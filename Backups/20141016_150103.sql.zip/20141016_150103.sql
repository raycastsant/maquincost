<?xml version="1.0"?><Agrupadormateriale>
<value>A I;;20</value>
<Tiposmateriale>
<value>Acero;;50;;60;;kg/mm2 </value>
<Materiale>
<value>390279996;;ACERO BARRA REDONDA X 12 M 12;;KGS;;30;;0.7053333;;0;;0000-00-00;;30;;Armando Mirabal</value>
</Materiale>
<value>Acero;;10;;20;;kg/mm2 </value>
<Materiale>
</Materiale>
<value>Acero duro al 12 % de manganeso;;;;;;</value>
<Materiale>
</Materiale>
</Tiposmateriale>
</Agrupadormateriale>
<Agrupadormateriale>
<value>A II;;12</value>
<Tiposmateriale>
<value>Acero;;60;;70;;kg/mm2</value>
<Materiale>
</Materiale>
</Tiposmateriale>
</Agrupadormateriale>
<Agrupadormateriale>
<value>A III;;89</value>
<Tiposmateriale>
<value>Acero;;70;;80;;kg/mm2 </value>
<Materiale>
</Materiale>
</Tiposmateriale>
</Agrupadormateriale>
<Agrupadormateriale>
<value>Bronces;;54</value>
<Tiposmateriale>
<value>Bronce;;;;;;</value>
<Materiale>
</Materiale>
</Tiposmateriale>
</Agrupadormateriale>
<Agrupadormateriale>
<value>Indefinido;;0</value>
<Tiposmateriale>
<value>Indefinido;;;;;;</value>
<Materiale>
<value>19819696;;BARRA AC G 35 DE DIAM 40MM;;KGS;;251;;2.16;;0;;2007-01-22;;14;;Luis Melian (Pzas prefabr)</value>
<value>390259821;;BARRA ACERO 30 X MA DE 90 MM;;KGS;;71;;0.36;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027865;;BARRA ACERO 9 X B6 DE 40 MM;;KGS;;57;;0.24;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025996;;BARRA ACERO ALEACION RED. GDO.;;KGS;;28;;0.7107143;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025999;;BARRA ACERO ALEACION REDONDA;;KGS;;171;;0.7110397;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027963;;BARRA ACERO CUAD. 9 X BG DE 60;;KGS;;77;;0.4035065;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260211;;BARRA ACERO CUAD. GRADO 45 DE;;KGS;;16;;0.32125;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027881;;BARRA ACERO CUAD. GRADO 45 DE;;KGS;;11;;0.3281818;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027964;;BARRA ACERO CUADRADA ALEACION;;KGS;;31;;0.4032787;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026115;;BARRA ACERO CUADRADA ESTIRADA;;KGS;;7;;0.2307692;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026116;;BARRA ACERO CUADRADA ESTIRADA;;KGS;;75;;0.2305333;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260931;;BARRA ACERO CUADRADA GDO X 12M;;KGS;;5;;1.3111111;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026093;;BARRA ACERO CUADRADA LMDA CTE;;KGS;;31;;0.8;;0;;2012-03-28;;30;;Armando Mirabal</value>
<value>390260264;;BARRA ACERO EXAGONAL C/CSN;;KGS;;3;;0.2666667;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260262;;BARRA ACERO EXAGONAL ESTIRADA;;KGS;;20;;0.27;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027894;;BARRA ACERO GRADO 35 DE 13 MM;;KGS;;9;;0.227907;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027893;;BARRA ACERO GRADO 35 DE 42 MM;;KGS;;8;;0.22875;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026007;;BARRA ACERO HTA. GRADO X12M DE;;KGS;;106;;0.7109641;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026035;;BARRA ACERO INOXIDABLE REDONDA;;KGS;;4;;1.8085714;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026923;;BARRA ACERO INOXIDABLE -X17H13;;KGS;;34;;1.1813609;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260263;;BARRA ACERO RDA. ESTIRADO FRIO;;KGS;;80;;0.3700249;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260471;;BARRA ACERO RDA. LAM. CAL. GDO;;KGS;;1211;;0.5090669;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260472;;BARRA ACERO RDA. LAM. EN CAL.;;KGS;;2823;;0.5090719;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026024;;BARRA ACERO RDA. LISA ESTIRADO;;KGS;;102;;0.5700195;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027732;;BARRA ACERO RED. 9XBG DE 50 MM;;KGS;;40;;0.4939547;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027327;;BARRA ACERO RED. GDO. 40XH2MA;;KGS;;36;;0.3141667;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260251;;BARRA ACERO RED. GRADO 20 DE;;KGS;;6;;0.2310345;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027381;;BARRA ACERO RED. GRADO 20 X DE;;C/U;;31;;0.3891803;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390259721;;BARRA ACERO RED. GRADO 45 65MM;;KGS;;42;;0.2309524;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027965;;BARRA ACERO RED. GRADO 45 DE;;KGS;;54;;0.2318519;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025970;;BARRA ACERO RED. GRADO 45 DE;;KGS;;37;;0.2318801;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260473;;BARRA ACERO RED. HERR. GRADO;;KGS;;393;;0.5090585;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026026;;BARRA ACERO REDONDA E/FRIO GDO;;KGS;;235;;0.2100128;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390279811;;BARRA ACERO REDONDA EST. FRIO;;KGS;;101;;0.2099606;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260151;;BARRA ACERO REDONDA GDO X12M;;KGS;;152;;0.7110526;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026032;;BARRA ACERO REDONDA GDO. C T 3;;KGS;;11;;0.1927273;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025966;;BARRA ACERO REDONDA GRADO 45;;KGS;;4;;0.2318182;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390259691;;BARRA ACERO REDONDA GRADO 45;;KGS;;69;;0.2317391;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026004;;BARRA ACERO X 12 DE 55 MM;;KGS;;212;;0.7110165;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>198105948;;BARRA ALIM.IZQ.U�A DEL.;;C/U;;1;;7.09;;0;;0000-00-00;;14;;Luis Melian (Pzas prefabr)</value>
<value>198806144;;BARRA ALIM.PERRO DEL.;;C/U;;5;;4.03;;0;;0000-00-00;;14;;Luis Melian (Pzas prefabr)</value>
<value>39027613;;BARRA CUAD. ACERO LAMINADA EN;;KGS;;55;;0.5600365;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025969;;BARRA CUADRADA ACERO EST. FRIO;;KGS;;15;;0.5281879;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026031;;BARRA CUADRADA ACERO GDO. 35;;KGS;;58;;0.3210345;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390259611;;BARRA CUADRADA ACERO GDO. 35;;KGS;;51;;0.3219802;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390278911;;BARRA CUADRADA ACERO GRADO 45;;KGS;;41;;0.2303704;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026109;;BARRA CUADRADA ACERO LAMINADO;;KGS;;15;;0.4187919;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026114;;BARRA CUADRADA ACERO STD. DE;;KGS;;4;;0.1906977;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026090;;BARRA CUADRADA DE ACERO GRADO;;KGS;;98;;0.4034872;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390259612;;BARRA DE ACERO CUADRADA EST.;;KGS;;15;;0.3214286;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025965;;BARRA DE ACERO REDONDA GRADO;;KGS;;68;;0.2317647;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026924;;BARRA DE ACERO REDONDA INOXID.;;KGS;;15;;0.5402597;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390259471;;BARRA DE ACERO REDONDA LISA;;KGS;;0;;0.1906977;;0;;2012-03-19;;30;;Armando Mirabal</value>
<value>5904922;;BARRA DE TIERRA FISICA 6 POSICIONES DE PARED;;U;;4;;299.3375;;111.0475;;2012-08-22;;5;;Almacen Central</value>
<value>39652418;;BARRA ESP CILINDRICA 31/64;;C/U;;2;;1.965;;0;;2005-12-04;;30;;Armando Mirabal</value>
<value>3963342;;BARRA PORTA CUCHILLA 1C 1/2;;C/U;;1;;1.1;;0;;2007-12-27;;30;;Armando Mirabal</value>
<value>3963344;;BARRA PORTA CUCHILLA 1C 3/8;;C/U;;7;;0.9;;0;;2007-12-27;;30;;Armando Mirabal</value>
<value>3963343;;BARRA PORTA CUCHILLA 1C 5/16;;C/U;;1;;0.95;;0;;2007-12-27;;30;;Armando Mirabal</value>
<value>390259951;;BARRA RDA. ACERO L/C X12M-8MM;;KGS;;13;;0.7106061;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027612;;BARRA RDA. ACERO LAM. CALIENTE;;KGS;;2;;0.5066667;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026936;;BARRA RDA. ALUMINIO DE 45 MM;;C/U;;1;;7.52;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3901203;;BARRA RED 44 MM;;KGS;;18;;0.1127778;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026006;;BARRA RED. ACERO 1133 41 GDO.;;KGS;;21;;0.7109524;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026003;;BARRA RED. ACERO 1133-41 GDO.;;KGS;;262;;0.7144656;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025997;;BARRA RED. ACERO 22 MM X 12 M;;KGS;;234;;0.7110493;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025977;;BARRA RED. ACERO 30 X MA 56 MM;;C/U;;3;;0.3615385;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026042;;BARRA RED. ACERO 9 X BG DE;;KGS;;0;;0.51;;0;;2012-03-20;;30;;Armando Mirabal</value>
<value>39025995;;BARRA RED. ACERO ALTA ALEACION;;KGS;;45;;0.767706;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026018;;BARRA RED. ACERO GRADO 35 25MM;;KGS;;86;;0.2261072;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025998;;BARRA RED. ACERO GRADO X12M;;KGS;;77;;0.7109518;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026010;;BARRA RED. ACERO GRADO X12M DE;;KGS;;106;;0.71109;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026045;;BARRA RED. ACERO HERRAM. DE;;KGS;;736;;0.5090761;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026028;;BARRA RED. ACERO HTA. A/V;;KGS;;5;;1.9596154;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026017;;BARRA RED. ACERO HTA. ALEACION;;KGS;;150;;0.711;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390259953;;BARRA RED. ACERO X12M DE 10 MM;;KGS;;36;;0.7109244;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026080;;BARRA RED. COBRE M 12 DE 45 MM;;KGS;;70;;1.0608571;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026002;;BARRA RED. DE ACERO GRADO X12M;;KGS;;142;;0.7109782;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025950;;BARRA REDONDA ACERO 3XP 45 MM;;KGS;;3;;0.1925926;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026037;;BARRA REDONDA ACERO 9 X B 6 DE;;KGS;;686;;0.5098614;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027611;;BARRA REDONDA ACERO 9 X B6 DE;;KGS;;4;;0.5590909;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260381;;BARRA REDONDA ACERO 9 X BG DE;;KGS;;5;;0.5091803;;0;;2012-03-20;;30;;Armando Mirabal</value>
<value>390260311;;BARRA REDONDA ACERO ESTIRADO;;KGS;;16;;0.290184;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027890;;BARRA REDONDA ACERO LAMINADA;;KGS;;10;;0.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390259952;;BARRA REDONDA ACERO LAMINADA;;KGS;;2;;0.71;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026925;;BARRA REDONDA ACERO LAMINADA;;KGS;;10;;0.390099;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026934;;BARRA REDONDA ACERO LAMINADO;;KGS;;9;;2.4576471;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260011;;BARRA REDONDA ACERO LAMINADO;;KGS;;39;;0.7111688;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026926;;BARRA REDONDA ACERO LAMINADO;;KGS;;4;;0.3139535;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026033;;BARRA REDONDA ACERO LISA GRADO;;KGS;;8;;0.1402597;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026000;;BARRA REDONDA ACERO X 124 D324;;KGS;;196;;0.7110489;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026001;;BARRA REDONDA ACERO X12M 38 MM;;KGS;;66;;0.7110606;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025949;;BARRA REDONDA LISA GRADO 3KP;;KGS;;9;;0.1925532;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>19320464;;BARRA RETENIDA  620M D-52;;U;;1;;394.79;;3719.95;;2012-06-19;;11;;Luis Melian (Mat Auxiliares)</value>
<value>19320465;;BARRA Z 62 M 23782;;U;;1;;464.84;;4379.95;;2012-06-19;;11;;Luis Melian (Mat Auxiliares)</value>
<value>19320143;;BARRA Z UE=4 62 M 21625;;U;;1;;333.36;;4248.89;;2008-10-14;;11;;Luis Melian (Mat Auxiliares)</value>
<value>19320471;;BARRA Z V E 4-62 M;;U;;1;;557.17;;5249.93;;2012-06-19;;11;;Luis Melian (Mat Auxiliares)</value>
<value>198806143;;BARRAALIM.PERRO INTERM.;;C/U;;7;;2.56;;0;;0000-00-00;;14;;Luis Melian (Pzas prefabr)</value>
<value>39026008;;BARRAS ACERO ALEACION REDONDA;;KGS;;89;;0.7110862;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026009;;BARRAS ACERO ALEACION REDONDA;;KGS;;209;;0.7110526;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026089;;BARRAS ACERO CUADRADO X 12 M;;KGS;;7;;1.3125;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025954;;BARRAS ACERO HERR. ALEACION;;KGS;;354;;0.4620056;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025962;;BARRAS ACERO RED. EST. FRIO;;KGS;;36;;0.2098901;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025963;;BARRAS ACERO RED. EST. FRIO;;KGS;;64;;0.58;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025961;;BARRAS ACERO RED. EST. FRIO;;KGS;;16;;0.21;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026012;;BARRAS ACERO RED. GDO. X12M DE;;KGS;;174;;0.7110345;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026076;;BARRAS COBRE RED. CONDICION;;KGS;;2;;0.91;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026078;;BARRAS COBRE REDONDAS COND.;;KGS;;25;;0.9099206;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026077;;BARRAS COBRE REDONDAS CONDIC.;;KGS;;52;;0.91;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026052;;BARRAS CUADRADAS 40 X HMA 106;;KGS;;22;;0.3830275;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026118;;BARRAS CUADRADAS ACERO HTA.;;KGS;;481;;0.9800083;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026112;;BARRAS CUADRADAS ACERO HTA.;;KGS;;6;;0.1310345;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026110;;BARRAS CUADRADAS ACERO HTA. AL;;KGS;;37;;0.4186486;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260001;;BARRAS DE ACERO REDONDA LAM.;;KGS;;31;;0.7111475;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026074;;BARRAS PLANCHUELAS MEDIA CA�A;;KGS;;69;;0.39;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3963341;;BARRAS PORTA CUCHILLA CONO # 4;;C/U;;1;;1.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3963340;;BARRAS PORTA CUCHILLA CONO 3;;C/U;;1;;0.7;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025960;;BARRAS RED. ACERO GDO. 25 50MM;;KGS;;16;;0.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026013;;BARRAS RED. ACERO HTA. ALEAC.;;KGS;;249;;0.7110619;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025964;;BARRAS REDONDA ACERO LAMINADO;;KGS;;2;;0.36;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025985;;BARRAS REDONDAS ACERO ALEACION;;KGS;;299;;0.3620067;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025983;;BARRAS REDONDAS ACERO ALEACION;;KGS;;46;;0.3619565;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026015;;BARRAS REDONDAS ACERO DE HTA.;;KGS;;16;;0.71125;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026038;;BARRAS REDONDAS ACERO GDO;;KGS;;636;;0.5090723;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025955;;BARRAS REDONDAS ACERO GRADO;;KGS;;82;;0.3900485;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026005;;BARRAS REDONDAS ACERO HTA. DE;;KGS;;4;;0.71;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026014;;BARRAS REDONDAS ACERO HTA. DE;;KGS;;326;;0.7110224;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026011;;BARRAS REDONDAS ACERO X12M DE;;KGS;;216;;0.7110287;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>59332367;;BUJE BARRA ESTAB LADA;;C/U;;2;;1.9823077;;0.0507692;;2012-08-28;;5;;Almacen Central</value>
<value>39026391;;CHOMACERA P/BARRA EXT. DELANT.;;C/U;;8;;1.71;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3963452;;CHUMACERA BARRA MOTRIZ;;C/U;;1;;133.34;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3963438;;CHUMASERA BARRA DELANTERA;;C/U;;1;;30.1;;0;;2008-12-19;;30;;Armando Mirabal</value>
<value>39148;;JAMON BARRA;;KGS;;0;;0.4285714;;3.5714286;;2012-09-12;;30;;Armando Mirabal</value>
<value>19148;;JAMON BARRA;;KGS;;0;;0.4376771;;3.5878187;;2012-09-14;;12;;Luis Melian (Comedor)</value>
<value>99148;;JAMON BARRA;;KGS;;0;;0.4400628;;3.5891701;;2012-09-11;;901;;Comedor</value>
<value>198806146;;MUELLE INTERM.TRASERO BARRA;;C/U;;38;;0.8344737;;0;;0000-00-00;;14;;Luis Melian (Pzas prefabr)</value>
<value>198807893;;PASADOR BARRA DE DISPARO;;C/U;;3;;9.26;;0;;0000-00-00;;14;;Luis Melian (Pzas prefabr)</value>
<value>198806282;;PERRO BARRA ALIM.;;C/U;;12;;26.015;;0;;0000-00-00;;14;;Luis Melian (Pzas prefabr)</value>
<value>1988011797;;PERRO TRASERO BARRA ALIM.;;C/U;;1;;25.81;;0;;0000-00-00;;14;;Luis Melian (Pzas prefabr)</value>
<value>1988013977;;ROBORTE BARRA ALIM.TRINQUETE;;C/U;;40;;0.6855;;0;;0000-00-00;;14;;Luis Melian (Pzas prefabr)</value>
<value>5934795;;ROTULA BARRA MANDO;;U;;0;;3.27;;34.45;;2012-05-27;;5;;Almacen Central</value>
<value>3963330;;SOP. BARRAS CILINDRICAS 80 MM;;C/U;;1;;0.9;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3963257;;SOP. DE BARRA IZQUIERDO GRANDE;;C/U;;1;;1.1;;0;;2011-06-21;;30;;Armando Mirabal</value>
<value>3963338;;SOP. P/BARRAS RECORTADOR 20 MM;;C/U;;1;;1.9;;0;;2011-06-21;;30;;Armando Mirabal</value>
<value>3963258;;SOP.BARRA RECTO GRANDE;;C/U;;1;;4.5;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3963462;;SOPORTE DE BARRA SOLDADORA;;C/U;;1;;94.3;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>5934831;;TERMINAL DERECHO BARRA;;U;;1;;2.58;;30.665;;2011-06-19;;5;;Almacen Central</value>
<value>5934830;;TERMINAL IZQUIERDO BARRA;;U;;1;;2.41;;28.525;;2011-06-19;;5;;Almacen Central</value>
<value>19014889;;TEXTOLITE EN BARRA;;KGS;;1;;8.4789474;;0;;2008-03-24;;11;;Luis Melian (Mat Auxiliares)</value>
<value>3902639815;;ACERO 4 X 9 CZ DE 28 MM;;KGS;;2;;0.7888889;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026108;;ACERO CALIBRADO 3 MM;;KGS;;10;;0.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>19819692;;ACERO CUAD G 45 DIAM 28MM;;KGS;;12;;126.0201681;;0;;2007-01-22;;14;;Luis Melian (Pzas prefabr)</value>
<value>390320026;;ACERO CUADRADO 9 X 8 G 40 MM;;KGS;;11;;0.4063636;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320029;;ACERO CUADRADO 9 X 8 G 50 MM;;KGS;;122;;0.5695902;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320050;;ACERO CUADRADO GR-45 36 MM;;KGS;;34;;0.2352941;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390279997;;ACERO CUADRADO X 12 M 12 MM;;KGS;;8;;1.3125;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390279998;;ACERO CUADRADO X 12 M 16 MM;;KGS;;19;;1.4745946;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902799912;;ACERO CUADRADO X 12 M 25 MM;;KGS;;2;;0.8;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320010;;ACERO CUADRADO X12M 32 MM;;KGS;;3;;1.3111111;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39032007;;ACERO CUADRADO X12M 75 X 75 MM;;KGS;;62;;1.3118506;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3903200;;ACERO CUADRADO X12M-100 M-M;;KGS;;34;;1.3117647;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320053;;ACERO CUADRADO Y-8-A 16 MM;;KGS;;16;;0.420625;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320047;;ACERO EXAGONAL GR-35 8 MM;;KGS;;6;;0.2390625;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320049;;ACERO EXAGONAL GR-45 14 MM;;KGS;;12;;0.2443478;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320088;;ACERO EXAGONAL GR-45 24 MM;;KGS;;2;;0.4117647;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>19818968;;ACERO G 20 DIAM  120 MM;;KGS;;444;;0.2299964;;0;;2007-10-22;;14;;Luis Melian (Pzas prefabr)</value>
<value>3902639827;;ACERO G. S. N. P/CUCHILLAS DE;;KGS;;8;;1.26;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639830;;ACERO G. S. N. P/CUCHILLAS DE;;KGS;;13;;1.26;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639829;;ACERO G. S. N. P/CUCHILLAS DE;;KGS;;5;;1.26;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639828;;ACERO G. S. N. P/CUCHILLAS DE;;KGS;;7;;1.26;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639831;;ACERO G. S. N. P/CUCHILLAS DE;;KGS;;6;;1.26;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639825;;ACERO G. S. N. P/CUCHILLAS DE;;KGS;;7;;1.26;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639826;;ACERO G. S. N. P/CUCHILLAS DE;;KGS;;10;;1.26;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639824;;ACERO G. S. N. P/CUCHILLOS DE;;KGS;;4;;1.26;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>19819259;;ACERO G-20 DIAM 100 MM;;KGS;;274;;1.5799949;;0;;2007-10-10;;14;;Luis Melian (Pzas prefabr)</value>
<value>3902639823;;ACERO HALCOMBI 9 1/4X8X1 1/2;;KGS;;3;;1.26;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639820;;ACERO HALCOMBI DE 10 3/4X9X2;;KGS;;7;;2.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639821;;ACERO HALCOMBI DE 11 X 9 X 3;;KGS;;14;;2.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639822;;ACERO HALCOMBI DE 11X9 1/2X2;;KGS;;6;;2.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639817;;ACERO HALCOMBI DE 9 1/4 X;;KGS;;7;;2.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639818;;ACERO HALCOMBI DE 9 5/8 X;;KGS;;7;;2.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902639819;;ACERO HALCOMBI DE 9 5/8 X 8;;KGS;;8;;2.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320089;;ACERO PLANCHUELA 3KP 16 X 50MM;;KGS;;9;;0.2622222;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39032009;;ACERO PLANCHUELA 9 X 8 G;;KGS;;20;;0.4779412;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320030;;ACERO PLANCHUELA 9 X 8 G;;KGS;;24;;0.4720833;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320021;;ACERO PLANCHUELA 9 X 8 G;;KGS;;3;;0.48;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320027;;ACERO PLANCHUELA 9 X 8 G;;KGS;;3;;0.496;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320080;;ACERO PLANCHUELA GR 6002 8X40;;KGS;;3;;0.35;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320048;;ACERO PLANCHUELA GR-35 20-200;;KGS;;14;;0.2364286;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39032006;;ACERO PLANCHUELA X12M 40 X 80;;KGS;;12;;0.5091667;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39032002;;ACERO PLANCHUELA X12M-10 X 100;;KGS;;4;;0.2457143;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320055;;ACERO PLANCHUELA Y 8 A 20 X 80;;KGS;;16;;0.323125;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>19819694;;ACERO RED 30  HMA DE DIAM 190M;;KGS;;37;;0.7379781;;0;;0000-00-00;;14;;Luis Melian (Pzas prefabr)</value>
<value>19819042;;ACERO RED G - 20  DIAM 25 MM;;KGS;;37;;0.5501216;;0;;2007-01-02;;14;;Luis Melian (Pzas prefabr)</value>
<value>19819689;;ACERO RED X12M X 32MM;;KGS;;146;;1.2300344;;0;;2007-01-02;;14;;Luis Melian (Pzas prefabr)</value>
<value>390320077;;ACERO RED. CALIBRADO GR B-1;;KGS;;8;;1.0106667;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320082;;ACERO RED. CSN 38 MM;;KGS;;20;;0.768;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025956;;ACERO RED. GDO. 40 XC DE 25 MM;;KGS;;22;;0.3;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026036;;ACERO RED. GDO. 9 X 18 DE 70;;KGS;;26;;0.5579365;;0;;2012-03-28;;30;;Armando Mirabal</value>
<value>390320046;;ACERO RED. GR-35 45 MM;;KGS;;39;;0.2894872;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320076;;ACERO RED. GRD P-18 20 MM;;KGS;;6;;2.45;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320078;;ACERO RED. GRD PH8 52 MM;;KGS;;3;;2.47;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320086;;ACERO RED. POLDI CSN 194343;;KGS;;212;;0.7375;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320041;;ACERO REDONDO 30 XMA 250 MM;;KGS;;46;;0.3973913;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320037;;ACERO REDONDO 30 XMA 50 MM;;KGS;;30;;0.397;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320038;;ACERO REDONDO 30 XMA 56 MM;;KGS;;94;;0.3626738;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320039;;ACERO REDONDO 30 XMA 60 MM;;KGS;;22;;0.3622727;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320040;;ACERO REDONDO 30 XMA 70 MM;;KGS;;78;;0.3113548;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320042;;ACERO REDONDO 61-20-25 MM;;KGS;;9;;0.0866667;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39032008;;ACERO REDONDO 9 X 8 G 10 MM;;KGS;;29;;0.4208904;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320031;;ACERO REDONDO 9 X 8 G 125 MM;;KGS;;169;;0.4046154;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320035;;ACERO REDONDO 9 X 8 G 150 MM;;KGS;;638;;0.5091066;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320033;;ACERO REDONDO 9 X 8 G 180 MM;;KGS;;228;;0.5090351;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320022;;ACERO REDONDO 9 X 8 G 20 MM;;KGS;;17;;0.4558824;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320034;;ACERO REDONDO 9 X 8 G 230 MM;;KGS;;100;;0.2122;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320023;;ACERO REDONDO 9 X 8 G 25 MM;;KGS;;8;;0.488;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320024;;ACERO REDONDO 9 X 8 G 32 MM;;KGS;;20;;0.4025;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320025;;ACERO REDONDO 9 X 8 G 35 MM;;KGS;;13;;0.2366412;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320036;;ACERO REDONDO 9 X 8 G 360 MM;;KGS;;39;;0.5090909;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320052;;ACERO REDONDO GRD-45 75 MM;;KGS;;26;;0.24;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902799910;;ACERO REDONDO X 12 M 22 MM;;KGS;;1;;0.54;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>3902799911;;ACERO REDONDO X 12 M 25 MM;;KGS;;45;;0.7368539;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320020;;ACERO REDONDO X12M 100 MM;;KGS;;344;;1.0364826;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39032003;;ACERO REDONDO X12M 120 MM;;KGS;;120;;0.7110833;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39032004;;ACERO REDONDO X12M 140 MM;;KGS;;6;;0.71;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320032;;ACERO REDONDO X12M 200 MM;;KGS;;110;;0.4555455;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39032005;;ACERO REDONDO X12M 200 MM;;KGS;;63;;0.7111111;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320011;;ACERO REDONDO X12M 38 MM;;KGS;;17;;0.7117647;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320012;;ACERO REDONDO X12M 45 MM;;KGS;;162;;0.3531481;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320013;;ACERO REDONDO X12M 50 MM;;KGS;;446;;0.7794843;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320014;;ACERO REDONDO X12M 55 MM;;KGS;;4;;0.7125;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320015;;ACERO REDONDO X12M 60 MM;;KGS;;46;;0.7119565;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320016;;ACERO REDONDO X12M 65 MM;;KGS;;49;;0.7410204;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320017;;ACERO REDONDO X12M 70 MM;;KGS;;30;;0.7125424;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320018;;ACERO REDONDO X12M 75 MM;;KGS;;56;;0.712234;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320019;;ACERO REDONDO X12M 95 MM;;KGS;;333;;1.0034535;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320043;;ACERO REDONDO X12M DE 80 MM;;KGS;;220;;0.6588182;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39032001;;ACERO REDONDO X12M-110-M-M;;KGS;;22;;0.7113636;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390320054;;ACERO REDONDO Y 8 A 25 MM;;KGS;;22;;0.3311628;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026117;;ACERO ROLLDI SSN # 17246 DE;;KGS;;3;;1.94;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39025959;;ACERO X 12 M PLANCHUELA DE;;KGS;;3;;2.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>19819690;;ACERO X 12M DIAM 60MM;;KGS;;449;;3.0450071;;0;;2007-10-22;;14;;Luis Melian (Pzas prefabr)</value>
<value>19014854;;ALAMBRE ACERO .26 0.65 MM;;KGS;;4;;0.4916667;;0;;2005-09-12;;11;;Luis Melian (Mat Auxiliares)</value>
<value>39027448;;ALAMBRE ACERO P/HACER MUELLE;;KGS;;46;;0.2301099;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026158;;ALAMBRE ACERO P/MUELLE LOCZA;;KGS;;8;;0.7420031;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>19014051;;ALAMBRE ACERO P/MUELLES .80 MM;;KGS;;90;;0.1600713;;0;;2005-09-14;;11;;Luis Melian (Mat Auxiliares)</value>
<value>39027639;;ALAMBRE ACERO P/MUELLES 1 MM;;KGS;;14;;0.8702899;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026201;;ALAMBRE ACERO P/MUELLES 60 CAS;;KGS;;74;;0.8768919;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390262021;;ALAMBRE ACERO P/MUELLES CLASE;;KGS;;64;;0.3399376;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390261991;;ALAMBRE ACERO P/MUELLES CLASE;;KGS;;60;;0.34;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027640;;ALAMBRE ACERO P/MUELLES CLASE;;KGS;;4;;0.2485714;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026200;;ALAMBRE ACERO P/MUELLES CLASE;;KGS;;56;;0.241844;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026204;;ALAMBRE ACERO P/MUELLES GR-65;;KGS;;50;;0.27;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>19014853;;ALAMBRE DE ACERO .0255;;KGS;;9;;0.4797872;;0;;2005-09-12;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1908715;;ALAMBRE DE ACERO .200 50 MM;;KGS;;10;;0.1411765;;0;;2005-09-21;;11;;Luis Melian (Mat Auxiliares)</value>
<value>190557;;ALAMBRE DE ACERO 0.118 MM;;KGS;;5;;0.2496164;;0;;2008-04-17;;11;;Luis Melian (Mat Auxiliares)</value>
<value>19018605;;ALAMBRE DE ACERO 6.5 SEGUNDA 1 ROLLO;;TM;;0;;148.6701031;;244.6701031;;2012-04-26;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1901217;;ARANDELA PRESION ACERO NEG.3/4;;C/U;;54;;0.0134848;;0;;2012-02-13;;11;;Luis Melian (Mat Auxiliares)</value>
<value>19016736;;BALAS DE ACERO 1 3/4;;C/U;;5;;0.81;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>39325842;;BALAS DE ACERO DE 7/16;;C/U;;11;;0.01;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>19319030;;BOLA DE ACERO 1/8;;C/U;;43;;0.0113953;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>19016940;;BOLAS ACERO 8 MM;;C/U;;493;;0.01;;0;;2010-10-31;;11;;Luis Melian (Mat Auxiliares)</value>
<value>19017408;;BOLAS DE ACERO 1/4;;C/U;;58;;0.0303448;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>59342292;;BOLAS DE ACERO 1/8;;C/U;;28;;0.011;;0;;2009-05-21;;5;;Almacen Central</value>
<value>190195;;BOLAS DE ACERO DE 10 MM O 3/8";;C/U;;190;;0.01;;0;;2011-10-10;;11;;Luis Melian (Mat Auxiliares)</value>
<value>190196;;BOLAS DE ACERO DE 17 X 32;;C/U;;6;;0.02;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>190198;;BOLAS DE ACERO DE 3/4;;C/U;;8;;0.06;;0;;2005-03-31;;11;;Luis Melian (Mat Auxiliares)</value>
<value>59344137;;BOLAS DE ACERO DE 3/4;;C/U;;147;;0.06;;0;;0000-00-00;;5;;Almacen Central</value>
<value>190200;;BOLAS DE ACERO DE 5/8;;C/U;;149;;0.0368456;;0;;2006-10-31;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1964446;;BROCA ACERO;;JGO;;2;;1.96;;11.63;;2009-02-12;;11;;Luis Melian (Mat Auxiliares)</value>
<value>5964446;;BROCA P/ACERO;;JGO;;2;;1.96;;11.63;;2009-02-11;;5;;Almacen Central</value>
<value>1905216;;CABLE DE ACERO BRILLANET 9.1;;TM;;0;;611.9904077;;0;;2007-11-28;;11;;Luis Melian (Mat Auxiliares)</value>
<value>5903030;;CABLE DE ACERO BRILLANTE 9.7MM;;MTS;;400;;0.099975;;0;;2005-04-30;;5;;Almacen Central</value>
<value>19015904;;CAPILAR ACERO INOX. � EXT.4 MM;;KGS;;17;;14.5586207;;0;;2004-12-15;;11;;Luis Melian (Mat Auxiliares)</value>
<value>59010299;;CERCA PIRLET 1.80 X 10 MALLA ACERO ROLLO;;U;;6;;11.7;;38.2;;2011-09-27;;5;;Almacen Central</value>
<value>5934482;;CLAN ACERO LADA;;JGO;;1;;1.11;;3.38;;2010-06-09;;5;;Almacen Central</value>
<value>59021376;;CUCHARITA CAFE   ROMA ACERO INX;;U;;3;;0.1066667;;0.43;;2009-11-27;;5;;Almacen Central</value>
<value>1963686;;CUCHILLA ACERO 6X6X125;;C/U;;1;;2.77;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>39625755;;DADO DE ROSCAR A MANO ACERO;;C/U;;1;;1.63;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39625749;;DADO DE ROSCAS A MANO ACERO;;C/U;;1;;1.25;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>59653527;;DADO MANUAL ACERO  5/16 X 18;;C/U;;3;;0.72;;0;;0000-00-00;;5;;Almacen Central</value>
<value>396257441;;DADO RDO. MANUAL ACERO HTA;;C/U;;2;;0.35;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39625745;;DADO RDO. MANUAL ACERO HTA DE;;C/U;;3;;0.69;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39625747;;DADO RDO. MANUAL ACERO HTA. DE;;C/U;;2;;0.66;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39625756;;DADO REDONDO ACERO AL CARBONO;;C/U;;1;;1.21;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>59653489;;DADO REDONDO MANUAL ACERO;;C/U;;2;;1.37;;0;;2009-06-03;;5;;Almacen Central</value>
<value>59653497;;DADO REDONDO MANUAL ACERO;;C/U;;5;;1.21;;0;;2011-08-09;;5;;Almacen Central</value>
<value>59653487;;DADO REDONDO MANUAL-ACERO;;C/U;;2;;0.52;;0;;2009-06-03;;5;;Almacen Central</value>
<value>3962797711;;ESPATULA ACERO FLEXIBLE DE 1";;C/U;;2;;0.51;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026126;;FLEJES ACERO 0.5 X 15 MM;;KGS;;837;;0.3584229;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>396279977;;FRESA P/ACERO 5 X 25 MM;;C/U;;1;;4.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>19819048;;G - 45 ACERO DIAM 180;;KGS;;561;;0.5699841;;0;;2007-12-09;;14;;Luis Melian (Pzas prefabr)</value>
<value>396279292;;MACHO MANUAL ACERO HERR. DE;;C/U;;2;;4.55;;0;;2005-12-04;;30;;Armando Mirabal</value>
<value>39625704;;MACHO MANUAL ACERO HTA 3/4X14;;JGO;;1;;0.63;;0;;2005-11-23;;30;;Armando Mirabal</value>
<value>396257181;;MACHO MANUAL ACERO HTA. 3/4X10;;JGO;;1;;18.06;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39627929;;MACHO MANUAL ACERO HTA. ROSCA;;C/U;;1;;1.94;;0;;2005-12-04;;30;;Armando Mirabal</value>
<value>39625715;;MACHO MANUAL ACERO P/ROSCA JGO 3 PIEZAS;;C/U;;1;;1.63;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39625724;;MACHO MANUAL ACERO P/ROSCA NC JGO 2 PIEZAS;;C/U;;1;;3.93;;0;;2005-12-04;;30;;Armando Mirabal</value>
<value>19017837;;MALLA ACERO 11X13X0.97;;KGS;;60;;0.5;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1909284;;PASADOR ACERO CONICO #10  3";;C/U;;48;;0.375;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1909274;;PASADOR ACERO CONICO #2  3";;C/U;;254;;0.1146063;;0;;2006-01-04;;11;;Luis Melian (Mat Auxiliares)</value>
<value>190388;;PASADOR ACERO CONICO #7 DE 3";;C/U;;52;;0.1148077;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1909281;;PASADOR ACERO CONICO #8 DE 3";;C/U;;103;;0.1148571;;0;;2009-01-27;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1909283;;PASADOR ACERO CONICO #9 4";;C/U;;11;;0.1327273;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>39027582;;PASADORES ABIERTOS ACERO DE;;C/U;;1;;0.54;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027578;;PASADORES ABIERTOS ACERO DE;;C/U;;1;;0.69;;0;;2005-12-08;;30;;Armando Mirabal</value>
<value>39027577;;PASADORES ABIERTOS ACERO DE;;KGS;;1;;1.09;;0;;2005-12-08;;30;;Armando Mirabal</value>
<value>39027579;;PASADORES ABIERTOS ACERO DE;;KGS;;1;;0.65;;0;;2005-12-08;;30;;Armando Mirabal</value>
<value>39027576;;PASADORES ABIERTOS ACERO DE;;KGS;;1;;1.12;;0;;2005-12-08;;30;;Armando Mirabal</value>
<value>39027581;;PASADORES ABIERTOS ACERO DE;;C/U;;2;;0.545;;0;;2005-12-08;;30;;Armando Mirabal</value>
<value>59017143;;PASADORES ABIERTOS DE ACERO;;C/U;;700;;0.7086;;0;;2004-12-14;;5;;Almacen Central</value>
<value>1909270;;PASADORES ACERO CONICO #1 2";;C/U;;130;;0.1133077;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1909273;;PASADORES ACERO CONICO #2;;C/U;;11;;0.1128571;;0;;2012-01-31;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1909282;;PASADORES ACERO CONICO #9 3";;C/U;;94;;0.1158511;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1909269;;PASADORES DE ACERO CONICO # 1;;C/U;;48;;0.1152083;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>59010038;;PERSIANA ACERO GALV 1X400 1X20;;C/U;;1;;93.59;;0;;2006-10-19;;5;;Almacen Central</value>
<value>5904918;;PICO DE ACERO COBRIZADO 1.5M;;u;;4;;69.0425;;21.5725;;2012-08-21;;5;;Almacen Central</value>
<value>19320459;;PLACA FRIJACION CHAPA ACERO;;U;;0;;1.415;;2.55;;2012-07-02;;11;;Luis Melian (Mat Auxiliares)</value>
<value>390260972;;PLANCHA ACERO GRADO 9 X BG DE;;KGS;;123;;0.4035772;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026048;;PLANCHA ACERO GRAO 3 KP DE;;KGS;;322;;0.11;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026071;;PLANCHUELA ACERO 3 KP 12X50 MM;;KGS;;23;;0.1996;;0;;2012-03-28;;30;;Armando Mirabal</value>
<value>390276141;;PLANCHUELA ACERO 9 X B6 DE;;KGS;;11;;0.56;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260973;;PLANCHUELA ACERO 9 X BG DE;;KGS;;8;;0.4746988;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026067;;PLANCHUELA ACERO AL CARBONO;;KGS;;6;;0.2;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026051;;PLANCHUELA ACERO G. 35 DE;;KGS;;67;;0.2370149;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390261101;;PLANCHUELA ACERO LAM. CALIENTE;;KGS;;0;;0.3397674;;0;;2012-03-28;;30;;Armando Mirabal</value>
<value>390261102;;PLANCHUELA ACERO LAM. CALIENTE;;KGS;;31;;0.3386139;;0;;2012-03-28;;30;;Armando Mirabal</value>
<value>390261051;;PLANCHUELA ACERO LAMINADA EN;;KGS;;50;;1.5350515;;0;;2012-03-28;;30;;Armando Mirabal</value>
<value>39027895;;PLANCHUELA ACERO LAMINADA EN;;KGS;;6;;0.7507937;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>390260971;;PLANCHUELA ACERO LAVADO 9 X B;;KGS;;8;;0.675;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027758;;PLANCHUELA DE ACERO;;C/U;;91;;0.2552486;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>59010058;;PLANCHUELA DE ACERO;;TM;;0;;73.6403509;;850.4166667;;2012-05-02;;5;;Almacen Central</value>
<value>39027822;;PLANCHUELA DE ACERO 9XB6 DE;;KGS;;6;;0.4032258;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027739;;PLANCHUELA DE ACERO DE 3KP DE;;KGS;;5;;0.2555556;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027220;;PLANCHUELA DE ACERO GDO. DE;;KGS;;18;;0.95;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027824;;PLANCHUELA DE ACERO GRADO 45;;KGS;;108;;0.14;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39027380;;PLANCHUELAS ACERO 25.4X6.35 MM;;KGS;;49;;0.7442387;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39017912;;PUNTILLA DE ACERO 2 1/2;;KGS;;2;;0.488;;2.08;;2012-10-01;;30;;Armando Mirabal</value>
<value>59017912;;PUNTILLA DE ACERO 2 1/2;;KGS;;339;;0.4881896;;2.0801823;;2012-09-18;;5;;Almacen Central</value>
<value>1907161;;REMACHE ACERO GALV. 1/8 X 3/8;;C/U;;1176;;0.0020172;;0;;2012-04-08;;11;;Luis Melian (Mat Auxiliares)</value>
<value>39026729;;REMACHE ACERO GALV. C/P;;KGS;;3;;0.7066667;;0;;2005-12-13;;30;;Armando Mirabal</value>
<value>39026730;;REMACHE ACERO GALV. C/PLANA;;KGS;;1;;2.12;;0;;2005-12-07;;30;;Armando Mirabal</value>
<value>39026734;;REMACHE ACERO GALV. C/PLANA;;KGS;;0;;0.8;;0;;2007-11-12;;30;;Armando Mirabal</value>
<value>39026736;;REMACHE ACERO GALV. C/PLANA;;KGS;;2;;0.61;;0;;2011-01-26;;30;;Armando Mirabal</value>
<value>39026732;;REMACHES ACERO GALV. C/P DE;;KGS;;2;;0.88;;0;;2007-02-05;;30;;Armando Mirabal</value>
<value>39625874;;RIMAS AJUSTABLES DE MANO ACERO;;C/U;;1;;3.51;;0;;2005-12-04;;30;;Armando Mirabal</value>
<value>39625868;;RIMAS AJUSTABLES DE MANO ACERO;;C/U;;1;;15.22;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39625873;;RIMAS APORTABLES DE MANO ACERO;;C/U;;2;;3.64;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>19320462;;RODILLO TAMBOR ACERO;;U;;0;;1.42;;2.55;;2012-07-02;;11;;Luis Melian (Mat Auxiliares)</value>
<value>59023202;;TANQUE ACERO PRECION;;C/U;;13;;267.0261538;;0;;0000-00-00;;5;;Almacen Central</value>
<value>59021373;;TENEDOR ACERO INOXIDABLE;;U;;87;;0.2163218;;0.8702299;;2009-12-08;;5;;Almacen Central</value>
<value>19015847;;TOR.PRIS.ACERO C/CIL #6 32 H.;;C/U;;165;;0.0632727;;0;;2005-02-02;;11;;Luis Melian (Mat Auxiliares)</value>
<value>19010267;;TORN.PRIS.ACERO C/CIL;;C/U;;179;;0.0966129;;0;;2011-03-15;;11;;Luis Melian (Mat Auxiliares)</value>
<value>19015849;;TORN.PRIS.ACERO C/CILIND 5/32;;C/U;;301;;0.0565449;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1907859;;TORNILLO ACERO PULIDO C/EXAG.;;C/U;;119;;0.1320168;;0;;2005-04-30;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1907854;;TORNILLO ACERO PULIDO C/EXAG.;;C/U;;346;;0.1077077;;0;;2011-05-31;;11;;Luis Melian (Mat Auxiliares)</value>
<value>39027259;;TORNILLO ACERO PULIDO C/EXAG.;;C/U;;397;;0.0787442;;0;;2012-07-03;;30;;Armando Mirabal</value>
<value>1907390;;TORNILLO ACERO PULIDO C/MAQUI.;;C/U;;600;;0.0166924;;0;;2012-06-25;;11;;Luis Melian (Mat Auxiliares)</value>
<value>39026532;;TORNILLO ALLEN ACERO C/CILIND.;;C/U;;25;;0.04;;0;;2005-12-05;;30;;Armando Mirabal</value>
<value>39026517;;TORNILLO ALLEN ACERO CABEZA;;C/U;;36;;0.0618667;;0;;2012-09-20;;30;;Armando Mirabal</value>
<value>39026516;;TORNILLO ALLEN ACERO CABEZA;;C/U;;178;;0.0603371;;0;;2006-08-20;;30;;Armando Mirabal</value>
<value>39026515;;TORNILLO ALLEN DE ACERO CABEZA;;C/U;;16;;0.03375;;0;;2007-02-18;;30;;Armando Mirabal</value>
<value>19012003;;TORNILLO DE ACERO 3/8 X 1 1/4;;C/U;;120;;0.0528333;;0;;2007-11-18;;11;;Luis Melian (Mat Auxiliares)</value>
<value>390265511;;TORNILLO DE MAQUINA DE ACERO;;C/U;;8;;0.05;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026646;;TORNILLO ESTUFA ACERO GALV.5/16X518;;C/U;;167;;0.0247904;;0;;2005-12-06;;30;;Armando Mirabal</value>
<value>39026567;;TORNILLO MAQ. ACERO C/EXAG.;;C/U;;17;;0.05;;0;;2005-12-06;;30;;Armando Mirabal</value>
<value>39026568;;TORNILLO MAQ. ACERO C/EXAG.;;C/U;;21;;0.06;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>39026571;;TORNILLO MAQ. ACERO C/EXAG.;;C/U;;26;;0.01;;0;;2005-12-06;;30;;Armando Mirabal</value>
<value>39026550;;TORNILLO MAQ. ACERO EXAGONAL;;C/U;;169;;0.01;;0;;2011-01-05;;30;;Armando Mirabal</value>
<value>39026654;;TORNILLO MAQUINA ACERO 3/4 X 5;;C/U;;11;;0.3063636;;0;;2005-12-06;;30;;Armando Mirabal</value>
<value>19013365;;TORNILLO PRIS. ACERO C/CIL.;;C/U;;39;;0.1538095;;0;;2011-11-14;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1901156;;TORNILLO PRIS.ACERO C/C R/STD;;C/U;;223;;0.155434;;0;;2012-02-14;;11;;Luis Melian (Mat Auxiliares)</value>
<value>190605;;TORNILLO PRIS.ACERO CILIND. DE;;C/U;;25;;0.0568;;0;;0000-00-00;;11;;Luis Melian (Mat Auxiliares)</value>
<value>1901599;;TORNILLO PRIS.ACERO EMBUTIR;;C/U;;220;;0.030913;;0;;2010-06-22;;11;;Luis Melian (Mat Auxiliares)</value>
<value>19013420;;TORNILLO PRISIONERO ACERO;;C/U;;44;;0.05;;0;;2007-01-12;;11;;Luis Melian (Mat Auxiliares)</value>
<value>39026518;;TORNILLOS ALLEN DE ACERO;;C/U;;38;;0.0285714;;0;;2011-01-31;;30;;Armando Mirabal</value>
<value>39026621;;TORNILLOS MAQUINA ACERO COMUN;;C/U;;210;;0.01;;0;;2007-03-21;;30;;Armando Mirabal</value>
<value>39021408;;TUBO ACERO DE 1/2;;U;;0;;4.518;;42.504;;2012-04-16;;30;;Armando Mirabal</value>
<value>390260356;;TUBOS ACERO INOXIDABLE 32X1.4;;KGS;;77;;1.4;;0;;0000-00-00;;30;;Armando Mirabal</value>
<value>1908779;;TUERCA ACERO PULIDO ROSCA GRUE;;C/U;;205;;0.0760408;;0;;2012-04-24;;11;;Luis Melian (Mat Auxiliares)</value>
<value>39026698;;TUERCA EXAG. ACERO R/STD 1 1/4;;C/U;;90;;0.0185556;;0;;2009-09-08;;30;;Armando Mirabal</value>
<value>1901225;;TUERCA STD. ACERO 5/16";;C/U;;553;;0.0169114;;0;;2012-09-18;;11;;Luis Melian (Mat Auxiliares)</value>
<value>5902211;;TURBINA 1/4 DE ACERO GALV.;;KGS;;7;;0.8514286;;0;;0000-00-00;;5;;Almacen Central</value>
<value>5904936;;ARQUETA REGISTRO 300X300 BARRA TIERRA;;U;;3;;447.9233333;;187.4033333;;2012-08-22;;5;;Almacen Central</value>
<value>59021075;;NIPLE ACERO GALV 1/4X31/2;;C/U;;13;;2.063125;;0;;2009-06-03;;5;;Almacen Central</value>
</Materiale>
</Tiposmateriale>
</Agrupadormateriale>
<Agrupadormateriale>
<value>ALUM;;0.5</value>
<Tiposmateriale>
<value>Aluminio;;50;;100;;kg/mm2 </value>
<Materiale>
</Materiale>
</Tiposmateriale>
</Agrupadormateriale>
