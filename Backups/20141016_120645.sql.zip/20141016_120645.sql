begin_Agrupadormateriale
A I.,20.
end_Tiposmateriale

A II.,12.
end_Tiposmateriale

A III.,89.
end_Tiposmateriale

Bronces.,54.
end_Tiposmateriale

Indefinido.,0.
end_Tiposmateriale

ALUM.,0.5.
end_Tiposmateriale

end_Agrupadormateriale
