SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";DELIMITER_SQL
                    /*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;DELIMITER_SQL
                    /*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;DELIMITER_SQL
                    /*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;DELIMITER_SQL
                    /*!40101 SET NAMES utf8 */;DELIMITER_SQL
/* Drop statement for agrupadormateriales */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`agrupadormateriales`;DELIMITER_SQL

/* Backuping table schema agrupadormateriales */
CREATE TABLE `maquincost`.`agrupadormateriales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `factor_peso` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data agrupadormateriales */
INSERT INTO `maquincost`.`agrupadormateriales` (`id`, `nombre`, `factor_peso`) VALUES (1, 'A I', 20);DELIMITER_SQL
INSERT INTO `maquincost`.`agrupadormateriales` (`id`, `nombre`, `factor_peso`) VALUES (2, 'A II', 12);DELIMITER_SQL
INSERT INTO `maquincost`.`agrupadormateriales` (`id`, `nombre`, `factor_peso`) VALUES (3, 'A III', 89);DELIMITER_SQL
INSERT INTO `maquincost`.`agrupadormateriales` (`id`, `nombre`, `factor_peso`) VALUES (4, 'Bronces', 54);DELIMITER_SQL
INSERT INTO `maquincost`.`agrupadormateriales` (`id`, `nombre`, `factor_peso`) VALUES (5, 'Indefinido', 0);DELIMITER_SQL
INSERT INTO `maquincost`.`agrupadormateriales` (`id`, `nombre`, `factor_peso`) VALUES (6, 'ALUM', '0.5');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for avances */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`avances`;DELIMITER_SQL

/* Backuping table schema avances */
CREATE TABLE `maquincost`.`avances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `selectore_id` int(11) DEFAULT NULL,
  `avance` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKavancespro479270` (`selectore_id`),
  CONSTRAINT `avances_ibfk_1` FOREIGN KEY (`selectore_id`) REFERENCES `selectores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data avances */
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (3, 19, 18);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (4, 19, 22);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (5, 7, 89);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (6, 5, 88);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (8, 2, 65);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (12, 17, 98);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (13, 16, 81);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (14, 19, 209);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (15, 19, 87);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (16, 19, 10);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (17, 22, 56);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (18, 22, 22);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (19, 22, 45);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (23, 25, 23);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (24, 26, '0.258');DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (25, 2, 104);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (27, 2, 47);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (28, 19, 34);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (29, 19, 345);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (30, 13, 456);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (31, 26, 45);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (32, 5, 35);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (33, 5, 346);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (34, 5, 6);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (35, 2, 74);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (36, 7, 7);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (37, 5, 90);DELIMITER_SQL
INSERT INTO `maquincost`.`avances` (`id`, `selectore_id`, `avance`) VALUES (38, 13, 15);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for calificacionoperarios */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`calificacionoperarios`;DELIMITER_SQL

/* Backuping table schema calificacionoperarios */
CREATE TABLE `maquincost`.`calificacionoperarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) DEFAULT NULL,
  `tarifa` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data calificacionoperarios */
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (1, 'Tornero  y Fresador A', '0.98');DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (2, 'Tornero  y Fresador B', 1.14);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (3, 'Tornero  y Fresador C', 1.33);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (4, 'Rectificador A', 1.14);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (5, 'Rectificador B', 4);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (6, 'Mecánico de taller A', 3);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (7, 'Mecánico de taller B', 5);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (8, 'Ajustador de banco A', 3);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (9, 'Ajustador de banco B', 4);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (10, 'Operario de segueta', 3);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (11, 'Afilador A', 4);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (12, 'Soldador A', 4);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (14, 'Proyectista', 8.6);DELIMITER_SQL
INSERT INTO `maquincost`.`calificacionoperarios` (`id`, `nombre`, `tarifa`) VALUES (15, 'Tecnólogo', 6);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for cartasordenes */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`cartasordenes`;DELIMITER_SQL

/* Backuping table schema cartasordenes */
CREATE TABLE `maquincost`.`cartasordenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordene_id` int(11) NOT NULL,
  `cartastecnologica_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cartastecnologica_id` (`cartastecnologica_id`),
  KEY `ordene_id` (`ordene_id`),
  CONSTRAINT `cartasordenes_ibfk_2` FOREIGN KEY (`cartastecnologica_id`) REFERENCES `cartastecnologicas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cartasordenes_ibfk_3` FOREIGN KEY (`ordene_id`) REFERENCES `ordenes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=latin1;DELIMITER_SQL

/* Backuping table data cartasordenes */
INSERT INTO `maquincost`.`cartasordenes` (`id`, `ordene_id`, `cartastecnologica_id`) VALUES (82, 2, 15);DELIMITER_SQL
INSERT INTO `maquincost`.`cartasordenes` (`id`, `ordene_id`, `cartastecnologica_id`) VALUES (89, 2, 24);DELIMITER_SQL
INSERT INTO `maquincost`.`cartasordenes` (`id`, `ordene_id`, `cartastecnologica_id`) VALUES (90, 2, 25);DELIMITER_SQL
INSERT INTO `maquincost`.`cartasordenes` (`id`, `ordene_id`, `cartastecnologica_id`) VALUES (100, 34, 25);DELIMITER_SQL
INSERT INTO `maquincost`.`cartasordenes` (`id`, `ordene_id`, `cartastecnologica_id`) VALUES (101, 34, 15);DELIMITER_SQL
INSERT INTO `maquincost`.`cartasordenes` (`id`, `ordene_id`, `cartastecnologica_id`) VALUES (106, 36, 26);DELIMITER_SQL
INSERT INTO `maquincost`.`cartasordenes` (`id`, `ordene_id`, `cartastecnologica_id`) VALUES (107, 36, 27);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for cartastecnologicas */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`cartastecnologicas`;DELIMITER_SQL

/* Backuping table schema cartastecnologicas */
CREATE TABLE `maquincost`.`cartastecnologicas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `materiale_id` int(11) DEFAULT NULL,
  `semiproductoforma_id` int(11) DEFAULT NULL,
  `maquina_id` int(11) DEFAULT NULL,
  `pieza_id` int(11) DEFAULT NULL,
  `codigo` varchar(30) DEFAULT NULL,
  `piezamaquinada` tinyint(4) DEFAULT NULL,
  `cantpiezas` int(11) NOT NULL DEFAULT '0',
  `urlplano` varchar(255) DEFAULT NULL,
  `codigoplano` varchar(20) DEFAULT NULL,
  `semiproducto_diametro` double DEFAULT NULL,
  `semiproducto_ancho` double DEFAULT NULL,
  `semiproducto_largo` double DEFAULT NULL,
  `semiproducto_peso_neto` double DEFAULT NULL,
  `semiproducto_peso_bruto` double DEFAULT NULL,
  `timpo_prep` double DEFAULT '0',
  `tiempo_total` double DEFAULT NULL,
  `fecha_elaboracion` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKcartastecn582497` (`materiale_id`),
  KEY `FKcartastecn514175` (`semiproductoforma_id`),
  KEY `FKcartastecn61686` (`maquina_id`),
  KEY `pieza_id` (`pieza_id`),
  CONSTRAINT `cartastecnologicas_ibfk_1` FOREIGN KEY (`materiale_id`) REFERENCES `materiales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cartastecnologicas_ibfk_2` FOREIGN KEY (`semiproductoforma_id`) REFERENCES `semiproductoformas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cartastecnologicas_ibfk_3` FOREIGN KEY (`maquina_id`) REFERENCES `maquinas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cartastecnologicas_ibfk_4` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data cartastecnologicas */
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (7, 1, 1, 1, 4, '5345', 0, 34343453, 'P1030444.JPG', '4355', 345, 5345, 34, 34, 5345, 4534, NULL, '2014-06-26');DELIMITER_SQL
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (10, 1, 1, 1, 4, '35345', 1, 353534, '', '34553', 345, 455, 345, 5435, 345, 34523, NULL, '2014-07-02');DELIMITER_SQL
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (11, 9, 1, 1, 4, '456456', 1, 9, 'P1030443.JPG', '456456456', 4, 566, 456, 64, 546, 45, NULL, '2014-06-18');DELIMITER_SQL
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (15, 1, 1, 10, 3, '456 4 horas', 0, 456546, '', '546', 456, 45, 6, 645, 645, 0, NULL, '2014-06-19');DELIMITER_SQL
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (16, 1, 1, 7, 5, '46', 0, 45646, '', '456', 456, 456, 546, 6456, 456, 3, NULL, '2014-07-03');DELIMITER_SQL
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (17, 1, 1, 3, 5, '456', 0, 456456, '', '456', 546, 456, 456, 546, 56, 456, NULL, '2014-03-12');DELIMITER_SQL
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (18, 1, 1, 1, 5, '45', 1, 456, '', '456', 546, 456, 46, 56, 456, 64, NULL, '2014-03-14');DELIMITER_SQL
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (24, 1, 1, 1, 3, '456', 0, 656, '', '456', 6456, 46, 6546, 45, 54, 456, NULL, '2014-07-03');DELIMITER_SQL
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (25, 1, 1, 1, 3, '45354', 0, 345, 'PLANTA BAJA EMPRESA Propuesta.dwg', '353', 3, 53, 53, 534, 45, 35, NULL, '2014-05-15');DELIMITER_SQL
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (26, 90, 5, 1, 6, '4564645', 1, 6, 'El mundo esta semana 02.JPG', '4645646', 4, 4, 4, 4, 4, 10, NULL, '2014-04-24');DELIMITER_SQL
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (27, 1, 2, 1, 6, '56456456', 0, 5, '', '456456', 4, 2, 5, 2, 4, 5, NULL, '2014-07-01');DELIMITER_SQL
INSERT INTO `maquincost`.`cartastecnologicas` (`id`, `materiale_id`, `semiproductoforma_id`, `maquina_id`, `pieza_id`, `codigo`, `piezamaquinada`, `cantpiezas`, `urlplano`, `codigoplano`, `semiproducto_diametro`, `semiproducto_ancho`, `semiproducto_largo`, `semiproducto_peso_neto`, `semiproducto_peso_bruto`, `timpo_prep`, `tiempo_total`, `fecha_elaboracion`) VALUES (28, 58, 1, 7, 4, 'hgh', 0, 4, '', 'rtghfg', 2, 2, 2, 2, 2, 4, NULL, '2014-07-03');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for ctregistros */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`ctregistros`;DELIMITER_SQL

/* Backuping table schema ctregistros */
CREATE TABLE `maquincost`.`ctregistros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cartastecnologica_id` int(11) DEFAULT NULL,
  `operacione_id` int(11) DEFAULT NULL,
  `tipooperacione_id` int(11) DEFAULT NULL,
  `elementoscortante_id` int(11) NOT NULL,
  `instrumentosauxiliare_id` int(11) DEFAULT NULL,
  `instrumentosmedicion_id` int(11) DEFAULT NULL,
  `no_orden_operacion` int(11) DEFAULT NULL,
  `diametro_ini` double DEFAULT NULL,
  `diametro_fin` double DEFAULT NULL,
  `longitud_diametro` double DEFAULT NULL,
  `longitud` double DEFAULT NULL,
  `prof_corte` double DEFAULT NULL,
  `cantidad_pasadas` int(11) DEFAULT NULL,
  `avance` double DEFAULT NULL,
  `velocidad` double DEFAULT NULL,
  `revoluciones` double DEFAULT NULL,
  `tiempo_corte` double DEFAULT NULL,
  `tiempo_auxiliar` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKctregistro547723` (`cartastecnologica_id`),
  KEY `FKctregistro441609` (`operacione_id`),
  KEY `FKctregistro77603` (`tipooperacione_id`),
  KEY `FKctregistro233266` (`elementoscortante_id`),
  KEY `FKctregistro887609` (`instrumentosauxiliare_id`),
  KEY `FKctregistro545156` (`instrumentosmedicion_id`),
  CONSTRAINT `ctregistros_ibfk_1` FOREIGN KEY (`cartastecnologica_id`) REFERENCES `cartastecnologicas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ctregistros_ibfk_2` FOREIGN KEY (`operacione_id`) REFERENCES `operaciones` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `ctregistros_ibfk_3` FOREIGN KEY (`tipooperacione_id`) REFERENCES `tipooperaciones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ctregistros_ibfk_4` FOREIGN KEY (`elementoscortante_id`) REFERENCES `elementoscortantes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ctregistros_ibfk_5` FOREIGN KEY (`instrumentosauxiliare_id`) REFERENCES `instrumentosauxiliares` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ctregistros_ibfk_6` FOREIGN KEY (`instrumentosmedicion_id`) REFERENCES `instrumentosmedicions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data ctregistros */
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (44, 7, 4, 2, 5, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 1);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (45, 11, 5, 3, 5, 3, 2, NULL, 5, 6, 4, 5, 4, 5, 5, 5, 5, 6, 5);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (49, 15, 4, 2, 5, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 10);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (50, 15, 4, 2, 5, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 10);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (52, 16, 4, 2, 5, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (53, 16, 4, 2, 5, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (54, 16, 4, 2, 5, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (55, 17, 2, 2, 2, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 45, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (56, 18, 4, 2, 5, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (57, 15, 2, 2, 2, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 110, 10);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (61, 10, 4, 2, 5, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 1);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (63, 24, 4, 2, 5, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (64, 17, 2, 2, 2, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (65, 25, 4, 2, 7, 2, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (66, 26, 4, 2, 7, 2, 4, NULL, 4, 5, 0, 0, 0, 0, 0, 0, 0, 5, 3);DELIMITER_SQL
INSERT INTO `maquincost`.`ctregistros` (`id`, `cartastecnologica_id`, `operacione_id`, `tipooperacione_id`, `elementoscortante_id`, `instrumentosauxiliare_id`, `instrumentosmedicion_id`, `no_orden_operacion`, `diametro_ini`, `diametro_fin`, `longitud_diametro`, `longitud`, `prof_corte`, `cantidad_pasadas`, `avance`, `velocidad`, `revoluciones`, `tiempo_corte`, `tiempo_auxiliar`) VALUES (67, 28, 4, 1, 5, 3, 1, NULL, 6, 7, 7, 5, 5, 6, 7, 6, 6, 5, 3);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for elementocortanteoperaciones */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`elementocortanteoperaciones`;DELIMITER_SQL

/* Backuping table schema elementocortanteoperaciones */
CREATE TABLE `maquincost`.`elementocortanteoperaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operacione_id` int(11) NOT NULL,
  `elementoscortante_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKelementoco261305` (`operacione_id`),
  KEY `FKelementoco558020` (`elementoscortante_id`),
  CONSTRAINT `elementocortanteoperaciones_ibfk_1` FOREIGN KEY (`operacione_id`) REFERENCES `operaciones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `elementocortanteoperaciones_ibfk_2` FOREIGN KEY (`elementoscortante_id`) REFERENCES `elementoscortantes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data elementocortanteoperaciones */
INSERT INTO `maquincost`.`elementocortanteoperaciones` (`id`, `operacione_id`, `elementoscortante_id`) VALUES (12, 4, 5);DELIMITER_SQL
INSERT INTO `maquincost`.`elementocortanteoperaciones` (`id`, `operacione_id`, `elementoscortante_id`) VALUES (19, 5, 5);DELIMITER_SQL
INSERT INTO `maquincost`.`elementocortanteoperaciones` (`id`, `operacione_id`, `elementoscortante_id`) VALUES (21, 1, 5);DELIMITER_SQL
INSERT INTO `maquincost`.`elementocortanteoperaciones` (`id`, `operacione_id`, `elementoscortante_id`) VALUES (22, 3, 6);DELIMITER_SQL
INSERT INTO `maquincost`.`elementocortanteoperaciones` (`id`, `operacione_id`, `elementoscortante_id`) VALUES (24, 1, 2);DELIMITER_SQL
INSERT INTO `maquincost`.`elementocortanteoperaciones` (`id`, `operacione_id`, `elementoscortante_id`) VALUES (25, 5, 2);DELIMITER_SQL
INSERT INTO `maquincost`.`elementocortanteoperaciones` (`id`, `operacione_id`, `elementoscortante_id`) VALUES (26, 2, 2);DELIMITER_SQL
INSERT INTO `maquincost`.`elementocortanteoperaciones` (`id`, `operacione_id`, `elementoscortante_id`) VALUES (27, 6, 1);DELIMITER_SQL
INSERT INTO `maquincost`.`elementocortanteoperaciones` (`id`, `operacione_id`, `elementoscortante_id`) VALUES (28, 2, 7);DELIMITER_SQL
INSERT INTO `maquincost`.`elementocortanteoperaciones` (`id`, `operacione_id`, `elementoscortante_id`) VALUES (29, 4, 7);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for elementoscortantes */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`elementoscortantes`;DELIMITER_SQL

/* Backuping table schema elementoscortantes */
CREATE TABLE `maquincost`.`elementoscortantes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `materialelemento_id` int(11) DEFAULT NULL,
  `formascorte_id` int(11) DEFAULT NULL,
  `tipoelementoscortante_id` int(11) DEFAULT NULL,
  `nombre` varchar(80) DEFAULT NULL,
  `descripcion` varchar(130) DEFAULT NULL,
  `calzada` tinyint(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKelementosc291539` (`materialelemento_id`),
  KEY `FKelementosc265304` (`formascorte_id`),
  KEY `FKelementosc932586` (`tipoelementoscortante_id`),
  CONSTRAINT `elementoscortantes_ibfk_1` FOREIGN KEY (`materialelemento_id`) REFERENCES `materialelementos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `elementoscortantes_ibfk_2` FOREIGN KEY (`formascorte_id`) REFERENCES `formascortes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `elementoscortantes_ibfk_3` FOREIGN KEY (`tipoelementoscortante_id`) REFERENCES `tipoelementoscortante` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data elementoscortantes */
INSERT INTO `maquincost`.`elementoscortantes` (`id`, `materialelemento_id`, `formascorte_id`, `tipoelementoscortante_id`, `nombre`, `descripcion`, `calzada`) VALUES (1, 1, 1, 1, 'MATROX', '3x5 Calada', 1);DELIMITER_SQL
INSERT INTO `maquincost`.`elementoscortantes` (`id`, `materialelemento_id`, `formascorte_id`, `tipoelementoscortante_id`, `nombre`, `descripcion`, `calzada`) VALUES (2, 2, 4, 2, 'Widia', '45', 0);DELIMITER_SQL
INSERT INTO `maquincost`.`elementoscortantes` (`id`, `materialelemento_id`, `formascorte_id`, `tipoelementoscortante_id`, `nombre`, `descripcion`, `calzada`) VALUES (5, 3, 3, 3, 'Durazno', '35', 1);DELIMITER_SQL
INSERT INTO `maquincost`.`elementoscortantes` (`id`, `materialelemento_id`, `formascorte_id`, `tipoelementoscortante_id`, `nombre`, `descripcion`, `calzada`) VALUES (6, 4, 2, 4, 'KIT 342', 'Automatica', 1);DELIMITER_SQL
INSERT INTO `maquincost`.`elementoscortantes` (`id`, `materialelemento_id`, `formascorte_id`, `tipoelementoscortante_id`, `nombre`, `descripcion`, `calzada`) VALUES (7, 3, 2, 2, 'Cuchilla NES', '3x4 Manual', 0);DELIMITER_SQL
INSERT INTO `maquincost`.`elementoscortantes` (`id`, `materialelemento_id`, `formascorte_id`, `tipoelementoscortante_id`, `nombre`, `descripcion`, `calzada`) VALUES (8, 2, 3, 4, 'tyuutu', '5674', 1);DELIMITER_SQL
INSERT INTO `maquincost`.`elementoscortantes` (`id`, `materialelemento_id`, `formascorte_id`, `tipoelementoscortante_id`, `nombre`, `descripcion`, `calzada`) VALUES (9, 3, 3, 2, 'Segueta', 'sdfsdf', 1);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for formapagos */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`formapagos`;DELIMITER_SQL

/* Backuping table schema formapagos */
CREATE TABLE `maquincost`.`formapagos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data formapagos */
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for formascortes */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`formascortes`;DELIMITER_SQL

/* Backuping table schema formascortes */
CREATE TABLE `maquincost`.`formascortes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data formascortes */
INSERT INTO `maquincost`.`formascortes` (`id`, `nombre`) VALUES (1, 'Izquierda');DELIMITER_SQL
INSERT INTO `maquincost`.`formascortes` (`id`, `nombre`) VALUES (2, 'Derecha');DELIMITER_SQL
INSERT INTO `maquincost`.`formascortes` (`id`, `nombre`) VALUES (3, 'Acodada');DELIMITER_SQL
INSERT INTO `maquincost`.`formascortes` (`id`, `nombre`) VALUES (4, 'Recta');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for fuerzatrabajoordenes */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`fuerzatrabajoordenes`;DELIMITER_SQL

/* Backuping table schema fuerzatrabajoordenes */
CREATE TABLE `maquincost`.`fuerzatrabajoordenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operario_id` int(11) NOT NULL,
  `ordenreal_id` int(11) DEFAULT NULL,
  `salario` double DEFAULT NULL,
  `fechacomienzo` date DEFAULT NULL,
  `fechaterminacion` date DEFAULT NULL,
  `totalhoras` int(11) DEFAULT NULL,
  `tarifa` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKfuerzatrab42480` (`operario_id`),
  KEY `FKfuerzatrab585690` (`ordenreal_id`),
  CONSTRAINT `fuerzatrabajoordenes_ibfk_1` FOREIGN KEY (`operario_id`) REFERENCES `operarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fuerzatrabajoordenes_ibfk_2` FOREIGN KEY (`ordenreal_id`) REFERENCES `ordenreals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data fuerzatrabajoordenes */
INSERT INTO `maquincost`.`fuerzatrabajoordenes` (`id`, `operario_id`, `ordenreal_id`, `salario`, `fechacomienzo`, `fechaterminacion`, `totalhoras`, `tarifa`) VALUES (5, 4, 2, 6.84, '2014-05-01', '2014-05-23', 6, 1.14);DELIMITER_SQL
INSERT INTO `maquincost`.`fuerzatrabajoordenes` (`id`, `operario_id`, `ordenreal_id`, `salario`, `fechacomienzo`, `fechaterminacion`, `totalhoras`, `tarifa`) VALUES (7, 2, 2, 7.98, '2014-05-08', '2014-05-24', 7, 1.14);DELIMITER_SQL
INSERT INTO `maquincost`.`fuerzatrabajoordenes` (`id`, `operario_id`, `ordenreal_id`, `salario`, `fechacomienzo`, `fechaterminacion`, `totalhoras`, `tarifa`) VALUES (8, 1, 2, 3.92, '2014-05-03', '2014-05-31', 4, '0.98');DELIMITER_SQL
INSERT INTO `maquincost`.`fuerzatrabajoordenes` (`id`, `operario_id`, `ordenreal_id`, `salario`, `fechacomienzo`, `fechaterminacion`, `totalhoras`, `tarifa`) VALUES (14, 3, 2, 7.98, '2014-06-12', '2014-06-21', 6, 1.33);DELIMITER_SQL
INSERT INTO `maquincost`.`fuerzatrabajoordenes` (`id`, `operario_id`, `ordenreal_id`, `salario`, `fechacomienzo`, `fechaterminacion`, `totalhoras`, `tarifa`) VALUES (19, 1, 21, 7.84, '2014-08-21', '2014-08-15', 8, '0.98');DELIMITER_SQL
INSERT INTO `maquincost`.`fuerzatrabajoordenes` (`id`, `operario_id`, `ordenreal_id`, `salario`, `fechacomienzo`, `fechaterminacion`, `totalhoras`, `tarifa`) VALUES (20, 1, 25, 3.92, '2014-09-11', '2014-09-18', 4, '0.98');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for informerecepcions */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`informerecepcions`;DELIMITER_SQL

/* Backuping table schema informerecepcions */
CREATE TABLE `maquincost`.`informerecepcions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordenreal_id` int(11) NOT NULL,
  `codigo` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` date NOT NULL,
  `empresa` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `unidad` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ordenreal_id` (`ordenreal_id`),
  CONSTRAINT `informerecepcions_ibfk_1` FOREIGN KEY (`ordenreal_id`) REFERENCES `ordenreals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;DELIMITER_SQL

/* Backuping table data informerecepcions */
INSERT INTO `maquincost`.`informerecepcions` (`id`, `ordenreal_id`, `codigo`, `fecha`, `empresa`, `unidad`) VALUES (1, 2, 'FGH-342', '2014-07-22', 'ENVOOC', 'LM');DELIMITER_SQL
INSERT INTO `maquincost`.`informerecepcions` (`id`, `ordenreal_id`, `codigo`, `fecha`, `empresa`, `unidad`) VALUES (2, 21, 'KJHG565', '2014-09-11', 'ENVOOC', 'Dirección');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for instrumentosauxiliares */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`instrumentosauxiliares`;DELIMITER_SQL

/* Backuping table schema instrumentosauxiliares */
CREATE TABLE `maquincost`.`instrumentosauxiliares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data instrumentosauxiliares */
INSERT INTO `maquincost`.`instrumentosauxiliares` (`id`, `nombre`) VALUES (1, 'Pinza');DELIMITER_SQL
INSERT INTO `maquincost`.`instrumentosauxiliares` (`id`, `nombre`) VALUES (2, 'Destornillador');DELIMITER_SQL
INSERT INTO `maquincost`.`instrumentosauxiliares` (`id`, `nombre`) VALUES (3, 'Martillo');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for instrumentosmedicions */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`instrumentosmedicions`;DELIMITER_SQL

/* Backuping table schema instrumentosmedicions */
CREATE TABLE `maquincost`.`instrumentosmedicions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data instrumentosmedicions */
INSERT INTO `maquincost`.`instrumentosmedicions` (`id`, `nombre`) VALUES (1, 'Regla');DELIMITER_SQL
INSERT INTO `maquincost`.`instrumentosmedicions` (`id`, `nombre`) VALUES (2, 'Pie de Rey');DELIMITER_SQL
INSERT INTO `maquincost`.`instrumentosmedicions` (`id`, `nombre`) VALUES (4, 'Monómetro');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for maquinas */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`maquinas`;DELIMITER_SQL

/* Backuping table schema maquinas */
CREATE TABLE `maquincost`.`maquinas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `modelo` varchar(50) DEFAULT NULL,
  `imagen` varchar(100) DEFAULT NULL,
  `coef_pieza` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data maquinas */
INSERT INTO `maquincost`.`maquinas` (`id`, `nombre`, `modelo`, `imagen`, `coef_pieza`) VALUES (1, 'Fresadora', 'MHY23', 'torno2.PNG', 2.2);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinas` (`id`, `nombre`, `modelo`, `imagen`, `coef_pieza`) VALUES (2, 'Torno', '536', 'torno3.PNG', 1.1);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinas` (`id`, `nombre`, `modelo`, `imagen`, `coef_pieza`) VALUES (3, 'TALADRO l', '345345', 'torno8.png', 6);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinas` (`id`, `nombre`, `modelo`, `imagen`, `coef_pieza`) VALUES (7, 'Recortador', 'FVC001', 'torno4.PNG', 2);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinas` (`id`, `nombre`, `modelo`, `imagen`, `coef_pieza`) VALUES (10, 'Trozadora', 'KKKK', 'torno5.PNG', 1);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for maquinasoperaciones */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`maquinasoperaciones`;DELIMITER_SQL

/* Backuping table schema maquinasoperaciones */
CREATE TABLE `maquincost`.`maquinasoperaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maquina_id` int(11) NOT NULL,
  `operacione_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKmaquinasop492178` (`maquina_id`),
  KEY `FKmaquinasop392048` (`operacione_id`),
  CONSTRAINT `maquinasoperaciones_ibfk_1` FOREIGN KEY (`maquina_id`) REFERENCES `maquinas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `maquinasoperaciones_ibfk_2` FOREIGN KEY (`operacione_id`) REFERENCES `operaciones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data maquinasoperaciones */
INSERT INTO `maquincost`.`maquinasoperaciones` (`id`, `maquina_id`, `operacione_id`) VALUES (1, 1, 4);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinasoperaciones` (`id`, `maquina_id`, `operacione_id`) VALUES (2, 1, 1);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinasoperaciones` (`id`, `maquina_id`, `operacione_id`) VALUES (3, 1, 5);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinasoperaciones` (`id`, `maquina_id`, `operacione_id`) VALUES (4, 3, 2);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinasoperaciones` (`id`, `maquina_id`, `operacione_id`) VALUES (5, 10, 2);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinasoperaciones` (`id`, `maquina_id`, `operacione_id`) VALUES (6, 2, 4);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinasoperaciones` (`id`, `maquina_id`, `operacione_id`) VALUES (7, 2, 5);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinasoperaciones` (`id`, `maquina_id`, `operacione_id`) VALUES (8, 2, 2);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinasoperaciones` (`id`, `maquina_id`, `operacione_id`) VALUES (9, 2, 3);DELIMITER_SQL
INSERT INTO `maquincost`.`maquinasoperaciones` (`id`, `maquina_id`, `operacione_id`) VALUES (10, 7, 4);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for materialelementos */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`materialelementos`;DELIMITER_SQL

/* Backuping table schema materialelementos */
CREATE TABLE `maquincost`.`materialelementos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data materialelementos */
INSERT INTO `maquincost`.`materialelementos` (`id`, `nombre`) VALUES (1, 'Acero Inoxidable');DELIMITER_SQL
INSERT INTO `maquincost`.`materialelementos` (`id`, `nombre`) VALUES (2, 'Tusteno');DELIMITER_SQL
INSERT INTO `maquincost`.`materialelementos` (`id`, `nombre`) VALUES (3, 'Acero Endurecido');DELIMITER_SQL
INSERT INTO `maquincost`.`materialelementos` (`id`, `nombre`) VALUES (4, 'Aleación de Bronce');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for materiales */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`materiales`;DELIMITER_SQL

/* Backuping table schema materiales */
CREATE TABLE `maquincost`.`materiales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tiposmateriale_id` int(11) DEFAULT NULL,
  `codigo` varchar(30) DEFAULT NULL,
  `descripcion` varchar(150) DEFAULT NULL,
  `um` varchar(15) DEFAULT NULL,
  `existencia` int(11) DEFAULT NULL,
  `precio_mn` double DEFAULT NULL,
  `precio_mlc` double DEFAULT NULL,
  `fecha_ultima_salida` date DEFAULT NULL,
  `almacen_codigo` varchar(15) NOT NULL,
  `almacen_desc` varchar(120) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKmateriales735281` (`tiposmateriale_id`)
) ENGINE=InnoDB AUTO_INCREMENT=388 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data materiales */
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (1, 1, '390279996', 'ACERO BARRA REDONDA X 12 M 12', 'KGS', 30, '0.7053333', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (3, 8, '19819696', 'BARRA AC G 35 DE DIAM 40MM', 'KGS', 251, 2.16, 0, '2007-01-22', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (4, 8, '390259821', 'BARRA ACERO 30 X MA DE 90 MM', 'KGS', 71, '0.36', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (5, 8, '39027865', 'BARRA ACERO 9 X B6 DE 40 MM', 'KGS', 57, '0.24', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (6, 8, '39025996', 'BARRA ACERO ALEACION RED. GDO.', 'KGS', 28, '0.7107143', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (7, 8, '39025999', 'BARRA ACERO ALEACION REDONDA', 'KGS', 171, '0.7110397', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (8, 8, '39027963', 'BARRA ACERO CUAD. 9 X BG DE 60', 'KGS', 77, '0.4035065', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (9, 8, '390260211', 'BARRA ACERO CUAD. GRADO 45 DE', 'KGS', 16, '0.32125', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (10, 8, '39027881', 'BARRA ACERO CUAD. GRADO 45 DE', 'KGS', 11, '0.3281818', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (11, 8, '39027964', 'BARRA ACERO CUADRADA ALEACION', 'KGS', 31, '0.4032787', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (12, 8, '39026115', 'BARRA ACERO CUADRADA ESTIRADA', 'KGS', 7, '0.2307692', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (13, 8, '39026116', 'BARRA ACERO CUADRADA ESTIRADA', 'KGS', 75, '0.2305333', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (14, 8, '390260931', 'BARRA ACERO CUADRADA GDO X 12M', 'KGS', 5, 1.3111111, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (15, 8, '39026093', 'BARRA ACERO CUADRADA LMDA CTE', 'KGS', 31, '0.8', 0, '2012-03-28', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (16, 8, '390260264', 'BARRA ACERO EXAGONAL C/CSN', 'KGS', 3, '0.2666667', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (17, 8, '390260262', 'BARRA ACERO EXAGONAL ESTIRADA', 'KGS', 20, '0.27', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (18, 8, '39027894', 'BARRA ACERO GRADO 35 DE 13 MM', 'KGS', 9, '0.227907', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (19, 8, '39027893', 'BARRA ACERO GRADO 35 DE 42 MM', 'KGS', 8, '0.22875', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (20, 8, '39026007', 'BARRA ACERO HTA. GRADO X12M DE', 'KGS', 106, '0.7109641', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (21, 8, '39026035', 'BARRA ACERO INOXIDABLE REDONDA', 'KGS', 4, 1.8085714, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (22, 8, '39026923', 'BARRA ACERO INOXIDABLE -X17H13', 'KGS', 34, 1.1813609, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (23, 8, '390260263', 'BARRA ACERO RDA. ESTIRADO FRIO', 'KGS', 80, '0.3700249', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (24, 8, '390260471', 'BARRA ACERO RDA. LAM. CAL. GDO', 'KGS', 1211, '0.5090669', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (25, 8, '390260472', 'BARRA ACERO RDA. LAM. EN CAL.', 'KGS', 2823, '0.5090719', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (26, 8, '39026024', 'BARRA ACERO RDA. LISA ESTIRADO', 'KGS', 102, '0.5700195', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (27, 8, '39027732', 'BARRA ACERO RED. 9XBG DE 50 MM', 'KGS', 40, '0.4939547', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (28, 8, '39027327', 'BARRA ACERO RED. GDO. 40XH2MA', 'KGS', 36, '0.3141667', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (29, 8, '390260251', 'BARRA ACERO RED. GRADO 20 DE', 'KGS', 6, '0.2310345', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (30, 8, '39027381', 'BARRA ACERO RED. GRADO 20 X DE', 'C/U', 31, '0.3891803', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (31, 8, '390259721', 'BARRA ACERO RED. GRADO 45 65MM', 'KGS', 42, '0.2309524', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (32, 8, '39027965', 'BARRA ACERO RED. GRADO 45 DE', 'KGS', 54, '0.2318519', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (33, 8, '39025970', 'BARRA ACERO RED. GRADO 45 DE', 'KGS', 37, '0.2318801', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (34, 8, '390260473', 'BARRA ACERO RED. HERR. GRADO', 'KGS', 393, '0.5090585', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (35, 8, '39026026', 'BARRA ACERO REDONDA E/FRIO GDO', 'KGS', 235, '0.2100128', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (36, 8, '390279811', 'BARRA ACERO REDONDA EST. FRIO', 'KGS', 101, '0.2099606', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (37, 8, '390260151', 'BARRA ACERO REDONDA GDO X12M', 'KGS', 152, '0.7110526', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (38, 8, '39026032', 'BARRA ACERO REDONDA GDO. C T 3', 'KGS', 11, '0.1927273', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (39, 8, '39025966', 'BARRA ACERO REDONDA GRADO 45', 'KGS', 4, '0.2318182', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (40, 8, '390259691', 'BARRA ACERO REDONDA GRADO 45', 'KGS', 69, '0.2317391', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (41, 8, '39026004', 'BARRA ACERO X 12 DE 55 MM', 'KGS', 212, '0.7110165', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (42, 8, '198105948', 'BARRA ALIM.IZQ.UÑA DEL.', 'C/U', 1, 7.09, 0, '0000-00-00', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (43, 8, '198806144', 'BARRA ALIM.PERRO DEL.', 'C/U', 5, 4.03, 0, '0000-00-00', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (44, 8, '39027613', 'BARRA CUAD. ACERO LAMINADA EN', 'KGS', 55, '0.5600365', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (45, 8, '39025969', 'BARRA CUADRADA ACERO EST. FRIO', 'KGS', 15, '0.5281879', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (46, 8, '39026031', 'BARRA CUADRADA ACERO GDO. 35', 'KGS', 58, '0.3210345', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (47, 8, '390259611', 'BARRA CUADRADA ACERO GDO. 35', 'KGS', 51, '0.3219802', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (48, 8, '390278911', 'BARRA CUADRADA ACERO GRADO 45', 'KGS', 41, '0.2303704', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (49, 8, '39026109', 'BARRA CUADRADA ACERO LAMINADO', 'KGS', 15, '0.4187919', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (50, 8, '39026114', 'BARRA CUADRADA ACERO STD. DE', 'KGS', 4, '0.1906977', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (51, 8, '39026090', 'BARRA CUADRADA DE ACERO GRADO', 'KGS', 98, '0.4034872', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (52, 8, '390259612', 'BARRA DE ACERO CUADRADA EST.', 'KGS', 15, '0.3214286', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (53, 8, '39025965', 'BARRA DE ACERO REDONDA GRADO', 'KGS', 68, '0.2317647', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (54, 8, '39026924', 'BARRA DE ACERO REDONDA INOXID.', 'KGS', 15, '0.5402597', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (55, 8, '390259471', 'BARRA DE ACERO REDONDA LISA', 'KGS', 0, '0.1906977', 0, '2012-03-19', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (56, 8, '5904922', 'BARRA DE TIERRA FISICA 6 POSICIONES DE PARED', 'U', 4, 299.3375, 111.0475, '2012-08-22', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (57, 8, '39652418', 'BARRA ESP CILINDRICA 31/64', 'C/U', 2, 1.965, 0, '2005-12-04', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (58, 8, '3963342', 'BARRA PORTA CUCHILLA 1C 1/2', 'C/U', 1, 1.1, 0, '2007-12-27', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (59, 8, '3963344', 'BARRA PORTA CUCHILLA 1C 3/8', 'C/U', 7, '0.9', 0, '2007-12-27', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (60, 8, '3963343', 'BARRA PORTA CUCHILLA 1C 5/16', 'C/U', 1, '0.95', 0, '2007-12-27', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (61, 8, '390259951', 'BARRA RDA. ACERO L/C X12M-8MM', 'KGS', 13, '0.7106061', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (62, 8, '39027612', 'BARRA RDA. ACERO LAM. CALIENTE', 'KGS', 2, '0.5066667', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (63, 8, '39026936', 'BARRA RDA. ALUMINIO DE 45 MM', 'C/U', 1, 7.52, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (64, 8, '3901203', 'BARRA RED 44 MM', 'KGS', 18, '0.1127778', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (65, 8, '39026006', 'BARRA RED. ACERO 1133 41 GDO.', 'KGS', 21, '0.7109524', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (66, 8, '39026003', 'BARRA RED. ACERO 1133-41 GDO.', 'KGS', 262, '0.7144656', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (67, 8, '39025997', 'BARRA RED. ACERO 22 MM X 12 M', 'KGS', 234, '0.7110493', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (68, 8, '39025977', 'BARRA RED. ACERO 30 X MA 56 MM', 'C/U', 3, '0.3615385', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (69, 8, '39026042', 'BARRA RED. ACERO 9 X BG DE', 'KGS', 0, '0.51', 0, '2012-03-20', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (70, 8, '39025995', 'BARRA RED. ACERO ALTA ALEACION', 'KGS', 45, '0.767706', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (71, 8, '39026018', 'BARRA RED. ACERO GRADO 35 25MM', 'KGS', 86, '0.2261072', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (72, 8, '39025998', 'BARRA RED. ACERO GRADO X12M', 'KGS', 77, '0.7109518', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (73, 8, '39026010', 'BARRA RED. ACERO GRADO X12M DE', 'KGS', 106, '0.71109', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (74, 8, '39026045', 'BARRA RED. ACERO HERRAM. DE', 'KGS', 736, '0.5090761', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (75, 8, '39026028', 'BARRA RED. ACERO HTA. A/V', 'KGS', 5, 1.9596154, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (76, 8, '39026017', 'BARRA RED. ACERO HTA. ALEACION', 'KGS', 150, '0.711', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (77, 8, '390259953', 'BARRA RED. ACERO X12M DE 10 MM', 'KGS', 36, '0.7109244', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (78, 8, '39026080', 'BARRA RED. COBRE M 12 DE 45 MM', 'KGS', 70, 1.0608571, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (79, 8, '39026002', 'BARRA RED. DE ACERO GRADO X12M', 'KGS', 142, '0.7109782', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (80, 8, '39025950', 'BARRA REDONDA ACERO 3XP 45 MM', 'KGS', 3, '0.1925926', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (81, 8, '39026037', 'BARRA REDONDA ACERO 9 X B 6 DE', 'KGS', 686, '0.5098614', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (82, 8, '39027611', 'BARRA REDONDA ACERO 9 X B6 DE', 'KGS', 4, '0.5590909', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (83, 8, '390260381', 'BARRA REDONDA ACERO 9 X BG DE', 'KGS', 5, '0.5091803', 0, '2012-03-20', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (84, 8, '390260311', 'BARRA REDONDA ACERO ESTIRADO', 'KGS', 16, '0.290184', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (85, 8, '39027890', 'BARRA REDONDA ACERO LAMINADA', 'KGS', 10, '0.2', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (86, 8, '390259952', 'BARRA REDONDA ACERO LAMINADA', 'KGS', 2, '0.71', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (87, 8, '39026925', 'BARRA REDONDA ACERO LAMINADA', 'KGS', 10, '0.390099', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (88, 8, '39026934', 'BARRA REDONDA ACERO LAMINADO', 'KGS', 9, 2.4576471, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (89, 8, '390260011', 'BARRA REDONDA ACERO LAMINADO', 'KGS', 39, '0.7111688', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (90, 8, '39026926', 'BARRA REDONDA ACERO LAMINADO', 'KGS', 4, '0.3139535', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (91, 8, '39026033', 'BARRA REDONDA ACERO LISA GRADO', 'KGS', 8, '0.1402597', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (92, 8, '39026000', 'BARRA REDONDA ACERO X 124 D324', 'KGS', 196, '0.7110489', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (93, 8, '39026001', 'BARRA REDONDA ACERO X12M 38 MM', 'KGS', 66, '0.7110606', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (94, 8, '39025949', 'BARRA REDONDA LISA GRADO 3KP', 'KGS', 9, '0.1925532', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (95, 8, '19320464', 'BARRA RETENIDA  620M D-52', 'U', 1, 394.79, 3719.95, '2012-06-19', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (96, 8, '19320465', 'BARRA Z 62 M 23782', 'U', 1, 464.84, 4379.95, '2012-06-19', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (97, 8, '19320143', 'BARRA Z UE=4 62 M 21625', 'U', 1, 333.36, 4248.89, '2008-10-14', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (98, 8, '19320471', 'BARRA Z V E 4-62 M', 'U', 1, 557.17, 5249.93, '2012-06-19', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (99, 8, '198806143', 'BARRAALIM.PERRO INTERM.', 'C/U', 7, 2.56, 0, '0000-00-00', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (100, 8, '39026008', 'BARRAS ACERO ALEACION REDONDA', 'KGS', 89, '0.7110862', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (101, 8, '39026009', 'BARRAS ACERO ALEACION REDONDA', 'KGS', 209, '0.7110526', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (102, 8, '39026089', 'BARRAS ACERO CUADRADO X 12 M', 'KGS', 7, 1.3125, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (103, 8, '39025954', 'BARRAS ACERO HERR. ALEACION', 'KGS', 354, '0.4620056', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (104, 8, '39025962', 'BARRAS ACERO RED. EST. FRIO', 'KGS', 36, '0.2098901', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (105, 8, '39025963', 'BARRAS ACERO RED. EST. FRIO', 'KGS', 64, '0.58', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (106, 8, '39025961', 'BARRAS ACERO RED. EST. FRIO', 'KGS', 16, '0.21', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (107, 8, '39026012', 'BARRAS ACERO RED. GDO. X12M DE', 'KGS', 174, '0.7110345', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (108, 8, '39026076', 'BARRAS COBRE RED. CONDICION', 'KGS', 2, '0.91', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (109, 8, '39026078', 'BARRAS COBRE REDONDAS COND.', 'KGS', 25, '0.9099206', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (110, 8, '39026077', 'BARRAS COBRE REDONDAS CONDIC.', 'KGS', 52, '0.91', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (111, 8, '39026052', 'BARRAS CUADRADAS 40 X HMA 106', 'KGS', 22, '0.3830275', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (112, 8, '39026118', 'BARRAS CUADRADAS ACERO HTA.', 'KGS', 481, '0.9800083', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (113, 8, '39026112', 'BARRAS CUADRADAS ACERO HTA.', 'KGS', 6, '0.1310345', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (114, 8, '39026110', 'BARRAS CUADRADAS ACERO HTA. AL', 'KGS', 37, '0.4186486', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (115, 8, '390260001', 'BARRAS DE ACERO REDONDA LAM.', 'KGS', 31, '0.7111475', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (116, 8, '39026074', 'BARRAS PLANCHUELAS MEDIA CAÑA', 'KGS', 69, '0.39', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (117, 8, '3963341', 'BARRAS PORTA CUCHILLA CONO # 4', 'C/U', 1, 1.2, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (118, 8, '3963340', 'BARRAS PORTA CUCHILLA CONO 3', 'C/U', 1, '0.7', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (119, 8, '39025960', 'BARRAS RED. ACERO GDO. 25 50MM', 'KGS', 16, '0.2', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (120, 8, '39026013', 'BARRAS RED. ACERO HTA. ALEAC.', 'KGS', 249, '0.7110619', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (121, 8, '39025964', 'BARRAS REDONDA ACERO LAMINADO', 'KGS', 2, '0.36', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (122, 8, '39025985', 'BARRAS REDONDAS ACERO ALEACION', 'KGS', 299, '0.3620067', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (123, 8, '39025983', 'BARRAS REDONDAS ACERO ALEACION', 'KGS', 46, '0.3619565', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (124, 8, '39026015', 'BARRAS REDONDAS ACERO DE HTA.', 'KGS', 16, '0.71125', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (125, 8, '39026038', 'BARRAS REDONDAS ACERO GDO', 'KGS', 636, '0.5090723', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (126, 8, '39025955', 'BARRAS REDONDAS ACERO GRADO', 'KGS', 82, '0.3900485', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (127, 8, '39026005', 'BARRAS REDONDAS ACERO HTA. DE', 'KGS', 4, '0.71', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (128, 8, '39026014', 'BARRAS REDONDAS ACERO HTA. DE', 'KGS', 326, '0.7110224', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (129, 8, '39026011', 'BARRAS REDONDAS ACERO X12M DE', 'KGS', 216, '0.7110287', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (130, 8, '59332367', 'BUJE BARRA ESTAB LADA', 'C/U', 2, 1.9823077, '0.0507692', '2012-08-28', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (131, 8, '39026391', 'CHOMACERA P/BARRA EXT. DELANT.', 'C/U', 8, 1.71, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (132, 8, '3963452', 'CHUMACERA BARRA MOTRIZ', 'C/U', 1, 133.34, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (133, 8, '3963438', 'CHUMASERA BARRA DELANTERA', 'C/U', 1, 30.1, 0, '2008-12-19', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (134, 8, '39148', 'JAMON BARRA', 'KGS', 0, '0.4285714', 3.5714286, '2012-09-12', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (135, 8, '19148', 'JAMON BARRA', 'KGS', 0, '0.4376771', 3.5878187, '2012-09-14', '12', 'Luis Melian (Comedor)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (136, 8, '99148', 'JAMON BARRA', 'KGS', 0, '0.4400628', 3.5891701, '2012-09-11', '901', 'Comedor');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (137, 8, '198806146', 'MUELLE INTERM.TRASERO BARRA', 'C/U', 38, '0.8344737', 0, '0000-00-00', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (138, 8, '198807893', 'PASADOR BARRA DE DISPARO', 'C/U', 3, 9.26, 0, '0000-00-00', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (139, 8, '198806282', 'PERRO BARRA ALIM.', 'C/U', 12, 26.015, 0, '0000-00-00', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (140, 8, '1988011797', 'PERRO TRASERO BARRA ALIM.', 'C/U', 1, 25.81, 0, '0000-00-00', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (141, 8, '1988013977', 'ROBORTE BARRA ALIM.TRINQUETE', 'C/U', 40, '0.6855', 0, '0000-00-00', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (142, 8, '5934795', 'ROTULA BARRA MANDO', 'U', 0, 3.27, 34.45, '2012-05-27', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (143, 8, '3963330', 'SOP. BARRAS CILINDRICAS 80 MM', 'C/U', 1, '0.9', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (144, 8, '3963257', 'SOP. DE BARRA IZQUIERDO GRANDE', 'C/U', 1, 1.1, 0, '2011-06-21', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (145, 8, '3963338', 'SOP. P/BARRAS RECORTADOR 20 MM', 'C/U', 1, 1.9, 0, '2011-06-21', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (146, 8, '3963258', 'SOP.BARRA RECTO GRANDE', 'C/U', 1, 4.5, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (147, 8, '3963462', 'SOPORTE DE BARRA SOLDADORA', 'C/U', 1, 94.3, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (148, 8, '5934831', 'TERMINAL DERECHO BARRA', 'U', 1, 2.58, 30.665, '2011-06-19', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (149, 8, '5934830', 'TERMINAL IZQUIERDO BARRA', 'U', 1, 2.41, 28.525, '2011-06-19', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (150, 8, '19014889', 'TEXTOLITE EN BARRA', 'KGS', 1, 8.4789474, 0, '2008-03-24', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (151, 8, '3902639815', 'ACERO 4 X 9 CZ DE 28 MM', 'KGS', 2, '0.7888889', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (152, 8, '39026108', 'ACERO CALIBRADO 3 MM', 'KGS', 10, '0.2', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (153, 8, '19819692', 'ACERO CUAD G 45 DIAM 28MM', 'KGS', 12, 126.0201681, 0, '2007-01-22', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (154, 8, '390320026', 'ACERO CUADRADO 9 X 8 G 40 MM', 'KGS', 11, '0.4063636', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (155, 8, '390320029', 'ACERO CUADRADO 9 X 8 G 50 MM', 'KGS', 122, '0.5695902', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (156, 8, '390320050', 'ACERO CUADRADO GR-45 36 MM', 'KGS', 34, '0.2352941', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (157, 8, '390279997', 'ACERO CUADRADO X 12 M 12 MM', 'KGS', 8, 1.3125, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (158, 8, '390279998', 'ACERO CUADRADO X 12 M 16 MM', 'KGS', 19, 1.4745946, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (159, 8, '3902799912', 'ACERO CUADRADO X 12 M 25 MM', 'KGS', 2, '0.8', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (160, 8, '390320010', 'ACERO CUADRADO X12M 32 MM', 'KGS', 3, 1.3111111, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (161, 8, '39032007', 'ACERO CUADRADO X12M 75 X 75 MM', 'KGS', 62, 1.3118506, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (162, 8, '3903200', 'ACERO CUADRADO X12M-100 M-M', 'KGS', 34, 1.3117647, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (163, 8, '390320053', 'ACERO CUADRADO Y-8-A 16 MM', 'KGS', 16, '0.420625', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (164, 8, '390320047', 'ACERO EXAGONAL GR-35 8 MM', 'KGS', 6, '0.2390625', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (165, 8, '390320049', 'ACERO EXAGONAL GR-45 14 MM', 'KGS', 12, '0.2443478', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (166, 8, '390320088', 'ACERO EXAGONAL GR-45 24 MM', 'KGS', 2, '0.4117647', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (167, 8, '19818968', 'ACERO G 20 DIAM  120 MM', 'KGS', 444, '0.2299964', 0, '2007-10-22', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (168, 8, '3902639827', 'ACERO G. S. N. P/CUCHILLAS DE', 'KGS', 8, 1.26, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (169, 8, '3902639830', 'ACERO G. S. N. P/CUCHILLAS DE', 'KGS', 13, 1.26, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (170, 8, '3902639829', 'ACERO G. S. N. P/CUCHILLAS DE', 'KGS', 5, 1.26, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (171, 8, '3902639828', 'ACERO G. S. N. P/CUCHILLAS DE', 'KGS', 7, 1.26, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (172, 8, '3902639831', 'ACERO G. S. N. P/CUCHILLAS DE', 'KGS', 6, 1.26, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (173, 8, '3902639825', 'ACERO G. S. N. P/CUCHILLAS DE', 'KGS', 7, 1.26, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (174, 8, '3902639826', 'ACERO G. S. N. P/CUCHILLAS DE', 'KGS', 10, 1.26, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (175, 8, '3902639824', 'ACERO G. S. N. P/CUCHILLOS DE', 'KGS', 4, 1.26, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (176, 8, '19819259', 'ACERO G-20 DIAM 100 MM', 'KGS', 274, 1.5799949, 0, '2007-10-10', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (177, 8, '3902639823', 'ACERO HALCOMBI 9 1/4X8X1 1/2', 'KGS', 3, 1.26, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (178, 8, '3902639820', 'ACERO HALCOMBI DE 10 3/4X9X2', 'KGS', 7, 2.2, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (179, 8, '3902639821', 'ACERO HALCOMBI DE 11 X 9 X 3', 'KGS', 14, 2.2, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (180, 8, '3902639822', 'ACERO HALCOMBI DE 11X9 1/2X2', 'KGS', 6, 2.2, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (181, 8, '3902639817', 'ACERO HALCOMBI DE 9 1/4 X', 'KGS', 7, 2.2, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (182, 8, '3902639818', 'ACERO HALCOMBI DE 9 5/8 X', 'KGS', 7, 2.2, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (183, 8, '3902639819', 'ACERO HALCOMBI DE 9 5/8 X 8', 'KGS', 8, 2.2, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (184, 8, '390320089', 'ACERO PLANCHUELA 3KP 16 X 50MM', 'KGS', 9, '0.2622222', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (185, 8, '39032009', 'ACERO PLANCHUELA 9 X 8 G', 'KGS', 20, '0.4779412', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (186, 8, '390320030', 'ACERO PLANCHUELA 9 X 8 G', 'KGS', 24, '0.4720833', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (187, 8, '390320021', 'ACERO PLANCHUELA 9 X 8 G', 'KGS', 3, '0.48', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (188, 8, '390320027', 'ACERO PLANCHUELA 9 X 8 G', 'KGS', 3, '0.496', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (189, 8, '390320080', 'ACERO PLANCHUELA GR 6002 8X40', 'KGS', 3, '0.35', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (190, 8, '390320048', 'ACERO PLANCHUELA GR-35 20-200', 'KGS', 14, '0.2364286', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (191, 8, '39032006', 'ACERO PLANCHUELA X12M 40 X 80', 'KGS', 12, '0.5091667', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (192, 8, '39032002', 'ACERO PLANCHUELA X12M-10 X 100', 'KGS', 4, '0.2457143', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (193, 8, '390320055', 'ACERO PLANCHUELA Y 8 A 20 X 80', 'KGS', 16, '0.323125', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (194, 8, '19819694', 'ACERO RED 30  HMA DE DIAM 190M', 'KGS', 37, '0.7379781', 0, '0000-00-00', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (195, 8, '19819042', 'ACERO RED G - 20  DIAM 25 MM', 'KGS', 37, '0.5501216', 0, '2007-01-02', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (196, 8, '19819689', 'ACERO RED X12M X 32MM', 'KGS', 146, 1.2300344, 0, '2007-01-02', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (197, 8, '390320077', 'ACERO RED. CALIBRADO GR B-1', 'KGS', 8, 1.0106667, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (198, 8, '390320082', 'ACERO RED. CSN 38 MM', 'KGS', 20, '0.768', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (199, 8, '39025956', 'ACERO RED. GDO. 40 XC DE 25 MM', 'KGS', 22, '0.3', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (200, 8, '39026036', 'ACERO RED. GDO. 9 X 18 DE 70', 'KGS', 26, '0.5579365', 0, '2012-03-28', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (201, 8, '390320046', 'ACERO RED. GR-35 45 MM', 'KGS', 39, '0.2894872', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (202, 8, '390320076', 'ACERO RED. GRD P-18 20 MM', 'KGS', 6, 2.45, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (203, 8, '390320078', 'ACERO RED. GRD PH8 52 MM', 'KGS', 3, 2.47, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (204, 8, '390320086', 'ACERO RED. POLDI CSN 194343', 'KGS', 212, '0.7375', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (205, 8, '390320041', 'ACERO REDONDO 30 XMA 250 MM', 'KGS', 46, '0.3973913', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (206, 8, '390320037', 'ACERO REDONDO 30 XMA 50 MM', 'KGS', 30, '0.397', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (207, 8, '390320038', 'ACERO REDONDO 30 XMA 56 MM', 'KGS', 94, '0.3626738', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (208, 8, '390320039', 'ACERO REDONDO 30 XMA 60 MM', 'KGS', 22, '0.3622727', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (209, 8, '390320040', 'ACERO REDONDO 30 XMA 70 MM', 'KGS', 78, '0.3113548', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (210, 8, '390320042', 'ACERO REDONDO 61-20-25 MM', 'KGS', 9, '0.0866667', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (211, 8, '39032008', 'ACERO REDONDO 9 X 8 G 10 MM', 'KGS', 29, '0.4208904', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (212, 8, '390320031', 'ACERO REDONDO 9 X 8 G 125 MM', 'KGS', 169, '0.4046154', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (213, 8, '390320035', 'ACERO REDONDO 9 X 8 G 150 MM', 'KGS', 638, '0.5091066', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (214, 8, '390320033', 'ACERO REDONDO 9 X 8 G 180 MM', 'KGS', 228, '0.5090351', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (215, 8, '390320022', 'ACERO REDONDO 9 X 8 G 20 MM', 'KGS', 17, '0.4558824', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (216, 8, '390320034', 'ACERO REDONDO 9 X 8 G 230 MM', 'KGS', 100, '0.2122', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (217, 8, '390320023', 'ACERO REDONDO 9 X 8 G 25 MM', 'KGS', 8, '0.488', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (218, 8, '390320024', 'ACERO REDONDO 9 X 8 G 32 MM', 'KGS', 20, '0.4025', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (219, 8, '390320025', 'ACERO REDONDO 9 X 8 G 35 MM', 'KGS', 13, '0.2366412', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (220, 8, '390320036', 'ACERO REDONDO 9 X 8 G 360 MM', 'KGS', 39, '0.5090909', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (221, 8, '390320052', 'ACERO REDONDO GRD-45 75 MM', 'KGS', 26, '0.24', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (222, 8, '3902799910', 'ACERO REDONDO X 12 M 22 MM', 'KGS', 1, '0.54', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (223, 8, '3902799911', 'ACERO REDONDO X 12 M 25 MM', 'KGS', 45, '0.7368539', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (224, 8, '390320020', 'ACERO REDONDO X12M 100 MM', 'KGS', 344, 1.0364826, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (225, 8, '39032003', 'ACERO REDONDO X12M 120 MM', 'KGS', 120, '0.7110833', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (226, 8, '39032004', 'ACERO REDONDO X12M 140 MM', 'KGS', 6, '0.71', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (227, 8, '390320032', 'ACERO REDONDO X12M 200 MM', 'KGS', 110, '0.4555455', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (228, 8, '39032005', 'ACERO REDONDO X12M 200 MM', 'KGS', 63, '0.7111111', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (229, 8, '390320011', 'ACERO REDONDO X12M 38 MM', 'KGS', 17, '0.7117647', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (230, 8, '390320012', 'ACERO REDONDO X12M 45 MM', 'KGS', 162, '0.3531481', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (231, 8, '390320013', 'ACERO REDONDO X12M 50 MM', 'KGS', 446, '0.7794843', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (232, 8, '390320014', 'ACERO REDONDO X12M 55 MM', 'KGS', 4, '0.7125', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (233, 8, '390320015', 'ACERO REDONDO X12M 60 MM', 'KGS', 46, '0.7119565', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (234, 8, '390320016', 'ACERO REDONDO X12M 65 MM', 'KGS', 49, '0.7410204', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (235, 8, '390320017', 'ACERO REDONDO X12M 70 MM', 'KGS', 30, '0.7125424', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (236, 8, '390320018', 'ACERO REDONDO X12M 75 MM', 'KGS', 56, '0.712234', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (237, 8, '390320019', 'ACERO REDONDO X12M 95 MM', 'KGS', 333, 1.0034535, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (238, 8, '390320043', 'ACERO REDONDO X12M DE 80 MM', 'KGS', 220, '0.6588182', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (239, 8, '39032001', 'ACERO REDONDO X12M-110-M-M', 'KGS', 22, '0.7113636', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (240, 8, '390320054', 'ACERO REDONDO Y 8 A 25 MM', 'KGS', 22, '0.3311628', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (241, 8, '39026117', 'ACERO ROLLDI SSN # 17246 DE', 'KGS', 3, 1.94, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (242, 8, '39025959', 'ACERO X 12 M PLANCHUELA DE', 'KGS', 3, 2.2, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (243, 8, '19819690', 'ACERO X 12M DIAM 60MM', 'KGS', 449, 3.0450071, 0, '2007-10-22', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (244, 8, '19014854', 'ALAMBRE ACERO .26 0.65 MM', 'KGS', 4, '0.4916667', 0, '2005-09-12', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (245, 8, '39027448', 'ALAMBRE ACERO P/HACER MUELLE', 'KGS', 46, '0.2301099', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (246, 8, '39026158', 'ALAMBRE ACERO P/MUELLE LOCZA', 'KGS', 8, '0.7420031', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (247, 8, '19014051', 'ALAMBRE ACERO P/MUELLES .80 MM', 'KGS', 90, '0.1600713', 0, '2005-09-14', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (248, 8, '39027639', 'ALAMBRE ACERO P/MUELLES 1 MM', 'KGS', 14, '0.8702899', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (249, 8, '39026201', 'ALAMBRE ACERO P/MUELLES 60 CAS', 'KGS', 74, '0.8768919', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (250, 8, '390262021', 'ALAMBRE ACERO P/MUELLES CLASE', 'KGS', 64, '0.3399376', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (251, 8, '390261991', 'ALAMBRE ACERO P/MUELLES CLASE', 'KGS', 60, '0.34', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (252, 8, '39027640', 'ALAMBRE ACERO P/MUELLES CLASE', 'KGS', 4, '0.2485714', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (253, 8, '39026200', 'ALAMBRE ACERO P/MUELLES CLASE', 'KGS', 56, '0.241844', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (254, 8, '39026204', 'ALAMBRE ACERO P/MUELLES GR-65', 'KGS', 50, '0.27', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (255, 8, '19014853', 'ALAMBRE DE ACERO .0255', 'KGS', 9, '0.4797872', 0, '2005-09-12', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (256, 8, '1908715', 'ALAMBRE DE ACERO .200 50 MM', 'KGS', 10, '0.1411765', 0, '2005-09-21', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (257, 8, '190557', 'ALAMBRE DE ACERO 0.118 MM', 'KGS', 5, '0.2496164', 0, '2008-04-17', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (258, 8, '19018605', 'ALAMBRE DE ACERO 6.5 SEGUNDA 1 ROLLO', 'TM', 0, 148.6701031, 244.6701031, '2012-04-26', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (259, 8, '1901217', 'ARANDELA PRESION ACERO NEG.3/4', 'C/U', 54, '0.0134848', 0, '2012-02-13', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (260, 8, '19016736', 'BALAS DE ACERO 1 3/4', 'C/U', 5, '0.81', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (261, 8, '39325842', 'BALAS DE ACERO DE 7/16', 'C/U', 11, '0.01', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (262, 8, '19319030', 'BOLA DE ACERO 1/8', 'C/U', 43, '0.0113953', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (263, 8, '19016940', 'BOLAS ACERO 8 MM', 'C/U', 493, '0.01', 0, '2010-10-31', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (264, 8, '19017408', 'BOLAS DE ACERO 1/4', 'C/U', 58, '0.0303448', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (265, 8, '59342292', 'BOLAS DE ACERO 1/8', 'C/U', 28, '0.011', 0, '2009-05-21', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (266, 8, '190195', 'BOLAS DE ACERO DE 10 MM O 3/8\"', 'C/U', 190, '0.01', 0, '2011-10-10', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (267, 8, '190196', 'BOLAS DE ACERO DE 17 X 32', 'C/U', 6, '0.02', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (268, 8, '190198', 'BOLAS DE ACERO DE 3/4', 'C/U', 8, '0.06', 0, '2005-03-31', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (269, 8, '59344137', 'BOLAS DE ACERO DE 3/4', 'C/U', 147, '0.06', 0, '0000-00-00', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (270, 8, '190200', 'BOLAS DE ACERO DE 5/8', 'C/U', 149, '0.0368456', 0, '2006-10-31', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (271, 8, '1964446', 'BROCA ACERO', 'JGO', 2, 1.96, 11.63, '2009-02-12', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (272, 8, '5964446', 'BROCA P/ACERO', 'JGO', 2, 1.96, 11.63, '2009-02-11', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (273, 8, '1905216', 'CABLE DE ACERO BRILLANET 9.1', 'TM', 0, 611.9904077, 0, '2007-11-28', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (274, 8, '5903030', 'CABLE DE ACERO BRILLANTE 9.7MM', 'MTS', 400, '0.099975', 0, '2005-04-30', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (275, 8, '19015904', 'CAPILAR ACERO INOX. Ý EXT.4 MM', 'KGS', 17, 14.5586207, 0, '2004-12-15', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (276, 8, '59010299', 'CERCA PIRLET 1.80 X 10 MALLA ACERO ROLLO', 'U', 6, 11.7, 38.2, '2011-09-27', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (277, 8, '5934482', 'CLAN ACERO LADA', 'JGO', 1, 1.11, 3.38, '2010-06-09', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (278, 8, '59021376', 'CUCHARITA CAFE   ROMA ACERO INX', 'U', 3, '0.1066667', '0.43', '2009-11-27', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (279, 8, '1963686', 'CUCHILLA ACERO 6X6X125', 'C/U', 1, 2.77, 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (280, 8, '39625755', 'DADO DE ROSCAR A MANO ACERO', 'C/U', 1, 1.63, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (281, 8, '39625749', 'DADO DE ROSCAS A MANO ACERO', 'C/U', 1, 1.25, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (282, 8, '59653527', 'DADO MANUAL ACERO  5/16 X 18', 'C/U', 3, '0.72', 0, '0000-00-00', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (283, 8, '396257441', 'DADO RDO. MANUAL ACERO HTA', 'C/U', 2, '0.35', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (284, 8, '39625745', 'DADO RDO. MANUAL ACERO HTA DE', 'C/U', 3, '0.69', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (285, 8, '39625747', 'DADO RDO. MANUAL ACERO HTA. DE', 'C/U', 2, '0.66', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (286, 8, '39625756', 'DADO REDONDO ACERO AL CARBONO', 'C/U', 1, 1.21, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (287, 8, '59653489', 'DADO REDONDO MANUAL ACERO', 'C/U', 2, 1.37, 0, '2009-06-03', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (288, 8, '59653497', 'DADO REDONDO MANUAL ACERO', 'C/U', 5, 1.21, 0, '2011-08-09', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (289, 8, '59653487', 'DADO REDONDO MANUAL-ACERO', 'C/U', 2, '0.52', 0, '2009-06-03', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (290, 8, '3962797711', 'ESPATULA ACERO FLEXIBLE DE 1\"', 'C/U', 2, '0.51', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (291, 8, '39026126', 'FLEJES ACERO 0.5 X 15 MM', 'KGS', 837, '0.3584229', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (292, 8, '396279977', 'FRESA P/ACERO 5 X 25 MM', 'C/U', 1, 4.2, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (293, 8, '19819048', 'G - 45 ACERO DIAM 180', 'KGS', 561, '0.5699841', 0, '2007-12-09', '14', 'Luis Melian (Pzas prefabr)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (294, 8, '396279292', 'MACHO MANUAL ACERO HERR. DE', 'C/U', 2, 4.55, 0, '2005-12-04', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (295, 8, '39625704', 'MACHO MANUAL ACERO HTA 3/4X14', 'JGO', 1, '0.63', 0, '2005-11-23', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (296, 8, '396257181', 'MACHO MANUAL ACERO HTA. 3/4X10', 'JGO', 1, 18.06, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (297, 8, '39627929', 'MACHO MANUAL ACERO HTA. ROSCA', 'C/U', 1, 1.94, 0, '2005-12-04', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (298, 8, '39625715', 'MACHO MANUAL ACERO P/ROSCA JGO 3 PIEZAS', 'C/U', 1, 1.63, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (299, 8, '39625724', 'MACHO MANUAL ACERO P/ROSCA NC JGO 2 PIEZAS', 'C/U', 1, 3.93, 0, '2005-12-04', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (300, 8, '19017837', 'MALLA ACERO 11X13X0.97', 'KGS', 60, '0.5', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (302, 8, '1909284', 'PASADOR ACERO CONICO #10  3\"', 'C/U', 48, '0.375', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (303, 8, '1909274', 'PASADOR ACERO CONICO #2  3\"', 'C/U', 254, '0.1146063', 0, '2006-01-04', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (304, 8, '190388', 'PASADOR ACERO CONICO #7 DE 3\"', 'C/U', 52, '0.1148077', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (305, 8, '1909281', 'PASADOR ACERO CONICO #8 DE 3\"', 'C/U', 103, '0.1148571', 0, '2009-01-27', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (306, 8, '1909283', 'PASADOR ACERO CONICO #9 4\"', 'C/U', 11, '0.1327273', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (307, 8, '39027582', 'PASADORES ABIERTOS ACERO DE', 'C/U', 1, '0.54', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (308, 8, '39027578', 'PASADORES ABIERTOS ACERO DE', 'C/U', 1, '0.69', 0, '2005-12-08', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (309, 8, '39027577', 'PASADORES ABIERTOS ACERO DE', 'KGS', 1, 1.09, 0, '2005-12-08', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (310, 8, '39027579', 'PASADORES ABIERTOS ACERO DE', 'KGS', 1, '0.65', 0, '2005-12-08', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (311, 8, '39027576', 'PASADORES ABIERTOS ACERO DE', 'KGS', 1, 1.12, 0, '2005-12-08', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (312, 8, '39027581', 'PASADORES ABIERTOS ACERO DE', 'C/U', 2, '0.545', 0, '2005-12-08', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (313, 8, '59017143', 'PASADORES ABIERTOS DE ACERO', 'C/U', 700, '0.7086', 0, '2004-12-14', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (314, 8, '1909270', 'PASADORES ACERO CONICO #1 2\"', 'C/U', 130, '0.1133077', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (315, 8, '1909273', 'PASADORES ACERO CONICO #2', 'C/U', 11, '0.1128571', 0, '2012-01-31', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (316, 8, '1909282', 'PASADORES ACERO CONICO #9 3\"', 'C/U', 94, '0.1158511', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (317, 8, '1909269', 'PASADORES DE ACERO CONICO # 1', 'C/U', 48, '0.1152083', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (318, 8, '59010038', 'PERSIANA ACERO GALV 1X400 1X20', 'C/U', 1, 93.59, 0, '2006-10-19', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (319, 8, '5904918', 'PICO DE ACERO COBRIZADO 1.5M', 'u', 4, 69.0425, 21.5725, '2012-08-21', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (320, 8, '19320459', 'PLACA FRIJACION CHAPA ACERO', 'U', 0, 1.415, 2.55, '2012-07-02', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (321, 8, '390260972', 'PLANCHA ACERO GRADO 9 X BG DE', 'KGS', 123, '0.4035772', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (322, 8, '39026048', 'PLANCHA ACERO GRAO 3 KP DE', 'KGS', 322, '0.11', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (323, 8, '39026071', 'PLANCHUELA ACERO 3 KP 12X50 MM', 'KGS', 23, '0.1996', 0, '2012-03-28', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (324, 8, '390276141', 'PLANCHUELA ACERO 9 X B6 DE', 'KGS', 11, '0.56', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (325, 8, '390260973', 'PLANCHUELA ACERO 9 X BG DE', 'KGS', 8, '0.4746988', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (326, 8, '39026067', 'PLANCHUELA ACERO AL CARBONO', 'KGS', 6, '0.2', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (327, 8, '39026051', 'PLANCHUELA ACERO G. 35 DE', 'KGS', 67, '0.2370149', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (328, 8, '390261101', 'PLANCHUELA ACERO LAM. CALIENTE', 'KGS', 0, '0.3397674', 0, '2012-03-28', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (329, 8, '390261102', 'PLANCHUELA ACERO LAM. CALIENTE', 'KGS', 31, '0.3386139', 0, '2012-03-28', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (330, 8, '390261051', 'PLANCHUELA ACERO LAMINADA EN', 'KGS', 50, 1.5350515, 0, '2012-03-28', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (331, 8, '39027895', 'PLANCHUELA ACERO LAMINADA EN', 'KGS', 6, '0.7507937', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (332, 8, '390260971', 'PLANCHUELA ACERO LAVADO 9 X B', 'KGS', 8, '0.675', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (333, 8, '39027758', 'PLANCHUELA DE ACERO', 'C/U', 91, '0.2552486', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (334, 8, '59010058', 'PLANCHUELA DE ACERO', 'TM', 0, 73.6403509, 850.4166667, '2012-05-02', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (335, 8, '39027822', 'PLANCHUELA DE ACERO 9XB6 DE', 'KGS', 6, '0.4032258', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (336, 8, '39027739', 'PLANCHUELA DE ACERO DE 3KP DE', 'KGS', 5, '0.2555556', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (337, 8, '39027220', 'PLANCHUELA DE ACERO GDO. DE', 'KGS', 18, '0.95', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (338, 8, '39027824', 'PLANCHUELA DE ACERO GRADO 45', 'KGS', 108, '0.14', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (339, 8, '39027380', 'PLANCHUELAS ACERO 25.4X6.35 MM', 'KGS', 49, '0.7442387', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (340, 8, '39017912', 'PUNTILLA DE ACERO 2 1/2', 'KGS', 2, '0.488', 2.08, '2012-10-01', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (341, 8, '59017912', 'PUNTILLA DE ACERO 2 1/2', 'KGS', 339, '0.4881896', 2.0801823, '2012-09-18', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (342, 8, '1907161', 'REMACHE ACERO GALV. 1/8 X 3/8', 'C/U', 1176, '0.0020172', 0, '2012-04-08', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (343, 8, '39026729', 'REMACHE ACERO GALV. C/P', 'KGS', 3, '0.7066667', 0, '2005-12-13', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (344, 8, '39026730', 'REMACHE ACERO GALV. C/PLANA', 'KGS', 1, 2.12, 0, '2005-12-07', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (345, 8, '39026734', 'REMACHE ACERO GALV. C/PLANA', 'KGS', 0, '0.8', 0, '2007-11-12', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (346, 8, '39026736', 'REMACHE ACERO GALV. C/PLANA', 'KGS', 2, '0.61', 0, '2011-01-26', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (347, 8, '39026732', 'REMACHES ACERO GALV. C/P DE', 'KGS', 2, '0.88', 0, '2007-02-05', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (348, 8, '39625874', 'RIMAS AJUSTABLES DE MANO ACERO', 'C/U', 1, 3.51, 0, '2005-12-04', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (349, 8, '39625868', 'RIMAS AJUSTABLES DE MANO ACERO', 'C/U', 1, 15.22, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (350, 8, '39625873', 'RIMAS APORTABLES DE MANO ACERO', 'C/U', 2, 3.64, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (351, 8, '19320462', 'RODILLO TAMBOR ACERO', 'U', 0, 1.42, 2.55, '2012-07-02', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (352, 8, '59023202', 'TANQUE ACERO PRECION', 'C/U', 13, 267.0261538, 0, '0000-00-00', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (353, 8, '59021373', 'TENEDOR ACERO INOXIDABLE', 'U', 87, '0.2163218', '0.8702299', '2009-12-08', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (354, 8, '19015847', 'TOR.PRIS.ACERO C/CIL #6 32 H.', 'C/U', 165, '0.0632727', 0, '2005-02-02', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (355, 8, '19010267', 'TORN.PRIS.ACERO C/CIL', 'C/U', 179, '0.0966129', 0, '2011-03-15', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (356, 8, '19015849', 'TORN.PRIS.ACERO C/CILIND 5/32', 'C/U', 301, '0.0565449', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (357, 8, '1907859', 'TORNILLO ACERO PULIDO C/EXAG.', 'C/U', 119, '0.1320168', 0, '2005-04-30', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (358, 8, '1907854', 'TORNILLO ACERO PULIDO C/EXAG.', 'C/U', 346, '0.1077077', 0, '2011-05-31', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (359, 8, '39027259', 'TORNILLO ACERO PULIDO C/EXAG.', 'C/U', 397, '0.0787442', 0, '2012-07-03', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (360, 8, '1907390', 'TORNILLO ACERO PULIDO C/MAQUI.', 'C/U', 600, '0.0166924', 0, '2012-06-25', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (361, 8, '39026532', 'TORNILLO ALLEN ACERO C/CILIND.', 'C/U', 25, '0.04', 0, '2005-12-05', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (362, 8, '39026517', 'TORNILLO ALLEN ACERO CABEZA', 'C/U', 36, '0.0618667', 0, '2012-09-20', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (363, 8, '39026516', 'TORNILLO ALLEN ACERO CABEZA', 'C/U', 178, '0.0603371', 0, '2006-08-20', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (364, 8, '39026515', 'TORNILLO ALLEN DE ACERO CABEZA', 'C/U', 16, '0.03375', 0, '2007-02-18', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (365, 8, '19012003', 'TORNILLO DE ACERO 3/8 X 1 1/4', 'C/U', 120, '0.0528333', 0, '2007-11-18', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (366, 8, '390265511', 'TORNILLO DE MAQUINA DE ACERO', 'C/U', 8, '0.05', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (367, 8, '39026646', 'TORNILLO ESTUFA ACERO GALV.5/16X518', 'C/U', 167, '0.0247904', 0, '2005-12-06', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (368, 8, '39026567', 'TORNILLO MAQ. ACERO C/EXAG.', 'C/U', 17, '0.05', 0, '2005-12-06', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (369, 8, '39026568', 'TORNILLO MAQ. ACERO C/EXAG.', 'C/U', 21, '0.06', 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (370, 8, '39026571', 'TORNILLO MAQ. ACERO C/EXAG.', 'C/U', 26, '0.01', 0, '2005-12-06', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (371, 8, '39026550', 'TORNILLO MAQ. ACERO EXAGONAL', 'C/U', 169, '0.01', 0, '2011-01-05', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (372, 8, '39026654', 'TORNILLO MAQUINA ACERO 3/4 X 5', 'C/U', 11, '0.3063636', 0, '2005-12-06', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (373, 8, '19013365', 'TORNILLO PRIS. ACERO C/CIL.', 'C/U', 39, '0.1538095', 0, '2011-11-14', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (374, 8, '1901156', 'TORNILLO PRIS.ACERO C/C R/STD', 'C/U', 223, '0.155434', 0, '2012-02-14', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (375, 8, '190605', 'TORNILLO PRIS.ACERO CILIND. DE', 'C/U', 25, '0.0568', 0, '0000-00-00', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (376, 8, '1901599', 'TORNILLO PRIS.ACERO EMBUTIR', 'C/U', 220, '0.030913', 0, '2010-06-22', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (377, 8, '19013420', 'TORNILLO PRISIONERO ACERO', 'C/U', 44, '0.05', 0, '2007-01-12', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (378, 8, '39026518', 'TORNILLOS ALLEN DE ACERO', 'C/U', 38, '0.0285714', 0, '2011-01-31', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (379, 8, '39026621', 'TORNILLOS MAQUINA ACERO COMUN', 'C/U', 210, '0.01', 0, '2007-03-21', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (380, 8, '39021408', 'TUBO ACERO DE 1/2', 'U', 0, 4.518, 42.504, '2012-04-16', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (381, 8, '390260356', 'TUBOS ACERO INOXIDABLE 32X1.4', 'KGS', 77, 1.4, 0, '0000-00-00', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (382, 8, '1908779', 'TUERCA ACERO PULIDO ROSCA GRUE', 'C/U', 205, '0.0760408', 0, '2012-04-24', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (383, 8, '39026698', 'TUERCA EXAG. ACERO R/STD 1 1/4', 'C/U', 90, '0.0185556', 0, '2009-09-08', '30', 'Armando Mirabal');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (384, 8, '1901225', 'TUERCA STD. ACERO 5/16\"', 'C/U', 553, '0.0169114', 0, '2012-09-18', '11', 'Luis Melian (Mat Auxiliares)');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (385, 8, '5902211', 'TURBINA 1/4 DE ACERO GALV.', 'KGS', 7, '0.8514286', 0, '0000-00-00', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (386, 8, '5904936', 'ARQUETA REGISTRO 300X300 BARRA TIERRA', 'U', 3, 447.9233333, 187.4033333, '2012-08-22', '5', 'Almacen Central');DELIMITER_SQL
INSERT INTO `maquincost`.`materiales` (`id`, `tiposmateriale_id`, `codigo`, `descripcion`, `um`, `existencia`, `precio_mn`, `precio_mlc`, `fecha_ultima_salida`, `almacen_codigo`, `almacen_desc`) VALUES (387, 8, '59021075', 'NIPLE ACERO GALV 1/4X31/2', 'C/U', 13, 2.063125, 0, '2009-06-03', '5', 'Almacen Central');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for operaciones */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`operaciones`;DELIMITER_SQL

/* Backuping table schema operaciones */
CREATE TABLE `maquincost`.`operaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data operaciones */
INSERT INTO `maquincost`.`operaciones` (`id`, `nombre`) VALUES (1, 'Torneado');DELIMITER_SQL
INSERT INTO `maquincost`.`operaciones` (`id`, `nombre`) VALUES (2, 'Tronzado');DELIMITER_SQL
INSERT INTO `maquincost`.`operaciones` (`id`, `nombre`) VALUES (3, 'Segueteado');DELIMITER_SQL
INSERT INTO `maquincost`.`operaciones` (`id`, `nombre`) VALUES (4, 'Fresado');DELIMITER_SQL
INSERT INTO `maquincost`.`operaciones` (`id`, `nombre`) VALUES (5, 'Refrentado');DELIMITER_SQL
INSERT INTO `maquincost`.`operaciones` (`id`, `nombre`) VALUES (6, 'Ranurado');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for operarios */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`operarios`;DELIMITER_SQL

/* Backuping table schema operarios */
CREATE TABLE `maquincost`.`operarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calificacionoperario_id` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `direcci�n` varchar(255) DEFAULT NULL,
  `ci` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKoperarios689505` (`calificacionoperario_id`),
  CONSTRAINT `operarios_ibfk_1` FOREIGN KEY (`calificacionoperario_id`) REFERENCES `calificacionoperarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data operarios */
INSERT INTO `maquincost`.`operarios` (`id`, `calificacionoperario_id`, `nombre`, `direcci�n`, `ci`) VALUES (1, 1, 'Pepe Antorio Sanchez', 'sdf dfsdfsdf', '2147483647');DELIMITER_SQL
INSERT INTO `maquincost`.`operarios` (`id`, `calificacionoperario_id`, `nombre`, `direcci�n`, `ci`) VALUES (2, 2, 'Ernesto De Agostini', 'Itali', '566555');DELIMITER_SQL
INSERT INTO `maquincost`.`operarios` (`id`, `calificacionoperario_id`, `nombre`, `direcci�n`, `ci`) VALUES (3, 3, 'Jorge Sarmientos Saavedra', 'sdhsdf df', '2859058');DELIMITER_SQL
INSERT INTO `maquincost`.`operarios` (`id`, `calificacionoperario_id`, `nombre`, `direcci�n`, `ci`) VALUES (4, 4, 'Miguel Angel Ortiz', 'sodifysdy f', '569987412');DELIMITER_SQL
INSERT INTO `maquincost`.`operarios` (`id`, `calificacionoperario_id`, `nombre`, `direcci�n`, `ci`) VALUES (5, 14, 'Santiago Conde', 'Guanabacoa', '56051059684');DELIMITER_SQL
INSERT INTO `maquincost`.`operarios` (`id`, `calificacionoperario_id`, `nombre`, `direcci�n`, `ci`) VALUES (6, 15, 'Jorge', 'Luyanó', '59061812635');DELIMITER_SQL
INSERT INTO `maquincost`.`operarios` (`id`, `calificacionoperario_id`, `nombre`, `direcci�n`, `ci`) VALUES (7, 5, 'Manolo Hernández', 'Centro Habana', '89565625803');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for ordenes */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`ordenes`;DELIMITER_SQL

/* Backuping table schema ordenes */
CREATE TABLE `maquincost`.`ordenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `planmensualregistro_id` int(11) DEFAULT NULL,
  `tipotrabajo_id` int(11) NOT NULL,
  `numero` varchar(50) NOT NULL DEFAULT '0000.00.000',
  `planificada` tinyint(1) DEFAULT NULL,
  `cant_piezas` int(11) NOT NULL DEFAULT '0',
  `cant_materiales` int(11) DEFAULT '0',
  `fecha_solicitud` date DEFAULT NULL,
  `hora_solicitud` time DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `laboriosidad` double DEFAULT '0',
  `precio_material` double DEFAULT '0',
  `salario_plan` double DEFAULT '0',
  `tiempo_func_maquinas` double DEFAULT '0',
  `tarifa_proyectista` float NOT NULL DEFAULT '0',
  `tarifa_tecnologo` float NOT NULL DEFAULT '0',
  `tiempo_proyecto` float NOT NULL DEFAULT '0',
  `tiempo_tecnologia` float NOT NULL DEFAULT '0',
  `costo_pieza` float NOT NULL DEFAULT '0',
  `peso_pieza` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `planmensualregistro_id` (`planmensualregistro_id`),
  KEY `tipotrabajo_id` (`tipotrabajo_id`),
  CONSTRAINT `ordenes_ibfk_1` FOREIGN KEY (`planmensualregistro_id`) REFERENCES `planmensualregistros` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ordenes_ibfk_2` FOREIGN KEY (`tipotrabajo_id`) REFERENCES `tipotrabajos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data ordenes */
INSERT INTO `maquincost`.`ordenes` (`id`, `planmensualregistro_id`, `tipotrabajo_id`, `numero`, `planificada`, `cant_piezas`, `cant_materiales`, `fecha_solicitud`, `hora_solicitud`, `fecha_inicio`, `fecha_fin`, `laboriosidad`, `precio_material`, `salario_plan`, `tiempo_func_maquinas`, `tarifa_proyectista`, `tarifa_tecnologo`, `tiempo_proyecto`, `tiempo_tecnologia`, `costo_pieza`, `peso_pieza`) VALUES (2, 2, 2, '2014.04.001', '1', 3, NULL, '2014-05-30', '07:02:00', '2014-05-06', '2014-05-16', 69, 2.5, 32.24, NULL, 1.38, 1.3, 2, 3, 103.428, 104);DELIMITER_SQL
INSERT INTO `maquincost`.`ordenes` (`id`, `planmensualregistro_id`, `tipotrabajo_id`, `numero`, `planificada`, `cant_piezas`, `cant_materiales`, `fecha_solicitud`, `hora_solicitud`, `fecha_inicio`, `fecha_fin`, `laboriosidad`, `precio_material`, `salario_plan`, `tiempo_func_maquinas`, `tarifa_proyectista`, `tarifa_tecnologo`, `tiempo_proyecto`, `tiempo_tecnologia`, `costo_pieza`, `peso_pieza`) VALUES (34, 34, 2, '2014.04.003', '0', 5, 0, '2014-08-21', '05:03:00', '2014-08-03', '2014-08-20', 50, NULL, 1016.8, 0, 3, 2, 45, 436, 1016.8, 4);DELIMITER_SQL
INSERT INTO `maquincost`.`ordenes` (`id`, `planmensualregistro_id`, `tipotrabajo_id`, `numero`, `planificada`, `cant_piezas`, `cant_materiales`, `fecha_solicitud`, `hora_solicitud`, `fecha_inicio`, `fecha_fin`, `laboriosidad`, `precio_material`, `salario_plan`, `tiempo_func_maquinas`, `tarifa_proyectista`, `tarifa_tecnologo`, `tiempo_proyecto`, `tiempo_tecnologia`, `costo_pieza`, `peso_pieza`) VALUES (35, 35, 2, '2014.04.004', '0', 6, 0, '2014-08-11', '17:12:00', '2014-08-14', '2014-08-21', 0, 5, 0, 0, 2, 3, 3, 3, 0, 4);DELIMITER_SQL
INSERT INTO `maquincost`.`ordenes` (`id`, `planmensualregistro_id`, `tipotrabajo_id`, `numero`, `planificada`, `cant_piezas`, `cant_materiales`, `fecha_solicitud`, `hora_solicitud`, `fecha_inicio`, `fecha_fin`, `laboriosidad`, `precio_material`, `salario_plan`, `tiempo_func_maquinas`, `tarifa_proyectista`, `tarifa_tecnologo`, `tiempo_proyecto`, `tiempo_tecnologia`, `costo_pieza`, `peso_pieza`) VALUES (36, 36, 2, '2014.08.001', '1', 5, 0, NULL, NULL, NULL, NULL, 25.649999976158, 0, 5.027399995327, 0, 0, 0, 0, 0, 11.0603, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`ordenes` (`id`, `planmensualregistro_id`, `tipotrabajo_id`, `numero`, `planificada`, `cant_piezas`, `cant_materiales`, `fecha_solicitud`, `hora_solicitud`, `fecha_inicio`, `fecha_fin`, `laboriosidad`, `precio_material`, `salario_plan`, `tiempo_func_maquinas`, `tarifa_proyectista`, `tarifa_tecnologo`, `tiempo_proyecto`, `tiempo_tecnologia`, `costo_pieza`, `peso_pieza`) VALUES (37, 37, 1, '2014.08.002', '1', 4, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for ordenesplanoperarios */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`ordenesplanoperarios`;DELIMITER_SQL

/* Backuping table schema ordenesplanoperarios */
CREATE TABLE `maquincost`.`ordenesplanoperarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordene_id` int(11) NOT NULL,
  `operario_id` int(11) NOT NULL,
  `cartasordene_id` int(11) NOT NULL,
  `horas` float NOT NULL,
  `tarifa` float NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_terminacion` date NOT NULL,
  `otros_tiempos` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `operario_id` (`operario_id`),
  KEY `ordene_id` (`ordene_id`),
  KEY `cartasordene_id` (`cartasordene_id`),
  CONSTRAINT `ordenesplanoperarios_ibfk_1` FOREIGN KEY (`ordene_id`) REFERENCES `ordenes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ordenesplanoperarios_ibfk_2` FOREIGN KEY (`operario_id`) REFERENCES `operarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ordenesplanoperarios_ibfk_3` FOREIGN KEY (`cartasordene_id`) REFERENCES `cartasordenes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;DELIMITER_SQL

/* Backuping table data ordenesplanoperarios */
INSERT INTO `maquincost`.`ordenesplanoperarios` (`id`, `ordene_id`, `operario_id`, `cartasordene_id`, `horas`, `tarifa`, `fecha_inicio`, `fecha_terminacion`, `otros_tiempos`) VALUES (1, 2, 4, 82, 4, 1.14, '2014-05-08', '2014-05-30', 15);DELIMITER_SQL
INSERT INTO `maquincost`.`ordenesplanoperarios` (`id`, `ordene_id`, `operario_id`, `cartasordene_id`, `horas`, `tarifa`, `fecha_inicio`, `fecha_terminacion`, `otros_tiempos`) VALUES (2, 2, 1, 89, 0, '0.98', '2014-05-14', '2014-05-23', 4);DELIMITER_SQL
INSERT INTO `maquincost`.`ordenesplanoperarios` (`id`, `ordene_id`, `operario_id`, `cartasordene_id`, `horas`, `tarifa`, `fecha_inicio`, `fecha_terminacion`, `otros_tiempos`) VALUES (4, 34, 1, 101, 4, '0.98', '2014-08-02', '2014-08-29', 6);DELIMITER_SQL
INSERT INTO `maquincost`.`ordenesplanoperarios` (`id`, `ordene_id`, `operario_id`, `cartasordene_id`, `horas`, `tarifa`, `fecha_inicio`, `fecha_terminacion`, `otros_tiempos`) VALUES (5, 36, 1, 106, '0.13', '0.98', '2014-08-14', '2014-08-29', 5);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for ordenreals */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`ordenreals`;DELIMITER_SQL

/* Backuping table schema ordenreals */
CREATE TABLE `maquincost`.`ordenreals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordene_id` int(11) DEFAULT NULL,
  `materiale_id` int(11) NOT NULL,
  `tipotrabajo_id` int(11) NOT NULL,
  `piezas_elaboradas` int(11) DEFAULT NULL,
  `gasto_materiales` float DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `hora_inicio` time DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `hora_fin` time DEFAULT NULL,
  `fecha_cierre` date DEFAULT NULL,
  `consumo_salario` double DEFAULT NULL,
  `cerrada` tinyint(1) NOT NULL,
  `pieza_costo_unit` float NOT NULL DEFAULT '0',
  `mat_prim_peso_unit` float NOT NULL DEFAULT '0',
  `pieza_peso_unit` int(11) NOT NULL DEFAULT '0',
  `ueb` varchar(100) DEFAULT NULL,
  `responsable` varchar(50) DEFAULT NULL,
  `equipo` varchar(80) DEFAULT NULL,
  `precio_material` float NOT NULL DEFAULT '0',
  `pieza_precio` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FKordenreals902801` (`ordene_id`),
  KEY `materiale_id` (`materiale_id`),
  KEY `tipotrabajo_id` (`tipotrabajo_id`),
  CONSTRAINT `ordenreals_ibfk_1` FOREIGN KEY (`ordene_id`) REFERENCES `ordenes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ordenreals_ibfk_2` FOREIGN KEY (`materiale_id`) REFERENCES `materiales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data ordenreals */
INSERT INTO `maquincost`.`ordenreals` (`id`, `ordene_id`, `materiale_id`, `tipotrabajo_id`, `piezas_elaboradas`, `gasto_materiales`, `fecha_inicio`, `hora_inicio`, `fecha_fin`, `hora_fin`, `fecha_cierre`, `consumo_salario`, `cerrada`, `pieza_costo_unit`, `mat_prim_peso_unit`, `pieza_peso_unit`, `ueb`, `responsable`, `equipo`, `precio_material`, `pieza_precio`) VALUES (2, 2, 237, 1, 2, 68.3288, '2014-05-13', '17:03:00', '2014-05-06', '22:00:00', '2014-10-15', 26.72, '1', 47.5244, 15, 11, 'Luis Melián', 'Julio Alonso Fimias', 'Soucan 650', 2, 152.319);DELIMITER_SQL
INSERT INTO `maquincost`.`ordenreals` (`id`, `ordene_id`, `materiale_id`, `tipotrabajo_id`, `piezas_elaboradas`, `gasto_materiales`, `fecha_inicio`, `hora_inicio`, `fecha_fin`, `hora_fin`, `fecha_cierre`, `consumo_salario`, `cerrada`, `pieza_costo_unit`, `mat_prim_peso_unit`, `pieza_peso_unit`, `ueb`, `responsable`, `equipo`, `precio_material`, `pieza_precio`) VALUES (21, 34, 87, 2, 5, 11.7464, '2014-08-20', '00:00:00', '2014-08-20', '00:00:00', '2014-09-22', 7.84, '0', 3.91728, 4, 4, '', '', '', '0.390099', 3.4499120792);DELIMITER_SQL
INSERT INTO `maquincost`.`ordenreals` (`id`, `ordene_id`, `materiale_id`, `tipotrabajo_id`, `piezas_elaboradas`, `gasto_materiales`, `fecha_inicio`, `hora_inicio`, `fecha_fin`, `hora_fin`, `fecha_cierre`, `consumo_salario`, `cerrada`, `pieza_costo_unit`, `mat_prim_peso_unit`, `pieza_peso_unit`, `ueb`, `responsable`, `equipo`, `precio_material`, `pieza_precio`) VALUES (25, 35, 328, 2, 8, 0, '2014-08-20', '00:00:00', '2014-08-20', '00:00:00', '2014-09-22', 3.92, '1', '0.49', 0, 0, '', '', '', 0, 1.078);DELIMITER_SQL
INSERT INTO `maquincost`.`ordenreals` (`id`, `ordene_id`, `materiale_id`, `tipotrabajo_id`, `piezas_elaboradas`, `gasto_materiales`, `fecha_inicio`, `hora_inicio`, `fecha_fin`, `hora_fin`, `fecha_cierre`, `consumo_salario`, `cerrada`, `pieza_costo_unit`, `mat_prim_peso_unit`, `pieza_peso_unit`, `ueb`, `responsable`, `equipo`, `precio_material`, `pieza_precio`) VALUES (28, 36, 165, 2, 3, 0, '2014-08-20', '00:00:00', '2014-08-20', '00:00:00', '2014-10-15', 0, '1', 0, 0, 0, '', '', '', 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`ordenreals` (`id`, `ordene_id`, `materiale_id`, `tipotrabajo_id`, `piezas_elaboradas`, `gasto_materiales`, `fecha_inicio`, `hora_inicio`, `fecha_fin`, `hora_fin`, `fecha_cierre`, `consumo_salario`, `cerrada`, `pieza_costo_unit`, `mat_prim_peso_unit`, `pieza_peso_unit`, `ueb`, `responsable`, `equipo`, `precio_material`, `pieza_precio`) VALUES (29, 37, 151, 1, 0, 0, '2014-08-20', '00:00:00', '2014-08-20', '00:00:00', NULL, 0, '0', 0, 0, 0, '', '', '', 0, 0);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for piezas */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`piezas`;DELIMITER_SQL

/* Backuping table schema piezas */
CREATE TABLE `maquincost`.`piezas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `imagen` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data piezas */
INSERT INTO `maquincost`.`piezas` (`id`, `nombre`, `imagen`) VALUES (3, 'Eje cilíndrico', 'part8.jpg');DELIMITER_SQL
INSERT INTO `maquincost`.`piezas` (`id`, `nombre`, `imagen`) VALUES (4, 'T de Soporte', 'part19.jpg');DELIMITER_SQL
INSERT INTO `maquincost`.`piezas` (`id`, `nombre`, `imagen`) VALUES (5, 'Buje', 'part18.jpg');DELIMITER_SQL
INSERT INTO `maquincost`.`piezas` (`id`, `nombre`, `imagen`) VALUES (6, 'Anillo', 'part4.jpg');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for piezasmaterialesordenes */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`piezasmaterialesordenes`;DELIMITER_SQL

/* Backuping table schema piezasmaterialesordenes */
CREATE TABLE `maquincost`.`piezasmaterialesordenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordenreal_id` int(11) DEFAULT NULL,
  `vale_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKpiezasmate827723` (`ordenreal_id`),
  KEY `FKpiezasmate781996` (`vale_id`),
  CONSTRAINT `piezasmaterialesordenes_ibfk_1` FOREIGN KEY (`ordenreal_id`) REFERENCES `ordenreals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `piezasmaterialesordenes_ibfk_2` FOREIGN KEY (`vale_id`) REFERENCES `vales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data piezasmaterialesordenes */
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for plananualregistros */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`plananualregistros`;DELIMITER_SQL

/* Backuping table schema plananualregistros */
CREATE TABLE `maquincost`.`plananualregistros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `planesanuale_id` int(11) NOT NULL,
  `pieza_id` int(11) DEFAULT NULL,
  `materiale_id` int(11) DEFAULT NULL,
  `numeroplano` int(11) DEFAULT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `no_molde_disp_etc` varchar(100) DEFAULT NULL,
  `cantpiezas` int(11) DEFAULT NULL,
  `matprim_pesounidad` double DEFAULT NULL,
  `matprim_pesototal` double DEFAULT NULL,
  `pieza_pesotunidad` double DEFAULT NULL,
  `pieza_pesototal` double DEFAULT NULL,
  `matprima_largo` double DEFAULT NULL,
  `matprima_ancho` double DEFAULT NULL,
  `costounidad` double DEFAULT NULL,
  `costototal` double DEFAULT NULL,
  `fecha_necesita` date DEFAULT NULL,
  `fecha_recibe` date DEFAULT NULL,
  `observaciones` varchar(230) DEFAULT NULL,
  `planificada` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FKplanesanua721913` (`materiale_id`),
  KEY `pieza_id` (`pieza_id`),
  KEY `planesanuale_id` (`planesanuale_id`),
  CONSTRAINT `plananualregistros_ibfk_1` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `plananualregistros_ibfk_2` FOREIGN KEY (`materiale_id`) REFERENCES `materiales` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `plananualregistros_ibfk_3` FOREIGN KEY (`planesanuale_id`) REFERENCES `planesanuales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data plananualregistros */
INSERT INTO `maquincost`.`plananualregistros` (`id`, `planesanuale_id`, `pieza_id`, `materiale_id`, `numeroplano`, `modelo`, `no_molde_disp_etc`, `cantpiezas`, `matprim_pesounidad`, `matprim_pesototal`, `pieza_pesotunidad`, `pieza_pesototal`, `matprima_largo`, `matprima_ancho`, `costounidad`, `costototal`, `fecha_necesita`, `fecha_recibe`, `observaciones`, `planificada`) VALUES (22, 7, 3, 1, 54456, '6', '56456456', 566, 456456, 43, 5654, 546, 456, 456, 45, 17, '2014-04-02', '2014-04-29', 'gfh gh hfgh g hh', 1);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for planesanuales */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`planesanuales`;DELIMITER_SQL

/* Backuping table schema planesanuales */
CREATE TABLE `maquincost`.`planesanuales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anno` int(11) NOT NULL,
  `empresa` varchar(100) DEFAULT NULL,
  `taller` varchar(100) DEFAULT NULL,
  `fecha_elaboracion` date DEFAULT NULL,
  `planificada` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;DELIMITER_SQL

/* Backuping table data planesanuales */
INSERT INTO `maquincost`.`planesanuales` (`id`, `anno`, `empresa`, `taller`, `fecha_elaboracion`, `planificada`) VALUES (7, 2014, 'ENVOOC', 'AM', '2014-04-21', 1);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for planesmensuales */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`planesmensuales`;DELIMITER_SQL

/* Backuping table schema planesmensuales */
CREATE TABLE `maquincost`.`planesmensuales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anno` int(11) NOT NULL,
  `mes` int(11) NOT NULL,
  `empresa` varchar(100) DEFAULT NULL,
  `taller` varchar(100) DEFAULT NULL,
  `fecha_elaboracion` date DEFAULT NULL,
  `planificada` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;DELIMITER_SQL

/* Backuping table data planesmensuales */
INSERT INTO `maquincost`.`planesmensuales` (`id`, `anno`, `mes`, `empresa`, `taller`, `fecha_elaboracion`, `planificada`) VALUES (10, 2014, 4, 'ENVOCC', 'AM', '2014-08-09', 1);DELIMITER_SQL
INSERT INTO `maquincost`.`planesmensuales` (`id`, `anno`, `mes`, `empresa`, `taller`, `fecha_elaboracion`, `planificada`) VALUES (16, 0, 0, '', '', NULL, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`planesmensuales` (`id`, `anno`, `mes`, `empresa`, `taller`, `fecha_elaboracion`, `planificada`) VALUES (17, 2014, 8, 'ENVOCC', 'AM', '2014-08-20', 1);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for planmensualregistros */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`planmensualregistros`;DELIMITER_SQL

/* Backuping table schema planmensualregistros */
CREATE TABLE `maquincost`.`planmensualregistros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `planesmensuale_id` int(11) NOT NULL,
  `pieza_id` int(11) DEFAULT NULL,
  `materiale_id` int(11) DEFAULT NULL,
  `cantpiezas` int(11) DEFAULT NULL,
  `costounidad` double DEFAULT NULL,
  `costototal` double DEFAULT NULL,
  `matprim_pesounidad` double DEFAULT NULL,
  `matprim_pesototal` float DEFAULT NULL,
  `pieza_pesounidad` float NOT NULL,
  `pieza_pesototal` float NOT NULL,
  `matprim_ancho` double DEFAULT NULL,
  `matprim_largo` double DEFAULT NULL,
  `observaciones` varchar(200) DEFAULT NULL,
  `planificada` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FKplanesmens604445` (`materiale_id`),
  KEY `pieza_id` (`pieza_id`),
  KEY `planesmensuale_id` (`planesmensuale_id`),
  CONSTRAINT `FKplanesmens604445` FOREIGN KEY (`materiale_id`) REFERENCES `materiales` (`id`),
  CONSTRAINT `planmensualregistros_ibfk_1` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`),
  CONSTRAINT `planmensualregistros_ibfk_2` FOREIGN KEY (`planesmensuale_id`) REFERENCES `planesmensuales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data planmensualregistros */
INSERT INTO `maquincost`.`planmensualregistros` (`id`, `planesmensuale_id`, `pieza_id`, `materiale_id`, `cantpiezas`, `costounidad`, `costototal`, `matprim_pesounidad`, `matprim_pesototal`, `pieza_pesounidad`, `pieza_pesototal`, `matprim_ancho`, `matprim_largo`, `observaciones`, `planificada`) VALUES (2, 10, 3, 342, 3, 0, 0, 4, 24, 3, 18, 5, 4, 'fthfghfg hfgh fg hf h', 1);DELIMITER_SQL
INSERT INTO `maquincost`.`planmensualregistros` (`id`, `planesmensuale_id`, `pieza_id`, `materiale_id`, `cantpiezas`, `costounidad`, `costototal`, `matprim_pesounidad`, `matprim_pesototal`, `pieza_pesounidad`, `pieza_pesototal`, `matprim_ancho`, `matprim_largo`, `observaciones`, `planificada`) VALUES (34, 16, 3, 87, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, '', 0);DELIMITER_SQL
INSERT INTO `maquincost`.`planmensualregistros` (`id`, `planesmensuale_id`, `pieza_id`, `materiale_id`, `cantpiezas`, `costounidad`, `costototal`, `matprim_pesounidad`, `matprim_pesototal`, `pieza_pesounidad`, `pieza_pesototal`, `matprim_ancho`, `matprim_largo`, `observaciones`, `planificada`) VALUES (35, 16, 4, 328, 6, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, '', 0);DELIMITER_SQL
INSERT INTO `maquincost`.`planmensualregistros` (`id`, `planesmensuale_id`, `pieza_id`, `materiale_id`, `cantpiezas`, `costounidad`, `costototal`, `matprim_pesounidad`, `matprim_pesototal`, `pieza_pesounidad`, `pieza_pesototal`, `matprim_ancho`, `matprim_largo`, `observaciones`, `planificada`) VALUES (36, 17, 6, 165, 5, 0, 0, 4, 20, 5, 25, 4, 4, 'fghghgfh', 1);DELIMITER_SQL
INSERT INTO `maquincost`.`planmensualregistros` (`id`, `planesmensuale_id`, `pieza_id`, `materiale_id`, `cantpiezas`, `costounidad`, `costototal`, `matprim_pesounidad`, `matprim_pesototal`, `pieza_pesounidad`, `pieza_pesototal`, `matprim_ancho`, `matprim_largo`, `observaciones`, `planificada`) VALUES (37, 17, 6, 151, 4, 0, 0, 4, 16, 4, 16, 3, 3, '', 1);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for profcortes */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`profcortes`;DELIMITER_SQL

/* Backuping table schema profcortes */
CREATE TABLE `maquincost`.`profcortes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `selectore_id` int(11) NOT NULL,
  `profcorte` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `selectore_id` (`selectore_id`),
  CONSTRAINT `profcortes_ibfk_1` FOREIGN KEY (`selectore_id`) REFERENCES `selectores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;DELIMITER_SQL

/* Backuping table data profcortes */
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (1, 19, 82);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (3, 19, 42);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (4, 2, 65);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (5, 5, 22);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (6, 7, 5);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (7, 16, 78);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (8, 17, 454);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (10, 19, 12);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (11, 26, '0.018');DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (16, 25, 6456);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (17, 13, 6);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (18, 5, 455);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (19, 19, 754);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (20, 19, 6);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (21, 5, 46);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (22, 5, 745);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (23, 2, 6);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (24, 2, 745);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (25, 2, 45);DELIMITER_SQL
INSERT INTO `maquincost`.`profcortes` (`id`, `selectore_id`, `profcorte`) VALUES (26, 13, 78);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for selectores */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`selectores`;DELIMITER_SQL

/* Backuping table schema selectores */
CREATE TABLE `maquincost`.`selectores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `velocidadrango_id` int(11) DEFAULT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKselectores391540` (`velocidadrango_id`),
  CONSTRAINT `selectores_ibfk_1` FOREIGN KEY (`velocidadrango_id`) REFERENCES `velocidadrangos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data selectores */
INSERT INTO `maquincost`.`selectores` (`id`, `velocidadrango_id`, `nombre`) VALUES (2, 9, '1/8');DELIMITER_SQL
INSERT INTO `maquincost`.`selectores` (`id`, `velocidadrango_id`, `nombre`) VALUES (5, 9, '1/4');DELIMITER_SQL
INSERT INTO `maquincost`.`selectores` (`id`, `velocidadrango_id`, `nombre`) VALUES (7, 19, '1/2');DELIMITER_SQL
INSERT INTO `maquincost`.`selectores` (`id`, `velocidadrango_id`, `nombre`) VALUES (13, 11, '1/2');DELIMITER_SQL
INSERT INTO `maquincost`.`selectores` (`id`, `velocidadrango_id`, `nombre`) VALUES (16, 19, '1/4');DELIMITER_SQL
INSERT INTO `maquincost`.`selectores` (`id`, `velocidadrango_id`, `nombre`) VALUES (17, 19, '2/2');DELIMITER_SQL
INSERT INTO `maquincost`.`selectores` (`id`, `velocidadrango_id`, `nombre`) VALUES (19, 9, '1/2');DELIMITER_SQL
INSERT INTO `maquincost`.`selectores` (`id`, `velocidadrango_id`, `nombre`) VALUES (20, 6, '1/2');DELIMITER_SQL
INSERT INTO `maquincost`.`selectores` (`id`, `velocidadrango_id`, `nombre`) VALUES (22, 24, '1/2');DELIMITER_SQL
INSERT INTO `maquincost`.`selectores` (`id`, `velocidadrango_id`, `nombre`) VALUES (25, 25, '1/2');DELIMITER_SQL
INSERT INTO `maquincost`.`selectores` (`id`, `velocidadrango_id`, `nombre`) VALUES (26, 26, '1/2');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for semiproductoformas */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`semiproductoformas`;DELIMITER_SQL

/* Backuping table schema semiproductoformas */
CREATE TABLE `maquincost`.`semiproductoformas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data semiproductoformas */
INSERT INTO `maquincost`.`semiproductoformas` (`id`, `nombre`) VALUES (1, 'Cilindro');DELIMITER_SQL
INSERT INTO `maquincost`.`semiproductoformas` (`id`, `nombre`) VALUES (2, 'Cubo');DELIMITER_SQL
INSERT INTO `maquincost`.`semiproductoformas` (`id`, `nombre`) VALUES (5, 'Barra redonda');DELIMITER_SQL
INSERT INTO `maquincost`.`semiproductoformas` (`id`, `nombre`) VALUES (8, 'Esfera');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for tiemposauxiliares */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`tiemposauxiliares`;DELIMITER_SQL

/* Backuping table schema tiemposauxiliares */
CREATE TABLE `maquincost`.`tiemposauxiliares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tiempo` double NOT NULL DEFAULT '0',
  `descripcion` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;DELIMITER_SQL

/* Backuping table data tiemposauxiliares */
INSERT INTO `maquincost`.`tiemposauxiliares` (`id`, `tiempo`, `descripcion`) VALUES (1, 1.5, 'Ajuste del torno');DELIMITER_SQL
INSERT INTO `maquincost`.`tiemposauxiliares` (`id`, `tiempo`, `descripcion`) VALUES (3, 3, 'Acoplamiento de la pieza');DELIMITER_SQL
INSERT INTO `maquincost`.`tiemposauxiliares` (`id`, `tiempo`, `descripcion`) VALUES (4, 1, 'Rectificar mediciones');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for tiemposmaquinadoreales */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`tiemposmaquinadoreales`;DELIMITER_SQL

/* Backuping table schema tiemposmaquinadoreales */
CREATE TABLE `maquincost`.`tiemposmaquinadoreales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordenreal_id` int(11) NOT NULL,
  `maquina_id` int(11) NOT NULL,
  `tiempo_auxiliar` float NOT NULL,
  `tiempo_corte` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ordenreal_id` (`ordenreal_id`),
  KEY `maquina_id` (`maquina_id`),
  CONSTRAINT `tiemposmaquinadoreales_ibfk_1` FOREIGN KEY (`ordenreal_id`) REFERENCES `ordenreals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tiemposmaquinadoreales_ibfk_2` FOREIGN KEY (`maquina_id`) REFERENCES `maquinas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;DELIMITER_SQL

/* Backuping table data tiemposmaquinadoreales */
INSERT INTO `maquincost`.`tiemposmaquinadoreales` (`id`, `ordenreal_id`, `maquina_id`, `tiempo_auxiliar`, `tiempo_corte`) VALUES (7, 2, 3, 60, 50);DELIMITER_SQL
INSERT INTO `maquincost`.`tiemposmaquinadoreales` (`id`, `ordenreal_id`, `maquina_id`, `tiempo_auxiliar`, `tiempo_corte`) VALUES (8, 2, 1, 5, 4);DELIMITER_SQL
INSERT INTO `maquincost`.`tiemposmaquinadoreales` (`id`, `ordenreal_id`, `maquina_id`, `tiempo_auxiliar`, `tiempo_corte`) VALUES (9, 2, 10, 6, 6);DELIMITER_SQL
INSERT INTO `maquincost`.`tiemposmaquinadoreales` (`id`, `ordenreal_id`, `maquina_id`, `tiempo_auxiliar`, `tiempo_corte`) VALUES (15, 2, 1, 5, 4);DELIMITER_SQL
INSERT INTO `maquincost`.`tiemposmaquinadoreales` (`id`, `ordenreal_id`, `maquina_id`, `tiempo_auxiliar`, `tiempo_corte`) VALUES (18, 21, 1, 3, 4);DELIMITER_SQL
INSERT INTO `maquincost`.`tiemposmaquinadoreales` (`id`, `ordenreal_id`, `maquina_id`, `tiempo_auxiliar`, `tiempo_corte`) VALUES (19, 25, 1, 5, 4);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for tipoelementoscortante */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`tipoelementoscortante`;DELIMITER_SQL

/* Backuping table schema tipoelementoscortante */
CREATE TABLE `maquincost`.`tipoelementoscortante` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data tipoelementoscortante */
INSERT INTO `maquincost`.`tipoelementoscortante` (`id`, `nombre`) VALUES (1, 'Barrena');DELIMITER_SQL
INSERT INTO `maquincost`.`tipoelementoscortante` (`id`, `nombre`) VALUES (2, 'Cuchilla');DELIMITER_SQL
INSERT INTO `maquincost`.`tipoelementoscortante` (`id`, `nombre`) VALUES (3, 'Fresa');DELIMITER_SQL
INSERT INTO `maquincost`.`tipoelementoscortante` (`id`, `nombre`) VALUES (4, 'Segueta');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for tipooperaciones */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`tipooperaciones`;DELIMITER_SQL

/* Backuping table schema tipooperaciones */
CREATE TABLE `maquincost`.`tipooperaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data tipooperaciones */
INSERT INTO `maquincost`.`tipooperaciones` (`id`, `nombre`) VALUES (1, 'Desbaste');DELIMITER_SQL
INSERT INTO `maquincost`.`tipooperaciones` (`id`, `nombre`) VALUES (2, 'Afinado');DELIMITER_SQL
INSERT INTO `maquincost`.`tipooperaciones` (`id`, `nombre`) VALUES (3, 'Viruta');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for tiposmateriales */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`tiposmateriales`;DELIMITER_SQL

/* Backuping table schema tiposmateriales */
CREATE TABLE `maquincost`.`tiposmateriales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agrupadormateriale_id` int(11) DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `resistencia_min` double DEFAULT NULL,
  `resistencia_max` double DEFAULT NULL,
  `um` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKtiposmater192179` (`agrupadormateriale_id`),
  CONSTRAINT `tiposmateriales_ibfk_1` FOREIGN KEY (`agrupadormateriale_id`) REFERENCES `agrupadormateriales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data tiposmateriales */
INSERT INTO `maquincost`.`tiposmateriales` (`id`, `agrupadormateriale_id`, `nombre`, `resistencia_min`, `resistencia_max`, `um`) VALUES (1, 1, 'Acero', 50, 60, 'kg/mm2 ');DELIMITER_SQL
INSERT INTO `maquincost`.`tiposmateriales` (`id`, `agrupadormateriale_id`, `nombre`, `resistencia_min`, `resistencia_max`, `um`) VALUES (2, 2, 'Acero', 60, 70, 'kg/mm2');DELIMITER_SQL
INSERT INTO `maquincost`.`tiposmateriales` (`id`, `agrupadormateriale_id`, `nombre`, `resistencia_min`, `resistencia_max`, `um`) VALUES (3, 3, 'Acero', 70, 80, 'kg/mm2 ');DELIMITER_SQL
INSERT INTO `maquincost`.`tiposmateriales` (`id`, `agrupadormateriale_id`, `nombre`, `resistencia_min`, `resistencia_max`, `um`) VALUES (4, 4, 'Bronce', NULL, NULL, '');DELIMITER_SQL
INSERT INTO `maquincost`.`tiposmateriales` (`id`, `agrupadormateriale_id`, `nombre`, `resistencia_min`, `resistencia_max`, `um`) VALUES (5, 6, 'Aluminio', 50, 100, 'kg/mm2 ');DELIMITER_SQL
INSERT INTO `maquincost`.`tiposmateriales` (`id`, `agrupadormateriale_id`, `nombre`, `resistencia_min`, `resistencia_max`, `um`) VALUES (6, 1, 'Acero', 10, 20, 'kg/mm2 ');DELIMITER_SQL
INSERT INTO `maquincost`.`tiposmateriales` (`id`, `agrupadormateriale_id`, `nombre`, `resistencia_min`, `resistencia_max`, `um`) VALUES (7, 1, 'Acero duro al 12 % de manganeso', NULL, NULL, '');DELIMITER_SQL
INSERT INTO `maquincost`.`tiposmateriales` (`id`, `agrupadormateriale_id`, `nombre`, `resistencia_min`, `resistencia_max`, `um`) VALUES (8, 5, 'Indefinido', NULL, NULL, '');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for tipotrabajos */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`tipotrabajos`;DELIMITER_SQL

/* Backuping table schema tipotrabajos */
CREATE TABLE `maquincost`.`tipotrabajos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;DELIMITER_SQL

/* Backuping table data tipotrabajos */
INSERT INTO `maquincost`.`tipotrabajos` (`id`, `descripcion`) VALUES (1, 'Recuperación de piezas');DELIMITER_SQL
INSERT INTO `maquincost`.`tipotrabajos` (`id`, `descripcion`) VALUES (2, 'Construcción de piezas');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for tipousuarios */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`tipousuarios`;DELIMITER_SQL

/* Backuping table schema tipousuarios */
CREATE TABLE `maquincost`.`tipousuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nivel` int(11) DEFAULT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data tipousuarios */
INSERT INTO `maquincost`.`tipousuarios` (`id`, `nivel`, `descripcion`) VALUES (1, 1, 'Administrador');DELIMITER_SQL
INSERT INTO `maquincost`.`tipousuarios` (`id`, `nivel`, `descripcion`) VALUES (2, 2, 'Tecnólogo');DELIMITER_SQL
INSERT INTO `maquincost`.`tipousuarios` (`id`, `nivel`, `descripcion`) VALUES (3, 3, 'Jefe de Mantenimiento');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for users */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`users`;DELIMITER_SQL

/* Backuping table schema users */
CREATE TABLE `maquincost`.`users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipousuario_id` int(11) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nombre_completo` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKusers429433` (`tipousuario_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`tipousuario_id`) REFERENCES `tipousuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data users */
INSERT INTO `maquincost`.`users` (`id`, `tipousuario_id`, `username`, `password`, `nombre_completo`) VALUES (1, 1, 'Administrador', 'c3291dc078915c69122fc9a0e5690078f5092c17', 'Administrador del sistema');DELIMITER_SQL
INSERT INTO `maquincost`.`users` (`id`, `tipousuario_id`, `username`, `password`, `nombre_completo`) VALUES (2, 2, 'Tecnologo', '00213fbc3aece0fd0e724e1aa2c27f217f27f3ff', 'Tecnologo');DELIMITER_SQL
INSERT INTO `maquincost`.`users` (`id`, `tipousuario_id`, `username`, `password`, `nombre_completo`) VALUES (4, 3, 'JMantenimiento', 'de9aa8a9294709f048e3b4bd1e4b18e38615e946', 'Pedro');DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for vales */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`vales`;DELIMITER_SQL

/* Backuping table schema vales */
CREATE TABLE `maquincost`.`vales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `materiale_id` int(11) DEFAULT NULL,
  `ordenreal_id` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `unidades` varchar(50) DEFAULT NULL,
  `precio` float NOT NULL,
  `importe` double DEFAULT NULL,
  `no_solicitud` varchar(25) DEFAULT NULL,
  `no_salida` varchar(25) DEFAULT NULL,
  `fecha_solicitud` date DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKvales82471` (`materiale_id`),
  KEY `ordenreal_id` (`ordenreal_id`),
  CONSTRAINT `FKvales82471` FOREIGN KEY (`materiale_id`) REFERENCES `materiales` (`id`),
  CONSTRAINT `vales_ibfk_1` FOREIGN KEY (`ordenreal_id`) REFERENCES `ordenreals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data vales */
INSERT INTO `maquincost`.`vales` (`id`, `materiale_id`, `ordenreal_id`, `cantidad`, `unidades`, `precio`, `importe`, `no_solicitud`, `no_salida`, `fecha_solicitud`, `fecha_salida`) VALUES (12, 76, 2, 8, '', '0.711', 5.688, '5345', '345', NULL, NULL);DELIMITER_SQL
INSERT INTO `maquincost`.`vales` (`id`, `materiale_id`, `ordenreal_id`, `cantidad`, `unidades`, `precio`, `importe`, `no_solicitud`, `no_salida`, `fecha_solicitud`, `fecha_salida`) VALUES (13, 253, 2, 4, '', '0.241844', '0.967376', '354', '54', NULL, NULL);DELIMITER_SQL
INSERT INTO `maquincost`.`vales` (`id`, `materiale_id`, `ordenreal_id`, `cantidad`, `unidades`, `precio`, `importe`, `no_solicitud`, `no_salida`, `fecha_solicitud`, `fecha_salida`) VALUES (14, 164, 2, 7, '', '0.239063', 1.6734375, '355', '35', NULL, NULL);DELIMITER_SQL
INSERT INTO `maquincost`.`vales` (`id`, `materiale_id`, `ordenreal_id`, `cantidad`, `unidades`, `precio`, `importe`, `no_solicitud`, `no_salida`, `fecha_solicitud`, `fecha_salida`) VALUES (16, 151, 21, 5, '', '0.788889', 3.9444445, '56456', '5645', NULL, NULL);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for velocidades */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`velocidades`;DELIMITER_SQL

/* Backuping table schema velocidades */
CREATE TABLE `maquincost`.`velocidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `velocidadrango_id` int(11) DEFAULT NULL,
  `velocidad` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKvelocidade319580` (`velocidadrango_id`),
  CONSTRAINT `velocidades_ibfk_1` FOREIGN KEY (`velocidadrango_id`) REFERENCES `velocidadrangos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data velocidades */
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (3, 9, 345);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (4, 9, 56);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (6, 9, 37);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (7, 9, 74);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (10, 9, 57);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (13, 9, 45);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (20, 19, 405);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (21, 9, 634);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (22, 9, 46);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (24, 9, 546);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (25, 9, 500);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (27, 9, 354);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (30, 11, 89);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (31, 9, 100);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (32, 19, 342);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (33, 11, 120);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (34, 11, 259);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (35, 19, 100);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (36, 11, 789);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (39, 11, 34);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (41, 19, 34);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (47, 19, 8);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (50, 9, 16);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (51, 6, 23);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (53, 9, 10);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (54, 24, 345);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (56, 25, 86);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (57, 19, 200);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (59, 26, 23);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (61, 9, 262);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (62, 9, 45);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (63, 9, 35);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (64, 9, 64);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (65, 9, 565);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidades` (`id`, `velocidadrango_id`, `velocidad`) VALUES (67, 9, 456);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for velocidadrangos */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`velocidadrangos`;DELIMITER_SQL

/* Backuping table schema velocidadrangos */
CREATE TABLE `maquincost`.`velocidadrangos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maquina_id` int(11) DEFAULT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `vel_min` double DEFAULT NULL,
  `vel_max` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKvelocidadr20738` (`maquina_id`),
  CONSTRAINT `velocidadrangos_ibfk_1` FOREIGN KEY (`maquina_id`) REFERENCES `maquinas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data velocidadrangos */
INSERT INTO `maquincost`.`velocidadrangos` (`id`, `maquina_id`, `nombre`, `vel_min`, `vel_max`) VALUES (6, 2, 'I', 100, 200);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidadrangos` (`id`, `maquina_id`, `nombre`, `vel_min`, `vel_max`) VALUES (9, 1, 'I', 10, 70);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidadrangos` (`id`, `maquina_id`, `nombre`, `vel_min`, `vel_max`) VALUES (11, 1, 'III', 150, 210);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidadrangos` (`id`, `maquina_id`, `nombre`, `vel_min`, `vel_max`) VALUES (15, 2, 'II', 120, 244);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidadrangos` (`id`, `maquina_id`, `nombre`, `vel_min`, `vel_max`) VALUES (16, 2, 'III', 250, 365);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidadrangos` (`id`, `maquina_id`, `nombre`, `vel_min`, `vel_max`) VALUES (19, 1, 'II', 70, 150);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidadrangos` (`id`, `maquina_id`, `nombre`, `vel_min`, `vel_max`) VALUES (24, 2, 'IV', 561, 741);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidadrangos` (`id`, `maquina_id`, `nombre`, `vel_min`, `vel_max`) VALUES (25, 3, 'I', 56, 184);DELIMITER_SQL
INSERT INTO `maquincost`.`velocidadrangos` (`id`, `maquina_id`, `nombre`, `vel_min`, `vel_max`) VALUES (26, 7, 'I', 54, 98);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL

/* Drop statement for vpcamaterialeselementoscortantes */
SET foreign_key_checks = 0;DELIMITER_SQL
DROP TABLE IF EXISTS `maquincost`.`vpcamaterialeselementoscortantes`;DELIMITER_SQL

/* Backuping table schema vpcamaterialeselementoscortantes */
CREATE TABLE `maquincost`.`vpcamaterialeselementoscortantes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tiposmateriale_id` int(11) DEFAULT NULL,
  `elementocortanteoperacione_id` int(11) NOT NULL,
  `vel_min_viruta` double DEFAULT NULL,
  `vel_max_viruta` double DEFAULT NULL,
  `av_min_viruta` double DEFAULT NULL,
  `av_max_viruta` double DEFAULT NULL,
  `pfc_min_viruta` double DEFAULT NULL,
  `pfc_max_viruta` double DEFAULT NULL,
  `vel_min_desbaste` double DEFAULT NULL,
  `vel_max_desbaste` double DEFAULT NULL,
  `av_min_desbaste` double DEFAULT NULL,
  `av_max_desbaste` double DEFAULT NULL,
  `pfc_min_desbaste` double DEFAULT NULL,
  `pfc_max_desbaste` double DEFAULT NULL,
  `vel_min_afinar` double DEFAULT NULL,
  `vel_max_afinar` double DEFAULT NULL,
  `av_min_afinar` double DEFAULT NULL,
  `av_max_afinar` double DEFAULT NULL,
  `pfc_min_afinar` double DEFAULT NULL,
  `pfc_max_afinar` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKvpcamateri378306` (`tiposmateriale_id`),
  KEY `elementocortanteoperacione_id` (`elementocortanteoperacione_id`),
  CONSTRAINT `vpcamaterialeselementoscortantes_ibfk_2` FOREIGN KEY (`tiposmateriale_id`) REFERENCES `tiposmateriales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `vpcamaterialeselementoscortantes_ibfk_3` FOREIGN KEY (`elementocortanteoperacione_id`) REFERENCES `elementocortanteoperaciones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;DELIMITER_SQL

/* Backuping table data vpcamaterialeselementoscortantes */
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (4, 6, 21, 345, 345, 45, 345, 5, 53, 35, 35, 35, 35, 35, 353, 345, 35, 345, 35, 35, 35);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (7, 1, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (10, 1, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (11, 2, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (12, 2, 25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (13, 6, 25, 0, 0, 4, 0, 0, 0, 0, 45, 0, 0, 45, 0, 45, 0, 12, 56, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (14, 6, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (15, 6, 26, 0, 0, 0, 0, 0, 0, 0, 5464, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (16, 1, 25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (17, 7, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (18, 6, 22, 0, 0, 0, 0, 0, 0, 0, 45, 0, 0, 0, 0, 0, 0, 54, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (19, 1, 22, 535, 0, 535, 35, 5345, 3, 30355, 353, 15, 345, 5, 35, 0, 0, 345, 15345, 54, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (21, 6, 12, 18, 236, 91, 455, 160, 35, 10, 52, 21, 90, 84, 110, 2, 1000, 1, 2000, 3, 509);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (22, 6, 19, 345, 800, 0, 50, 0, 1000, 0, 60, 0, 50, 0, 70, 0, 529, 0, 45, 0, 234);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (23, 1, 21, 0, 0, 0, 466, 0, 0, 644, 46, 0, 0, 0, 0, 0, 6, 0, 0, 436, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (24, 3, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (25, 3, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (26, 3, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (27, 2, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (28, 6, 27, 4660, 0, 0, 0, 46, 646, 0, 445, 64, 0, 0, 46, 0, 0, 5446, 56, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (29, 4, 19, 0, 0, 0, 0, 0, 0, 3, 2, 3, 3, 2, 2, 4, 4, 5, 4, 3, 3);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (30, 4, 12, 0, 0, 0, 0, 0, 0, 2, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
INSERT INTO `maquincost`.`vpcamaterialeselementoscortantes` (`id`, `tiposmateriale_id`, `elementocortanteoperacione_id`, `vel_min_viruta`, `vel_max_viruta`, `av_min_viruta`, `av_max_viruta`, `pfc_min_viruta`, `pfc_max_viruta`, `vel_min_desbaste`, `vel_max_desbaste`, `av_min_desbaste`, `av_max_desbaste`, `pfc_min_desbaste`, `pfc_max_desbaste`, `vel_min_afinar`, `vel_max_afinar`, `av_min_afinar`, `av_max_afinar`, `pfc_min_afinar`, `pfc_max_afinar`) VALUES (31, 4, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);DELIMITER_SQL
SET foreign_key_checks = 1;DELIMITER_SQL
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;DELIMITER_SQL
                                /*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;DELIMITER_SQL
                                /*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;DELIMITER_SQL