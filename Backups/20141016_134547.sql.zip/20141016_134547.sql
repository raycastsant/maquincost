begin Agrupadormateriale
A I;;20
begin Tiposmateriale
startRDAcero;;startRD50;;startRD60;;startRDkg/mm2 endRD
begin Materiale
startRD390279996;;startRDACERO BARRA REDONDA X 12 M 12;;startRDKGS;;startRD30;;startRD0.7053333;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
end Materiale
startRDAcero;;startRD10;;startRD20;;startRDkg/mm2 endRD
begin Materiale
end Materiale
startRDAcero duro al 12 % de manganeso;;startRD;;startRD;;startRDendRD
begin Materiale
end Materiale
end Tiposmateriale

A II;;12
begin Tiposmateriale
startRDAcero;;startRD60;;startRD70;;startRDkg/mm2endRD
begin Materiale
end Materiale
end Tiposmateriale

A III;;89
begin Tiposmateriale
startRDAcero;;startRD70;;startRD80;;startRDkg/mm2 endRD
begin Materiale
end Materiale
end Tiposmateriale

Bronces;;54
begin Tiposmateriale
startRDBronce;;startRD;;startRD;;startRDendRD
begin Materiale
end Materiale
end Tiposmateriale

Indefinido;;0
begin Tiposmateriale
startRDIndefinido;;startRD;;startRD;;startRDendRD
begin Materiale
startRD19819696;;startRDBARRA AC G 35 DE DIAM 40MM;;startRDKGS;;startRD251;;startRD2.16;;startRD0;;startRD2007-01-22;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD390259821;;startRDBARRA ACERO 30 X MA DE 90 MM;;startRDKGS;;startRD71;;startRD0.36;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027865;;startRDBARRA ACERO 9 X B6 DE 40 MM;;startRDKGS;;startRD57;;startRD0.24;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025996;;startRDBARRA ACERO ALEACION RED. GDO.;;startRDKGS;;startRD28;;startRD0.7107143;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025999;;startRDBARRA ACERO ALEACION REDONDA;;startRDKGS;;startRD171;;startRD0.7110397;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027963;;startRDBARRA ACERO CUAD. 9 X BG DE 60;;startRDKGS;;startRD77;;startRD0.4035065;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260211;;startRDBARRA ACERO CUAD. GRADO 45 DE;;startRDKGS;;startRD16;;startRD0.32125;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027881;;startRDBARRA ACERO CUAD. GRADO 45 DE;;startRDKGS;;startRD11;;startRD0.3281818;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027964;;startRDBARRA ACERO CUADRADA ALEACION;;startRDKGS;;startRD31;;startRD0.4032787;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026115;;startRDBARRA ACERO CUADRADA ESTIRADA;;startRDKGS;;startRD7;;startRD0.2307692;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026116;;startRDBARRA ACERO CUADRADA ESTIRADA;;startRDKGS;;startRD75;;startRD0.2305333;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260931;;startRDBARRA ACERO CUADRADA GDO X 12M;;startRDKGS;;startRD5;;startRD1.3111111;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026093;;startRDBARRA ACERO CUADRADA LMDA CTE;;startRDKGS;;startRD31;;startRD0.8;;startRD0;;startRD2012-03-28;;startRD30;;startRDArmando MirabalendRD
startRD390260264;;startRDBARRA ACERO EXAGONAL C/CSN;;startRDKGS;;startRD3;;startRD0.2666667;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260262;;startRDBARRA ACERO EXAGONAL ESTIRADA;;startRDKGS;;startRD20;;startRD0.27;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027894;;startRDBARRA ACERO GRADO 35 DE 13 MM;;startRDKGS;;startRD9;;startRD0.227907;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027893;;startRDBARRA ACERO GRADO 35 DE 42 MM;;startRDKGS;;startRD8;;startRD0.22875;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026007;;startRDBARRA ACERO HTA. GRADO X12M DE;;startRDKGS;;startRD106;;startRD0.7109641;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026035;;startRDBARRA ACERO INOXIDABLE REDONDA;;startRDKGS;;startRD4;;startRD1.8085714;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026923;;startRDBARRA ACERO INOXIDABLE -X17H13;;startRDKGS;;startRD34;;startRD1.1813609;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260263;;startRDBARRA ACERO RDA. ESTIRADO FRIO;;startRDKGS;;startRD80;;startRD0.3700249;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260471;;startRDBARRA ACERO RDA. LAM. CAL. GDO;;startRDKGS;;startRD1211;;startRD0.5090669;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260472;;startRDBARRA ACERO RDA. LAM. EN CAL.;;startRDKGS;;startRD2823;;startRD0.5090719;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026024;;startRDBARRA ACERO RDA. LISA ESTIRADO;;startRDKGS;;startRD102;;startRD0.5700195;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027732;;startRDBARRA ACERO RED. 9XBG DE 50 MM;;startRDKGS;;startRD40;;startRD0.4939547;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027327;;startRDBARRA ACERO RED. GDO. 40XH2MA;;startRDKGS;;startRD36;;startRD0.3141667;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260251;;startRDBARRA ACERO RED. GRADO 20 DE;;startRDKGS;;startRD6;;startRD0.2310345;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027381;;startRDBARRA ACERO RED. GRADO 20 X DE;;startRDC/U;;startRD31;;startRD0.3891803;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390259721;;startRDBARRA ACERO RED. GRADO 45 65MM;;startRDKGS;;startRD42;;startRD0.2309524;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027965;;startRDBARRA ACERO RED. GRADO 45 DE;;startRDKGS;;startRD54;;startRD0.2318519;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025970;;startRDBARRA ACERO RED. GRADO 45 DE;;startRDKGS;;startRD37;;startRD0.2318801;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260473;;startRDBARRA ACERO RED. HERR. GRADO;;startRDKGS;;startRD393;;startRD0.5090585;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026026;;startRDBARRA ACERO REDONDA E/FRIO GDO;;startRDKGS;;startRD235;;startRD0.2100128;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390279811;;startRDBARRA ACERO REDONDA EST. FRIO;;startRDKGS;;startRD101;;startRD0.2099606;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260151;;startRDBARRA ACERO REDONDA GDO X12M;;startRDKGS;;startRD152;;startRD0.7110526;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026032;;startRDBARRA ACERO REDONDA GDO. C T 3;;startRDKGS;;startRD11;;startRD0.1927273;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025966;;startRDBARRA ACERO REDONDA GRADO 45;;startRDKGS;;startRD4;;startRD0.2318182;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390259691;;startRDBARRA ACERO REDONDA GRADO 45;;startRDKGS;;startRD69;;startRD0.2317391;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026004;;startRDBARRA ACERO X 12 DE 55 MM;;startRDKGS;;startRD212;;startRD0.7110165;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD198105948;;startRDBARRA ALIM.IZQ.U�A DEL.;;startRDC/U;;startRD1;;startRD7.09;;startRD0;;startRD0000-00-00;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD198806144;;startRDBARRA ALIM.PERRO DEL.;;startRDC/U;;startRD5;;startRD4.03;;startRD0;;startRD0000-00-00;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD39027613;;startRDBARRA CUAD. ACERO LAMINADA EN;;startRDKGS;;startRD55;;startRD0.5600365;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025969;;startRDBARRA CUADRADA ACERO EST. FRIO;;startRDKGS;;startRD15;;startRD0.5281879;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026031;;startRDBARRA CUADRADA ACERO GDO. 35;;startRDKGS;;startRD58;;startRD0.3210345;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390259611;;startRDBARRA CUADRADA ACERO GDO. 35;;startRDKGS;;startRD51;;startRD0.3219802;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390278911;;startRDBARRA CUADRADA ACERO GRADO 45;;startRDKGS;;startRD41;;startRD0.2303704;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026109;;startRDBARRA CUADRADA ACERO LAMINADO;;startRDKGS;;startRD15;;startRD0.4187919;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026114;;startRDBARRA CUADRADA ACERO STD. DE;;startRDKGS;;startRD4;;startRD0.1906977;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026090;;startRDBARRA CUADRADA DE ACERO GRADO;;startRDKGS;;startRD98;;startRD0.4034872;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390259612;;startRDBARRA DE ACERO CUADRADA EST.;;startRDKGS;;startRD15;;startRD0.3214286;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025965;;startRDBARRA DE ACERO REDONDA GRADO;;startRDKGS;;startRD68;;startRD0.2317647;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026924;;startRDBARRA DE ACERO REDONDA INOXID.;;startRDKGS;;startRD15;;startRD0.5402597;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390259471;;startRDBARRA DE ACERO REDONDA LISA;;startRDKGS;;startRD0;;startRD0.1906977;;startRD0;;startRD2012-03-19;;startRD30;;startRDArmando MirabalendRD
startRD5904922;;startRDBARRA DE TIERRA FISICA 6 POSICIONES DE PARED;;startRDU;;startRD4;;startRD299.3375;;startRD111.0475;;startRD2012-08-22;;startRD5;;startRDAlmacen CentralendRD
startRD39652418;;startRDBARRA ESP CILINDRICA 31/64;;startRDC/U;;startRD2;;startRD1.965;;startRD0;;startRD2005-12-04;;startRD30;;startRDArmando MirabalendRD
startRD3963342;;startRDBARRA PORTA CUCHILLA 1C 1/2;;startRDC/U;;startRD1;;startRD1.1;;startRD0;;startRD2007-12-27;;startRD30;;startRDArmando MirabalendRD
startRD3963344;;startRDBARRA PORTA CUCHILLA 1C 3/8;;startRDC/U;;startRD7;;startRD0.9;;startRD0;;startRD2007-12-27;;startRD30;;startRDArmando MirabalendRD
startRD3963343;;startRDBARRA PORTA CUCHILLA 1C 5/16;;startRDC/U;;startRD1;;startRD0.95;;startRD0;;startRD2007-12-27;;startRD30;;startRDArmando MirabalendRD
startRD390259951;;startRDBARRA RDA. ACERO L/C X12M-8MM;;startRDKGS;;startRD13;;startRD0.7106061;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027612;;startRDBARRA RDA. ACERO LAM. CALIENTE;;startRDKGS;;startRD2;;startRD0.5066667;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026936;;startRDBARRA RDA. ALUMINIO DE 45 MM;;startRDC/U;;startRD1;;startRD7.52;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3901203;;startRDBARRA RED 44 MM;;startRDKGS;;startRD18;;startRD0.1127778;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026006;;startRDBARRA RED. ACERO 1133 41 GDO.;;startRDKGS;;startRD21;;startRD0.7109524;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026003;;startRDBARRA RED. ACERO 1133-41 GDO.;;startRDKGS;;startRD262;;startRD0.7144656;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025997;;startRDBARRA RED. ACERO 22 MM X 12 M;;startRDKGS;;startRD234;;startRD0.7110493;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025977;;startRDBARRA RED. ACERO 30 X MA 56 MM;;startRDC/U;;startRD3;;startRD0.3615385;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026042;;startRDBARRA RED. ACERO 9 X BG DE;;startRDKGS;;startRD0;;startRD0.51;;startRD0;;startRD2012-03-20;;startRD30;;startRDArmando MirabalendRD
startRD39025995;;startRDBARRA RED. ACERO ALTA ALEACION;;startRDKGS;;startRD45;;startRD0.767706;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026018;;startRDBARRA RED. ACERO GRADO 35 25MM;;startRDKGS;;startRD86;;startRD0.2261072;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025998;;startRDBARRA RED. ACERO GRADO X12M;;startRDKGS;;startRD77;;startRD0.7109518;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026010;;startRDBARRA RED. ACERO GRADO X12M DE;;startRDKGS;;startRD106;;startRD0.71109;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026045;;startRDBARRA RED. ACERO HERRAM. DE;;startRDKGS;;startRD736;;startRD0.5090761;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026028;;startRDBARRA RED. ACERO HTA. A/V;;startRDKGS;;startRD5;;startRD1.9596154;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026017;;startRDBARRA RED. ACERO HTA. ALEACION;;startRDKGS;;startRD150;;startRD0.711;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390259953;;startRDBARRA RED. ACERO X12M DE 10 MM;;startRDKGS;;startRD36;;startRD0.7109244;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026080;;startRDBARRA RED. COBRE M 12 DE 45 MM;;startRDKGS;;startRD70;;startRD1.0608571;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026002;;startRDBARRA RED. DE ACERO GRADO X12M;;startRDKGS;;startRD142;;startRD0.7109782;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025950;;startRDBARRA REDONDA ACERO 3XP 45 MM;;startRDKGS;;startRD3;;startRD0.1925926;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026037;;startRDBARRA REDONDA ACERO 9 X B 6 DE;;startRDKGS;;startRD686;;startRD0.5098614;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027611;;startRDBARRA REDONDA ACERO 9 X B6 DE;;startRDKGS;;startRD4;;startRD0.5590909;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260381;;startRDBARRA REDONDA ACERO 9 X BG DE;;startRDKGS;;startRD5;;startRD0.5091803;;startRD0;;startRD2012-03-20;;startRD30;;startRDArmando MirabalendRD
startRD390260311;;startRDBARRA REDONDA ACERO ESTIRADO;;startRDKGS;;startRD16;;startRD0.290184;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027890;;startRDBARRA REDONDA ACERO LAMINADA;;startRDKGS;;startRD10;;startRD0.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390259952;;startRDBARRA REDONDA ACERO LAMINADA;;startRDKGS;;startRD2;;startRD0.71;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026925;;startRDBARRA REDONDA ACERO LAMINADA;;startRDKGS;;startRD10;;startRD0.390099;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026934;;startRDBARRA REDONDA ACERO LAMINADO;;startRDKGS;;startRD9;;startRD2.4576471;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260011;;startRDBARRA REDONDA ACERO LAMINADO;;startRDKGS;;startRD39;;startRD0.7111688;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026926;;startRDBARRA REDONDA ACERO LAMINADO;;startRDKGS;;startRD4;;startRD0.3139535;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026033;;startRDBARRA REDONDA ACERO LISA GRADO;;startRDKGS;;startRD8;;startRD0.1402597;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026000;;startRDBARRA REDONDA ACERO X 124 D324;;startRDKGS;;startRD196;;startRD0.7110489;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026001;;startRDBARRA REDONDA ACERO X12M 38 MM;;startRDKGS;;startRD66;;startRD0.7110606;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025949;;startRDBARRA REDONDA LISA GRADO 3KP;;startRDKGS;;startRD9;;startRD0.1925532;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD19320464;;startRDBARRA RETENIDA  620M D-52;;startRDU;;startRD1;;startRD394.79;;startRD3719.95;;startRD2012-06-19;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD19320465;;startRDBARRA Z 62 M 23782;;startRDU;;startRD1;;startRD464.84;;startRD4379.95;;startRD2012-06-19;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD19320143;;startRDBARRA Z UE=4 62 M 21625;;startRDU;;startRD1;;startRD333.36;;startRD4248.89;;startRD2008-10-14;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD19320471;;startRDBARRA Z V E 4-62 M;;startRDU;;startRD1;;startRD557.17;;startRD5249.93;;startRD2012-06-19;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD198806143;;startRDBARRAALIM.PERRO INTERM.;;startRDC/U;;startRD7;;startRD2.56;;startRD0;;startRD0000-00-00;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD39026008;;startRDBARRAS ACERO ALEACION REDONDA;;startRDKGS;;startRD89;;startRD0.7110862;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026009;;startRDBARRAS ACERO ALEACION REDONDA;;startRDKGS;;startRD209;;startRD0.7110526;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026089;;startRDBARRAS ACERO CUADRADO X 12 M;;startRDKGS;;startRD7;;startRD1.3125;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025954;;startRDBARRAS ACERO HERR. ALEACION;;startRDKGS;;startRD354;;startRD0.4620056;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025962;;startRDBARRAS ACERO RED. EST. FRIO;;startRDKGS;;startRD36;;startRD0.2098901;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025963;;startRDBARRAS ACERO RED. EST. FRIO;;startRDKGS;;startRD64;;startRD0.58;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025961;;startRDBARRAS ACERO RED. EST. FRIO;;startRDKGS;;startRD16;;startRD0.21;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026012;;startRDBARRAS ACERO RED. GDO. X12M DE;;startRDKGS;;startRD174;;startRD0.7110345;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026076;;startRDBARRAS COBRE RED. CONDICION;;startRDKGS;;startRD2;;startRD0.91;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026078;;startRDBARRAS COBRE REDONDAS COND.;;startRDKGS;;startRD25;;startRD0.9099206;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026077;;startRDBARRAS COBRE REDONDAS CONDIC.;;startRDKGS;;startRD52;;startRD0.91;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026052;;startRDBARRAS CUADRADAS 40 X HMA 106;;startRDKGS;;startRD22;;startRD0.3830275;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026118;;startRDBARRAS CUADRADAS ACERO HTA.;;startRDKGS;;startRD481;;startRD0.9800083;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026112;;startRDBARRAS CUADRADAS ACERO HTA.;;startRDKGS;;startRD6;;startRD0.1310345;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026110;;startRDBARRAS CUADRADAS ACERO HTA. AL;;startRDKGS;;startRD37;;startRD0.4186486;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260001;;startRDBARRAS DE ACERO REDONDA LAM.;;startRDKGS;;startRD31;;startRD0.7111475;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026074;;startRDBARRAS PLANCHUELAS MEDIA CA�A;;startRDKGS;;startRD69;;startRD0.39;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3963341;;startRDBARRAS PORTA CUCHILLA CONO # 4;;startRDC/U;;startRD1;;startRD1.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3963340;;startRDBARRAS PORTA CUCHILLA CONO 3;;startRDC/U;;startRD1;;startRD0.7;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025960;;startRDBARRAS RED. ACERO GDO. 25 50MM;;startRDKGS;;startRD16;;startRD0.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026013;;startRDBARRAS RED. ACERO HTA. ALEAC.;;startRDKGS;;startRD249;;startRD0.7110619;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025964;;startRDBARRAS REDONDA ACERO LAMINADO;;startRDKGS;;startRD2;;startRD0.36;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025985;;startRDBARRAS REDONDAS ACERO ALEACION;;startRDKGS;;startRD299;;startRD0.3620067;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025983;;startRDBARRAS REDONDAS ACERO ALEACION;;startRDKGS;;startRD46;;startRD0.3619565;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026015;;startRDBARRAS REDONDAS ACERO DE HTA.;;startRDKGS;;startRD16;;startRD0.71125;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026038;;startRDBARRAS REDONDAS ACERO GDO;;startRDKGS;;startRD636;;startRD0.5090723;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025955;;startRDBARRAS REDONDAS ACERO GRADO;;startRDKGS;;startRD82;;startRD0.3900485;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026005;;startRDBARRAS REDONDAS ACERO HTA. DE;;startRDKGS;;startRD4;;startRD0.71;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026014;;startRDBARRAS REDONDAS ACERO HTA. DE;;startRDKGS;;startRD326;;startRD0.7110224;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026011;;startRDBARRAS REDONDAS ACERO X12M DE;;startRDKGS;;startRD216;;startRD0.7110287;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD59332367;;startRDBUJE BARRA ESTAB LADA;;startRDC/U;;startRD2;;startRD1.9823077;;startRD0.0507692;;startRD2012-08-28;;startRD5;;startRDAlmacen CentralendRD
startRD39026391;;startRDCHOMACERA P/BARRA EXT. DELANT.;;startRDC/U;;startRD8;;startRD1.71;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3963452;;startRDCHUMACERA BARRA MOTRIZ;;startRDC/U;;startRD1;;startRD133.34;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3963438;;startRDCHUMASERA BARRA DELANTERA;;startRDC/U;;startRD1;;startRD30.1;;startRD0;;startRD2008-12-19;;startRD30;;startRDArmando MirabalendRD
startRD39148;;startRDJAMON BARRA;;startRDKGS;;startRD0;;startRD0.4285714;;startRD3.5714286;;startRD2012-09-12;;startRD30;;startRDArmando MirabalendRD
startRD19148;;startRDJAMON BARRA;;startRDKGS;;startRD0;;startRD0.4376771;;startRD3.5878187;;startRD2012-09-14;;startRD12;;startRDLuis Melian (Comedor)endRD
startRD99148;;startRDJAMON BARRA;;startRDKGS;;startRD0;;startRD0.4400628;;startRD3.5891701;;startRD2012-09-11;;startRD901;;startRDComedorendRD
startRD198806146;;startRDMUELLE INTERM.TRASERO BARRA;;startRDC/U;;startRD38;;startRD0.8344737;;startRD0;;startRD0000-00-00;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD198807893;;startRDPASADOR BARRA DE DISPARO;;startRDC/U;;startRD3;;startRD9.26;;startRD0;;startRD0000-00-00;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD198806282;;startRDPERRO BARRA ALIM.;;startRDC/U;;startRD12;;startRD26.015;;startRD0;;startRD0000-00-00;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD1988011797;;startRDPERRO TRASERO BARRA ALIM.;;startRDC/U;;startRD1;;startRD25.81;;startRD0;;startRD0000-00-00;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD1988013977;;startRDROBORTE BARRA ALIM.TRINQUETE;;startRDC/U;;startRD40;;startRD0.6855;;startRD0;;startRD0000-00-00;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD5934795;;startRDROTULA BARRA MANDO;;startRDU;;startRD0;;startRD3.27;;startRD34.45;;startRD2012-05-27;;startRD5;;startRDAlmacen CentralendRD
startRD3963330;;startRDSOP. BARRAS CILINDRICAS 80 MM;;startRDC/U;;startRD1;;startRD0.9;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3963257;;startRDSOP. DE BARRA IZQUIERDO GRANDE;;startRDC/U;;startRD1;;startRD1.1;;startRD0;;startRD2011-06-21;;startRD30;;startRDArmando MirabalendRD
startRD3963338;;startRDSOP. P/BARRAS RECORTADOR 20 MM;;startRDC/U;;startRD1;;startRD1.9;;startRD0;;startRD2011-06-21;;startRD30;;startRDArmando MirabalendRD
startRD3963258;;startRDSOP.BARRA RECTO GRANDE;;startRDC/U;;startRD1;;startRD4.5;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3963462;;startRDSOPORTE DE BARRA SOLDADORA;;startRDC/U;;startRD1;;startRD94.3;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD5934831;;startRDTERMINAL DERECHO BARRA;;startRDU;;startRD1;;startRD2.58;;startRD30.665;;startRD2011-06-19;;startRD5;;startRDAlmacen CentralendRD
startRD5934830;;startRDTERMINAL IZQUIERDO BARRA;;startRDU;;startRD1;;startRD2.41;;startRD28.525;;startRD2011-06-19;;startRD5;;startRDAlmacen CentralendRD
startRD19014889;;startRDTEXTOLITE EN BARRA;;startRDKGS;;startRD1;;startRD8.4789474;;startRD0;;startRD2008-03-24;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD3902639815;;startRDACERO 4 X 9 CZ DE 28 MM;;startRDKGS;;startRD2;;startRD0.7888889;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026108;;startRDACERO CALIBRADO 3 MM;;startRDKGS;;startRD10;;startRD0.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD19819692;;startRDACERO CUAD G 45 DIAM 28MM;;startRDKGS;;startRD12;;startRD126.0201681;;startRD0;;startRD2007-01-22;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD390320026;;startRDACERO CUADRADO 9 X 8 G 40 MM;;startRDKGS;;startRD11;;startRD0.4063636;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320029;;startRDACERO CUADRADO 9 X 8 G 50 MM;;startRDKGS;;startRD122;;startRD0.5695902;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320050;;startRDACERO CUADRADO GR-45 36 MM;;startRDKGS;;startRD34;;startRD0.2352941;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390279997;;startRDACERO CUADRADO X 12 M 12 MM;;startRDKGS;;startRD8;;startRD1.3125;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390279998;;startRDACERO CUADRADO X 12 M 16 MM;;startRDKGS;;startRD19;;startRD1.4745946;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902799912;;startRDACERO CUADRADO X 12 M 25 MM;;startRDKGS;;startRD2;;startRD0.8;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320010;;startRDACERO CUADRADO X12M 32 MM;;startRDKGS;;startRD3;;startRD1.3111111;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39032007;;startRDACERO CUADRADO X12M 75 X 75 MM;;startRDKGS;;startRD62;;startRD1.3118506;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3903200;;startRDACERO CUADRADO X12M-100 M-M;;startRDKGS;;startRD34;;startRD1.3117647;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320053;;startRDACERO CUADRADO Y-8-A 16 MM;;startRDKGS;;startRD16;;startRD0.420625;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320047;;startRDACERO EXAGONAL GR-35 8 MM;;startRDKGS;;startRD6;;startRD0.2390625;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320049;;startRDACERO EXAGONAL GR-45 14 MM;;startRDKGS;;startRD12;;startRD0.2443478;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320088;;startRDACERO EXAGONAL GR-45 24 MM;;startRDKGS;;startRD2;;startRD0.4117647;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD19818968;;startRDACERO G 20 DIAM  120 MM;;startRDKGS;;startRD444;;startRD0.2299964;;startRD0;;startRD2007-10-22;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD3902639827;;startRDACERO G. S. N. P/CUCHILLAS DE;;startRDKGS;;startRD8;;startRD1.26;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639830;;startRDACERO G. S. N. P/CUCHILLAS DE;;startRDKGS;;startRD13;;startRD1.26;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639829;;startRDACERO G. S. N. P/CUCHILLAS DE;;startRDKGS;;startRD5;;startRD1.26;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639828;;startRDACERO G. S. N. P/CUCHILLAS DE;;startRDKGS;;startRD7;;startRD1.26;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639831;;startRDACERO G. S. N. P/CUCHILLAS DE;;startRDKGS;;startRD6;;startRD1.26;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639825;;startRDACERO G. S. N. P/CUCHILLAS DE;;startRDKGS;;startRD7;;startRD1.26;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639826;;startRDACERO G. S. N. P/CUCHILLAS DE;;startRDKGS;;startRD10;;startRD1.26;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639824;;startRDACERO G. S. N. P/CUCHILLOS DE;;startRDKGS;;startRD4;;startRD1.26;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD19819259;;startRDACERO G-20 DIAM 100 MM;;startRDKGS;;startRD274;;startRD1.5799949;;startRD0;;startRD2007-10-10;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD3902639823;;startRDACERO HALCOMBI 9 1/4X8X1 1/2;;startRDKGS;;startRD3;;startRD1.26;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639820;;startRDACERO HALCOMBI DE 10 3/4X9X2;;startRDKGS;;startRD7;;startRD2.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639821;;startRDACERO HALCOMBI DE 11 X 9 X 3;;startRDKGS;;startRD14;;startRD2.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639822;;startRDACERO HALCOMBI DE 11X9 1/2X2;;startRDKGS;;startRD6;;startRD2.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639817;;startRDACERO HALCOMBI DE 9 1/4 X;;startRDKGS;;startRD7;;startRD2.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639818;;startRDACERO HALCOMBI DE 9 5/8 X;;startRDKGS;;startRD7;;startRD2.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902639819;;startRDACERO HALCOMBI DE 9 5/8 X 8;;startRDKGS;;startRD8;;startRD2.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320089;;startRDACERO PLANCHUELA 3KP 16 X 50MM;;startRDKGS;;startRD9;;startRD0.2622222;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39032009;;startRDACERO PLANCHUELA 9 X 8 G;;startRDKGS;;startRD20;;startRD0.4779412;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320030;;startRDACERO PLANCHUELA 9 X 8 G;;startRDKGS;;startRD24;;startRD0.4720833;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320021;;startRDACERO PLANCHUELA 9 X 8 G;;startRDKGS;;startRD3;;startRD0.48;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320027;;startRDACERO PLANCHUELA 9 X 8 G;;startRDKGS;;startRD3;;startRD0.496;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320080;;startRDACERO PLANCHUELA GR 6002 8X40;;startRDKGS;;startRD3;;startRD0.35;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320048;;startRDACERO PLANCHUELA GR-35 20-200;;startRDKGS;;startRD14;;startRD0.2364286;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39032006;;startRDACERO PLANCHUELA X12M 40 X 80;;startRDKGS;;startRD12;;startRD0.5091667;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39032002;;startRDACERO PLANCHUELA X12M-10 X 100;;startRDKGS;;startRD4;;startRD0.2457143;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320055;;startRDACERO PLANCHUELA Y 8 A 20 X 80;;startRDKGS;;startRD16;;startRD0.323125;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD19819694;;startRDACERO RED 30  HMA DE DIAM 190M;;startRDKGS;;startRD37;;startRD0.7379781;;startRD0;;startRD0000-00-00;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD19819042;;startRDACERO RED G - 20  DIAM 25 MM;;startRDKGS;;startRD37;;startRD0.5501216;;startRD0;;startRD2007-01-02;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD19819689;;startRDACERO RED X12M X 32MM;;startRDKGS;;startRD146;;startRD1.2300344;;startRD0;;startRD2007-01-02;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD390320077;;startRDACERO RED. CALIBRADO GR B-1;;startRDKGS;;startRD8;;startRD1.0106667;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320082;;startRDACERO RED. CSN 38 MM;;startRDKGS;;startRD20;;startRD0.768;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025956;;startRDACERO RED. GDO. 40 XC DE 25 MM;;startRDKGS;;startRD22;;startRD0.3;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026036;;startRDACERO RED. GDO. 9 X 18 DE 70;;startRDKGS;;startRD26;;startRD0.5579365;;startRD0;;startRD2012-03-28;;startRD30;;startRDArmando MirabalendRD
startRD390320046;;startRDACERO RED. GR-35 45 MM;;startRDKGS;;startRD39;;startRD0.2894872;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320076;;startRDACERO RED. GRD P-18 20 MM;;startRDKGS;;startRD6;;startRD2.45;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320078;;startRDACERO RED. GRD PH8 52 MM;;startRDKGS;;startRD3;;startRD2.47;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320086;;startRDACERO RED. POLDI CSN 194343;;startRDKGS;;startRD212;;startRD0.7375;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320041;;startRDACERO REDONDO 30 XMA 250 MM;;startRDKGS;;startRD46;;startRD0.3973913;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320037;;startRDACERO REDONDO 30 XMA 50 MM;;startRDKGS;;startRD30;;startRD0.397;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320038;;startRDACERO REDONDO 30 XMA 56 MM;;startRDKGS;;startRD94;;startRD0.3626738;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320039;;startRDACERO REDONDO 30 XMA 60 MM;;startRDKGS;;startRD22;;startRD0.3622727;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320040;;startRDACERO REDONDO 30 XMA 70 MM;;startRDKGS;;startRD78;;startRD0.3113548;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320042;;startRDACERO REDONDO 61-20-25 MM;;startRDKGS;;startRD9;;startRD0.0866667;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39032008;;startRDACERO REDONDO 9 X 8 G 10 MM;;startRDKGS;;startRD29;;startRD0.4208904;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320031;;startRDACERO REDONDO 9 X 8 G 125 MM;;startRDKGS;;startRD169;;startRD0.4046154;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320035;;startRDACERO REDONDO 9 X 8 G 150 MM;;startRDKGS;;startRD638;;startRD0.5091066;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320033;;startRDACERO REDONDO 9 X 8 G 180 MM;;startRDKGS;;startRD228;;startRD0.5090351;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320022;;startRDACERO REDONDO 9 X 8 G 20 MM;;startRDKGS;;startRD17;;startRD0.4558824;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320034;;startRDACERO REDONDO 9 X 8 G 230 MM;;startRDKGS;;startRD100;;startRD0.2122;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320023;;startRDACERO REDONDO 9 X 8 G 25 MM;;startRDKGS;;startRD8;;startRD0.488;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320024;;startRDACERO REDONDO 9 X 8 G 32 MM;;startRDKGS;;startRD20;;startRD0.4025;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320025;;startRDACERO REDONDO 9 X 8 G 35 MM;;startRDKGS;;startRD13;;startRD0.2366412;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320036;;startRDACERO REDONDO 9 X 8 G 360 MM;;startRDKGS;;startRD39;;startRD0.5090909;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320052;;startRDACERO REDONDO GRD-45 75 MM;;startRDKGS;;startRD26;;startRD0.24;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902799910;;startRDACERO REDONDO X 12 M 22 MM;;startRDKGS;;startRD1;;startRD0.54;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD3902799911;;startRDACERO REDONDO X 12 M 25 MM;;startRDKGS;;startRD45;;startRD0.7368539;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320020;;startRDACERO REDONDO X12M 100 MM;;startRDKGS;;startRD344;;startRD1.0364826;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39032003;;startRDACERO REDONDO X12M 120 MM;;startRDKGS;;startRD120;;startRD0.7110833;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39032004;;startRDACERO REDONDO X12M 140 MM;;startRDKGS;;startRD6;;startRD0.71;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320032;;startRDACERO REDONDO X12M 200 MM;;startRDKGS;;startRD110;;startRD0.4555455;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39032005;;startRDACERO REDONDO X12M 200 MM;;startRDKGS;;startRD63;;startRD0.7111111;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320011;;startRDACERO REDONDO X12M 38 MM;;startRDKGS;;startRD17;;startRD0.7117647;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320012;;startRDACERO REDONDO X12M 45 MM;;startRDKGS;;startRD162;;startRD0.3531481;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320013;;startRDACERO REDONDO X12M 50 MM;;startRDKGS;;startRD446;;startRD0.7794843;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320014;;startRDACERO REDONDO X12M 55 MM;;startRDKGS;;startRD4;;startRD0.7125;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320015;;startRDACERO REDONDO X12M 60 MM;;startRDKGS;;startRD46;;startRD0.7119565;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320016;;startRDACERO REDONDO X12M 65 MM;;startRDKGS;;startRD49;;startRD0.7410204;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320017;;startRDACERO REDONDO X12M 70 MM;;startRDKGS;;startRD30;;startRD0.7125424;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320018;;startRDACERO REDONDO X12M 75 MM;;startRDKGS;;startRD56;;startRD0.712234;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320019;;startRDACERO REDONDO X12M 95 MM;;startRDKGS;;startRD333;;startRD1.0034535;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320043;;startRDACERO REDONDO X12M DE 80 MM;;startRDKGS;;startRD220;;startRD0.6588182;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39032001;;startRDACERO REDONDO X12M-110-M-M;;startRDKGS;;startRD22;;startRD0.7113636;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390320054;;startRDACERO REDONDO Y 8 A 25 MM;;startRDKGS;;startRD22;;startRD0.3311628;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026117;;startRDACERO ROLLDI SSN # 17246 DE;;startRDKGS;;startRD3;;startRD1.94;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39025959;;startRDACERO X 12 M PLANCHUELA DE;;startRDKGS;;startRD3;;startRD2.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD19819690;;startRDACERO X 12M DIAM 60MM;;startRDKGS;;startRD449;;startRD3.0450071;;startRD0;;startRD2007-10-22;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD19014854;;startRDALAMBRE ACERO .26 0.65 MM;;startRDKGS;;startRD4;;startRD0.4916667;;startRD0;;startRD2005-09-12;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD39027448;;startRDALAMBRE ACERO P/HACER MUELLE;;startRDKGS;;startRD46;;startRD0.2301099;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026158;;startRDALAMBRE ACERO P/MUELLE LOCZA;;startRDKGS;;startRD8;;startRD0.7420031;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD19014051;;startRDALAMBRE ACERO P/MUELLES .80 MM;;startRDKGS;;startRD90;;startRD0.1600713;;startRD0;;startRD2005-09-14;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD39027639;;startRDALAMBRE ACERO P/MUELLES 1 MM;;startRDKGS;;startRD14;;startRD0.8702899;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026201;;startRDALAMBRE ACERO P/MUELLES 60 CAS;;startRDKGS;;startRD74;;startRD0.8768919;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390262021;;startRDALAMBRE ACERO P/MUELLES CLASE;;startRDKGS;;startRD64;;startRD0.3399376;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390261991;;startRDALAMBRE ACERO P/MUELLES CLASE;;startRDKGS;;startRD60;;startRD0.34;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027640;;startRDALAMBRE ACERO P/MUELLES CLASE;;startRDKGS;;startRD4;;startRD0.2485714;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026200;;startRDALAMBRE ACERO P/MUELLES CLASE;;startRDKGS;;startRD56;;startRD0.241844;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026204;;startRDALAMBRE ACERO P/MUELLES GR-65;;startRDKGS;;startRD50;;startRD0.27;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD19014853;;startRDALAMBRE DE ACERO .0255;;startRDKGS;;startRD9;;startRD0.4797872;;startRD0;;startRD2005-09-12;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1908715;;startRDALAMBRE DE ACERO .200 50 MM;;startRDKGS;;startRD10;;startRD0.1411765;;startRD0;;startRD2005-09-21;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD190557;;startRDALAMBRE DE ACERO 0.118 MM;;startRDKGS;;startRD5;;startRD0.2496164;;startRD0;;startRD2008-04-17;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD19018605;;startRDALAMBRE DE ACERO 6.5 SEGUNDA 1 ROLLO;;startRDTM;;startRD0;;startRD148.6701031;;startRD244.6701031;;startRD2012-04-26;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1901217;;startRDARANDELA PRESION ACERO NEG.3/4;;startRDC/U;;startRD54;;startRD0.0134848;;startRD0;;startRD2012-02-13;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD19016736;;startRDBALAS DE ACERO 1 3/4;;startRDC/U;;startRD5;;startRD0.81;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD39325842;;startRDBALAS DE ACERO DE 7/16;;startRDC/U;;startRD11;;startRD0.01;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD19319030;;startRDBOLA DE ACERO 1/8;;startRDC/U;;startRD43;;startRD0.0113953;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD19016940;;startRDBOLAS ACERO 8 MM;;startRDC/U;;startRD493;;startRD0.01;;startRD0;;startRD2010-10-31;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD19017408;;startRDBOLAS DE ACERO 1/4;;startRDC/U;;startRD58;;startRD0.0303448;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD59342292;;startRDBOLAS DE ACERO 1/8;;startRDC/U;;startRD28;;startRD0.011;;startRD0;;startRD2009-05-21;;startRD5;;startRDAlmacen CentralendRD
startRD190195;;startRDBOLAS DE ACERO DE 10 MM O 3/8";;startRDC/U;;startRD190;;startRD0.01;;startRD0;;startRD2011-10-10;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD190196;;startRDBOLAS DE ACERO DE 17 X 32;;startRDC/U;;startRD6;;startRD0.02;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD190198;;startRDBOLAS DE ACERO DE 3/4;;startRDC/U;;startRD8;;startRD0.06;;startRD0;;startRD2005-03-31;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD59344137;;startRDBOLAS DE ACERO DE 3/4;;startRDC/U;;startRD147;;startRD0.06;;startRD0;;startRD0000-00-00;;startRD5;;startRDAlmacen CentralendRD
startRD190200;;startRDBOLAS DE ACERO DE 5/8;;startRDC/U;;startRD149;;startRD0.0368456;;startRD0;;startRD2006-10-31;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1964446;;startRDBROCA ACERO;;startRDJGO;;startRD2;;startRD1.96;;startRD11.63;;startRD2009-02-12;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD5964446;;startRDBROCA P/ACERO;;startRDJGO;;startRD2;;startRD1.96;;startRD11.63;;startRD2009-02-11;;startRD5;;startRDAlmacen CentralendRD
startRD1905216;;startRDCABLE DE ACERO BRILLANET 9.1;;startRDTM;;startRD0;;startRD611.9904077;;startRD0;;startRD2007-11-28;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD5903030;;startRDCABLE DE ACERO BRILLANTE 9.7MM;;startRDMTS;;startRD400;;startRD0.099975;;startRD0;;startRD2005-04-30;;startRD5;;startRDAlmacen CentralendRD
startRD19015904;;startRDCAPILAR ACERO INOX. � EXT.4 MM;;startRDKGS;;startRD17;;startRD14.5586207;;startRD0;;startRD2004-12-15;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD59010299;;startRDCERCA PIRLET 1.80 X 10 MALLA ACERO ROLLO;;startRDU;;startRD6;;startRD11.7;;startRD38.2;;startRD2011-09-27;;startRD5;;startRDAlmacen CentralendRD
startRD5934482;;startRDCLAN ACERO LADA;;startRDJGO;;startRD1;;startRD1.11;;startRD3.38;;startRD2010-06-09;;startRD5;;startRDAlmacen CentralendRD
startRD59021376;;startRDCUCHARITA CAFE   ROMA ACERO INX;;startRDU;;startRD3;;startRD0.1066667;;startRD0.43;;startRD2009-11-27;;startRD5;;startRDAlmacen CentralendRD
startRD1963686;;startRDCUCHILLA ACERO 6X6X125;;startRDC/U;;startRD1;;startRD2.77;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD39625755;;startRDDADO DE ROSCAR A MANO ACERO;;startRDC/U;;startRD1;;startRD1.63;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39625749;;startRDDADO DE ROSCAS A MANO ACERO;;startRDC/U;;startRD1;;startRD1.25;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD59653527;;startRDDADO MANUAL ACERO  5/16 X 18;;startRDC/U;;startRD3;;startRD0.72;;startRD0;;startRD0000-00-00;;startRD5;;startRDAlmacen CentralendRD
startRD396257441;;startRDDADO RDO. MANUAL ACERO HTA;;startRDC/U;;startRD2;;startRD0.35;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39625745;;startRDDADO RDO. MANUAL ACERO HTA DE;;startRDC/U;;startRD3;;startRD0.69;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39625747;;startRDDADO RDO. MANUAL ACERO HTA. DE;;startRDC/U;;startRD2;;startRD0.66;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39625756;;startRDDADO REDONDO ACERO AL CARBONO;;startRDC/U;;startRD1;;startRD1.21;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD59653489;;startRDDADO REDONDO MANUAL ACERO;;startRDC/U;;startRD2;;startRD1.37;;startRD0;;startRD2009-06-03;;startRD5;;startRDAlmacen CentralendRD
startRD59653497;;startRDDADO REDONDO MANUAL ACERO;;startRDC/U;;startRD5;;startRD1.21;;startRD0;;startRD2011-08-09;;startRD5;;startRDAlmacen CentralendRD
startRD59653487;;startRDDADO REDONDO MANUAL-ACERO;;startRDC/U;;startRD2;;startRD0.52;;startRD0;;startRD2009-06-03;;startRD5;;startRDAlmacen CentralendRD
startRD3962797711;;startRDESPATULA ACERO FLEXIBLE DE 1";;startRDC/U;;startRD2;;startRD0.51;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026126;;startRDFLEJES ACERO 0.5 X 15 MM;;startRDKGS;;startRD837;;startRD0.3584229;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD396279977;;startRDFRESA P/ACERO 5 X 25 MM;;startRDC/U;;startRD1;;startRD4.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD19819048;;startRDG - 45 ACERO DIAM 180;;startRDKGS;;startRD561;;startRD0.5699841;;startRD0;;startRD2007-12-09;;startRD14;;startRDLuis Melian (Pzas prefabr)endRD
startRD396279292;;startRDMACHO MANUAL ACERO HERR. DE;;startRDC/U;;startRD2;;startRD4.55;;startRD0;;startRD2005-12-04;;startRD30;;startRDArmando MirabalendRD
startRD39625704;;startRDMACHO MANUAL ACERO HTA 3/4X14;;startRDJGO;;startRD1;;startRD0.63;;startRD0;;startRD2005-11-23;;startRD30;;startRDArmando MirabalendRD
startRD396257181;;startRDMACHO MANUAL ACERO HTA. 3/4X10;;startRDJGO;;startRD1;;startRD18.06;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39627929;;startRDMACHO MANUAL ACERO HTA. ROSCA;;startRDC/U;;startRD1;;startRD1.94;;startRD0;;startRD2005-12-04;;startRD30;;startRDArmando MirabalendRD
startRD39625715;;startRDMACHO MANUAL ACERO P/ROSCA JGO 3 PIEZAS;;startRDC/U;;startRD1;;startRD1.63;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39625724;;startRDMACHO MANUAL ACERO P/ROSCA NC JGO 2 PIEZAS;;startRDC/U;;startRD1;;startRD3.93;;startRD0;;startRD2005-12-04;;startRD30;;startRDArmando MirabalendRD
startRD19017837;;startRDMALLA ACERO 11X13X0.97;;startRDKGS;;startRD60;;startRD0.5;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1909284;;startRDPASADOR ACERO CONICO #10  3";;startRDC/U;;startRD48;;startRD0.375;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1909274;;startRDPASADOR ACERO CONICO #2  3";;startRDC/U;;startRD254;;startRD0.1146063;;startRD0;;startRD2006-01-04;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD190388;;startRDPASADOR ACERO CONICO #7 DE 3";;startRDC/U;;startRD52;;startRD0.1148077;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1909281;;startRDPASADOR ACERO CONICO #8 DE 3";;startRDC/U;;startRD103;;startRD0.1148571;;startRD0;;startRD2009-01-27;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1909283;;startRDPASADOR ACERO CONICO #9 4";;startRDC/U;;startRD11;;startRD0.1327273;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD39027582;;startRDPASADORES ABIERTOS ACERO DE;;startRDC/U;;startRD1;;startRD0.54;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027578;;startRDPASADORES ABIERTOS ACERO DE;;startRDC/U;;startRD1;;startRD0.69;;startRD0;;startRD2005-12-08;;startRD30;;startRDArmando MirabalendRD
startRD39027577;;startRDPASADORES ABIERTOS ACERO DE;;startRDKGS;;startRD1;;startRD1.09;;startRD0;;startRD2005-12-08;;startRD30;;startRDArmando MirabalendRD
startRD39027579;;startRDPASADORES ABIERTOS ACERO DE;;startRDKGS;;startRD1;;startRD0.65;;startRD0;;startRD2005-12-08;;startRD30;;startRDArmando MirabalendRD
startRD39027576;;startRDPASADORES ABIERTOS ACERO DE;;startRDKGS;;startRD1;;startRD1.12;;startRD0;;startRD2005-12-08;;startRD30;;startRDArmando MirabalendRD
startRD39027581;;startRDPASADORES ABIERTOS ACERO DE;;startRDC/U;;startRD2;;startRD0.545;;startRD0;;startRD2005-12-08;;startRD30;;startRDArmando MirabalendRD
startRD59017143;;startRDPASADORES ABIERTOS DE ACERO;;startRDC/U;;startRD700;;startRD0.7086;;startRD0;;startRD2004-12-14;;startRD5;;startRDAlmacen CentralendRD
startRD1909270;;startRDPASADORES ACERO CONICO #1 2";;startRDC/U;;startRD130;;startRD0.1133077;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1909273;;startRDPASADORES ACERO CONICO #2;;startRDC/U;;startRD11;;startRD0.1128571;;startRD0;;startRD2012-01-31;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1909282;;startRDPASADORES ACERO CONICO #9 3";;startRDC/U;;startRD94;;startRD0.1158511;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1909269;;startRDPASADORES DE ACERO CONICO # 1;;startRDC/U;;startRD48;;startRD0.1152083;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD59010038;;startRDPERSIANA ACERO GALV 1X400 1X20;;startRDC/U;;startRD1;;startRD93.59;;startRD0;;startRD2006-10-19;;startRD5;;startRDAlmacen CentralendRD
startRD5904918;;startRDPICO DE ACERO COBRIZADO 1.5M;;startRDu;;startRD4;;startRD69.0425;;startRD21.5725;;startRD2012-08-21;;startRD5;;startRDAlmacen CentralendRD
startRD19320459;;startRDPLACA FRIJACION CHAPA ACERO;;startRDU;;startRD0;;startRD1.415;;startRD2.55;;startRD2012-07-02;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD390260972;;startRDPLANCHA ACERO GRADO 9 X BG DE;;startRDKGS;;startRD123;;startRD0.4035772;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026048;;startRDPLANCHA ACERO GRAO 3 KP DE;;startRDKGS;;startRD322;;startRD0.11;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026071;;startRDPLANCHUELA ACERO 3 KP 12X50 MM;;startRDKGS;;startRD23;;startRD0.1996;;startRD0;;startRD2012-03-28;;startRD30;;startRDArmando MirabalendRD
startRD390276141;;startRDPLANCHUELA ACERO 9 X B6 DE;;startRDKGS;;startRD11;;startRD0.56;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260973;;startRDPLANCHUELA ACERO 9 X BG DE;;startRDKGS;;startRD8;;startRD0.4746988;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026067;;startRDPLANCHUELA ACERO AL CARBONO;;startRDKGS;;startRD6;;startRD0.2;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026051;;startRDPLANCHUELA ACERO G. 35 DE;;startRDKGS;;startRD67;;startRD0.2370149;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390261101;;startRDPLANCHUELA ACERO LAM. CALIENTE;;startRDKGS;;startRD0;;startRD0.3397674;;startRD0;;startRD2012-03-28;;startRD30;;startRDArmando MirabalendRD
startRD390261102;;startRDPLANCHUELA ACERO LAM. CALIENTE;;startRDKGS;;startRD31;;startRD0.3386139;;startRD0;;startRD2012-03-28;;startRD30;;startRDArmando MirabalendRD
startRD390261051;;startRDPLANCHUELA ACERO LAMINADA EN;;startRDKGS;;startRD50;;startRD1.5350515;;startRD0;;startRD2012-03-28;;startRD30;;startRDArmando MirabalendRD
startRD39027895;;startRDPLANCHUELA ACERO LAMINADA EN;;startRDKGS;;startRD6;;startRD0.7507937;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD390260971;;startRDPLANCHUELA ACERO LAVADO 9 X B;;startRDKGS;;startRD8;;startRD0.675;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027758;;startRDPLANCHUELA DE ACERO;;startRDC/U;;startRD91;;startRD0.2552486;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD59010058;;startRDPLANCHUELA DE ACERO;;startRDTM;;startRD0;;startRD73.6403509;;startRD850.4166667;;startRD2012-05-02;;startRD5;;startRDAlmacen CentralendRD
startRD39027822;;startRDPLANCHUELA DE ACERO 9XB6 DE;;startRDKGS;;startRD6;;startRD0.4032258;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027739;;startRDPLANCHUELA DE ACERO DE 3KP DE;;startRDKGS;;startRD5;;startRD0.2555556;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027220;;startRDPLANCHUELA DE ACERO GDO. DE;;startRDKGS;;startRD18;;startRD0.95;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027824;;startRDPLANCHUELA DE ACERO GRADO 45;;startRDKGS;;startRD108;;startRD0.14;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39027380;;startRDPLANCHUELAS ACERO 25.4X6.35 MM;;startRDKGS;;startRD49;;startRD0.7442387;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39017912;;startRDPUNTILLA DE ACERO 2 1/2;;startRDKGS;;startRD2;;startRD0.488;;startRD2.08;;startRD2012-10-01;;startRD30;;startRDArmando MirabalendRD
startRD59017912;;startRDPUNTILLA DE ACERO 2 1/2;;startRDKGS;;startRD339;;startRD0.4881896;;startRD2.0801823;;startRD2012-09-18;;startRD5;;startRDAlmacen CentralendRD
startRD1907161;;startRDREMACHE ACERO GALV. 1/8 X 3/8;;startRDC/U;;startRD1176;;startRD0.0020172;;startRD0;;startRD2012-04-08;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD39026729;;startRDREMACHE ACERO GALV. C/P;;startRDKGS;;startRD3;;startRD0.7066667;;startRD0;;startRD2005-12-13;;startRD30;;startRDArmando MirabalendRD
startRD39026730;;startRDREMACHE ACERO GALV. C/PLANA;;startRDKGS;;startRD1;;startRD2.12;;startRD0;;startRD2005-12-07;;startRD30;;startRDArmando MirabalendRD
startRD39026734;;startRDREMACHE ACERO GALV. C/PLANA;;startRDKGS;;startRD0;;startRD0.8;;startRD0;;startRD2007-11-12;;startRD30;;startRDArmando MirabalendRD
startRD39026736;;startRDREMACHE ACERO GALV. C/PLANA;;startRDKGS;;startRD2;;startRD0.61;;startRD0;;startRD2011-01-26;;startRD30;;startRDArmando MirabalendRD
startRD39026732;;startRDREMACHES ACERO GALV. C/P DE;;startRDKGS;;startRD2;;startRD0.88;;startRD0;;startRD2007-02-05;;startRD30;;startRDArmando MirabalendRD
startRD39625874;;startRDRIMAS AJUSTABLES DE MANO ACERO;;startRDC/U;;startRD1;;startRD3.51;;startRD0;;startRD2005-12-04;;startRD30;;startRDArmando MirabalendRD
startRD39625868;;startRDRIMAS AJUSTABLES DE MANO ACERO;;startRDC/U;;startRD1;;startRD15.22;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39625873;;startRDRIMAS APORTABLES DE MANO ACERO;;startRDC/U;;startRD2;;startRD3.64;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD19320462;;startRDRODILLO TAMBOR ACERO;;startRDU;;startRD0;;startRD1.42;;startRD2.55;;startRD2012-07-02;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD59023202;;startRDTANQUE ACERO PRECION;;startRDC/U;;startRD13;;startRD267.0261538;;startRD0;;startRD0000-00-00;;startRD5;;startRDAlmacen CentralendRD
startRD59021373;;startRDTENEDOR ACERO INOXIDABLE;;startRDU;;startRD87;;startRD0.2163218;;startRD0.8702299;;startRD2009-12-08;;startRD5;;startRDAlmacen CentralendRD
startRD19015847;;startRDTOR.PRIS.ACERO C/CIL #6 32 H.;;startRDC/U;;startRD165;;startRD0.0632727;;startRD0;;startRD2005-02-02;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD19010267;;startRDTORN.PRIS.ACERO C/CIL;;startRDC/U;;startRD179;;startRD0.0966129;;startRD0;;startRD2011-03-15;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD19015849;;startRDTORN.PRIS.ACERO C/CILIND 5/32;;startRDC/U;;startRD301;;startRD0.0565449;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1907859;;startRDTORNILLO ACERO PULIDO C/EXAG.;;startRDC/U;;startRD119;;startRD0.1320168;;startRD0;;startRD2005-04-30;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1907854;;startRDTORNILLO ACERO PULIDO C/EXAG.;;startRDC/U;;startRD346;;startRD0.1077077;;startRD0;;startRD2011-05-31;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD39027259;;startRDTORNILLO ACERO PULIDO C/EXAG.;;startRDC/U;;startRD397;;startRD0.0787442;;startRD0;;startRD2012-07-03;;startRD30;;startRDArmando MirabalendRD
startRD1907390;;startRDTORNILLO ACERO PULIDO C/MAQUI.;;startRDC/U;;startRD600;;startRD0.0166924;;startRD0;;startRD2012-06-25;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD39026532;;startRDTORNILLO ALLEN ACERO C/CILIND.;;startRDC/U;;startRD25;;startRD0.04;;startRD0;;startRD2005-12-05;;startRD30;;startRDArmando MirabalendRD
startRD39026517;;startRDTORNILLO ALLEN ACERO CABEZA;;startRDC/U;;startRD36;;startRD0.0618667;;startRD0;;startRD2012-09-20;;startRD30;;startRDArmando MirabalendRD
startRD39026516;;startRDTORNILLO ALLEN ACERO CABEZA;;startRDC/U;;startRD178;;startRD0.0603371;;startRD0;;startRD2006-08-20;;startRD30;;startRDArmando MirabalendRD
startRD39026515;;startRDTORNILLO ALLEN DE ACERO CABEZA;;startRDC/U;;startRD16;;startRD0.03375;;startRD0;;startRD2007-02-18;;startRD30;;startRDArmando MirabalendRD
startRD19012003;;startRDTORNILLO DE ACERO 3/8 X 1 1/4;;startRDC/U;;startRD120;;startRD0.0528333;;startRD0;;startRD2007-11-18;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD390265511;;startRDTORNILLO DE MAQUINA DE ACERO;;startRDC/U;;startRD8;;startRD0.05;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026646;;startRDTORNILLO ESTUFA ACERO GALV.5/16X518;;startRDC/U;;startRD167;;startRD0.0247904;;startRD0;;startRD2005-12-06;;startRD30;;startRDArmando MirabalendRD
startRD39026567;;startRDTORNILLO MAQ. ACERO C/EXAG.;;startRDC/U;;startRD17;;startRD0.05;;startRD0;;startRD2005-12-06;;startRD30;;startRDArmando MirabalendRD
startRD39026568;;startRDTORNILLO MAQ. ACERO C/EXAG.;;startRDC/U;;startRD21;;startRD0.06;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD39026571;;startRDTORNILLO MAQ. ACERO C/EXAG.;;startRDC/U;;startRD26;;startRD0.01;;startRD0;;startRD2005-12-06;;startRD30;;startRDArmando MirabalendRD
startRD39026550;;startRDTORNILLO MAQ. ACERO EXAGONAL;;startRDC/U;;startRD169;;startRD0.01;;startRD0;;startRD2011-01-05;;startRD30;;startRDArmando MirabalendRD
startRD39026654;;startRDTORNILLO MAQUINA ACERO 3/4 X 5;;startRDC/U;;startRD11;;startRD0.3063636;;startRD0;;startRD2005-12-06;;startRD30;;startRDArmando MirabalendRD
startRD19013365;;startRDTORNILLO PRIS. ACERO C/CIL.;;startRDC/U;;startRD39;;startRD0.1538095;;startRD0;;startRD2011-11-14;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1901156;;startRDTORNILLO PRIS.ACERO C/C R/STD;;startRDC/U;;startRD223;;startRD0.155434;;startRD0;;startRD2012-02-14;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD190605;;startRDTORNILLO PRIS.ACERO CILIND. DE;;startRDC/U;;startRD25;;startRD0.0568;;startRD0;;startRD0000-00-00;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD1901599;;startRDTORNILLO PRIS.ACERO EMBUTIR;;startRDC/U;;startRD220;;startRD0.030913;;startRD0;;startRD2010-06-22;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD19013420;;startRDTORNILLO PRISIONERO ACERO;;startRDC/U;;startRD44;;startRD0.05;;startRD0;;startRD2007-01-12;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD39026518;;startRDTORNILLOS ALLEN DE ACERO;;startRDC/U;;startRD38;;startRD0.0285714;;startRD0;;startRD2011-01-31;;startRD30;;startRDArmando MirabalendRD
startRD39026621;;startRDTORNILLOS MAQUINA ACERO COMUN;;startRDC/U;;startRD210;;startRD0.01;;startRD0;;startRD2007-03-21;;startRD30;;startRDArmando MirabalendRD
startRD39021408;;startRDTUBO ACERO DE 1/2;;startRDU;;startRD0;;startRD4.518;;startRD42.504;;startRD2012-04-16;;startRD30;;startRDArmando MirabalendRD
startRD390260356;;startRDTUBOS ACERO INOXIDABLE 32X1.4;;startRDKGS;;startRD77;;startRD1.4;;startRD0;;startRD0000-00-00;;startRD30;;startRDArmando MirabalendRD
startRD1908779;;startRDTUERCA ACERO PULIDO ROSCA GRUE;;startRDC/U;;startRD205;;startRD0.0760408;;startRD0;;startRD2012-04-24;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD39026698;;startRDTUERCA EXAG. ACERO R/STD 1 1/4;;startRDC/U;;startRD90;;startRD0.0185556;;startRD0;;startRD2009-09-08;;startRD30;;startRDArmando MirabalendRD
startRD1901225;;startRDTUERCA STD. ACERO 5/16";;startRDC/U;;startRD553;;startRD0.0169114;;startRD0;;startRD2012-09-18;;startRD11;;startRDLuis Melian (Mat Auxiliares)endRD
startRD5902211;;startRDTURBINA 1/4 DE ACERO GALV.;;startRDKGS;;startRD7;;startRD0.8514286;;startRD0;;startRD0000-00-00;;startRD5;;startRDAlmacen CentralendRD
startRD5904936;;startRDARQUETA REGISTRO 300X300 BARRA TIERRA;;startRDU;;startRD3;;startRD447.9233333;;startRD187.4033333;;startRD2012-08-22;;startRD5;;startRDAlmacen CentralendRD
startRD59021075;;startRDNIPLE ACERO GALV 1/4X31/2;;startRDC/U;;startRD13;;startRD2.063125;;startRD0;;startRD2009-06-03;;startRD5;;startRDAlmacen CentralendRD
end Materiale
end Tiposmateriale

ALUM;;0.5
begin Tiposmateriale
startRDAluminio;;startRD50;;startRD100;;startRDkg/mm2 endRD
begin Materiale
end Materiale
end Tiposmateriale

end Agrupadormateriale
