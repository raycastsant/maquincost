begin_Agrupadormateriale
A I.,20.
A II.,12.
A III.,89.
Bronces.,54.
Indefinido.,0.
ALUM.,0.5.
end_Agrupadormateriale
